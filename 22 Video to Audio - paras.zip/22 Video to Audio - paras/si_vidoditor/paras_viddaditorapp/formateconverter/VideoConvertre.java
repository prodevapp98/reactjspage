package com.si_vidoditor.paras_viddaditorapp.formateconverter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.CompressVideoAdapter;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.Video_Item;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.cuttetinter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class VideoConvertre extends AppCompatActivity {

    public CompressVideoAdapter adapter;


    private List<Video_Item> list = new ArrayList<>();

    private RecyclerView recyclerView;



    private SearchView iv_serch;
    private ImageView iv_serach;


    private ConstraintLayout rv_layoutt;

    Display defaultDisplay;
    DisplayMetrics displayMetrics;
    int i;

    public static final String BASE_TYPE_VIDEO = "video";
    private TextView tex_vie;
    private ConstraintLayout cl_one;
    private Dialog dialog2;

    private ImageView imageView;

    private ImageView iv_gidelist;


    private DataProccessor dataProccessor;

    private ConstraintLayout cl_all_show;
    private ImageView iv_sort;

    private ConstraintLayout cl_allfile;
    private ArrayList<File> pathDAta = new ArrayList<>();

    private TextView tv_tofile;

    private TinyDB tinyDB;
    int sort = 0;
    private ImageView iv_start;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_convertre);


        tinyDB = new TinyDB(VideoConvertre.this);


        dataProccessor = new DataProccessor(VideoConvertre.this);


        VideoConvertre.BradCatRecver bradCatRecver = new VideoConvertre.BradCatRecver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("main_service_api");
        registerReceiver(bradCatRecver, intentFilter);


        changeColor(R.color.home_top2s);

        intDArta();


        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(VideoConvertre.this, admobBanner,cardBAnner);

        if (dataProccessor.getStr("ListType").equals("yes")) {
            iv_gidelist.setImageResource(R.drawable.list);

        } else {
            iv_gidelist.setImageResource(R.drawable.grid);

        }


        iv_gidelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (dataProccessor.getStr("ListType").equals("yes")) {
                    iv_gidelist.setImageResource(R.drawable.grid);
                    dataProccessor.setStr("ListType", "no");


                    Intent intent = new Intent();
                    intent.setAction("main_service_api");
                    intent.putExtra("CONTROL_SERVICE", "Show");
                    sendBroadcast(intent);


                } else {
                    dataProccessor.setStr("ListType", "yes");
                    iv_gidelist.setImageResource(R.drawable.list);

                    Intent intent = new Intent();
                    intent.setAction("main_service_api");
                    intent.putExtra("CONTROL_SERVICE", "Show");
                    sendBroadcast(intent);

                }

            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        iv_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                PopupWindow pwindow = new PopupWindow(VideoConvertre.this);
                pwindow.setBackgroundDrawable(new BitmapDrawable());
                View inflate = getLayoutInflater().inflate(R.layout.sortpopup3, (ViewGroup) null);


                pwindow.setContentView(inflate);
                pwindow.setFocusable(true);
                pwindow.setWindowLayoutMode(-2, -2);
                pwindow.setOutsideTouchable(true);
                pwindow.showAsDropDown(iv_sort, 0, 20);


                TextView tv_asending = inflate.findViewById(R.id.tv_list);
                TextView tv_dessendin = inflate.findViewById(R.id.tv_grid);
                TextView tv_date = inflate.findViewById(R.id.tv_date);


                TextView tv_filco = inflate.findViewById(R.id.tv_filco);


                ImageView circleImageView = inflate.findViewById(R.id.circleImageView);
                ImageView circleImageView2 = inflate.findViewById(R.id.circleImageView2);
                ImageView circleImageView3 = inflate.findViewById(R.id.circleImageView3);
                ImageView circleImageView4 = inflate.findViewById(R.id.circleImageView4);


                if (sort == 0) {
                    circleImageView.setVisibility(View.VISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 1) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.VISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 2) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.VISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 3) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.VISIBLE);

                }


                tv_asending.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);
                        sort = 0;
                        pwindow.dismiss();


                        Collections.sort(list, new Comparator<Video_Item>() {
                            @Override
                            public int compare(Video_Item lhs, Video_Item rhs) {

                                File file1 = new File(lhs.getDATA());
                                File file2 = new File(rhs.getDATA());

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });
                        setData();


                    }
                });


                tv_dessendin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);
                        pwindow.dismiss();
                        sort = 1;

                        Collections.sort(list, new Comparator<Video_Item>() {
                            @Override
                            public int compare(Video_Item lhs, Video_Item rhs) {

                                File file1 = new File(lhs.getDATA());
                                File file2 = new File(rhs.getDATA());

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });

                        Collections.reverse(list);
                        setData();


                    }
                });

                tv_date.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);

                        pwindow.dismiss();
                        sort = 2;


                        Collections.sort(list, new Comparator<Video_Item>() {
                            DateFormat f = new SimpleDateFormat("dd-MM-yyyy");

                            @Override
                            public int compare(Video_Item lhs, Video_Item rhs) {
                                try {

                                    SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yyyy");
                                    Date lastModDate = new Date(new File(lhs.getDATA()).lastModified());
                                    String ThiedTime = currentDate.format(lastModDate);

                                    Date lastModDate2 = new Date(new File(rhs.getDATA()).lastModified());
                                    String ThiedTime2 = currentDate.format(lastModDate2);

                                    return f.parse(ThiedTime).compareTo(f.parse(ThiedTime2));
                                } catch (ParseException e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });


                        setData();


                    }
                });

                tv_filco.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);
                        pwindow.dismiss();
                        sort = 3;

                        Collections.sort(list, new Comparator<Video_Item>() {


                            @Override
                            public int compare(Video_Item lhs, Video_Item rhs) {
                                try {



                                    Long duration1 = Long.valueOf(lhs.getDURATION());
                                    Long duration2 = Long.valueOf(rhs.getDURATION());



                                    if (duration1 == null) {
                                        duration1= Long.valueOf(0);
                                    }
                                    if (duration2 == null) {
                                        duration2 = Long.valueOf(0);
                                    }


                                    return duration1.compareTo(duration2);


                                } catch (Exception e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });
                        setData();

                    }
                });






            }
        });


        defaultDisplay = getWindowManager().getDefaultDisplay();
        displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            defaultDisplay.getRealMetrics(displayMetrics);
        }
        i = displayMetrics.widthPixels;






        extraDAtaGet();
        if (list.size() > 0) {
            sort = 0;

            Collections.sort(list, new Comparator<Video_Item>() {
                @Override
                public int compare(Video_Item lhs, Video_Item rhs) {

                    File file1 = new File(lhs.getDATA());
                    File file2 = new File(rhs.getDATA());

                    return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                }
            });


            setData();
            tex_vie.setVisibility(View.GONE);


        } else {

            tex_vie.setVisibility(View.VISIBLE);


        }



        iv_serach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_serch.performClick();
            }
        });




        iv_serch.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            iv_serch.setIconified(false);

                                        }
                                    }
        );


        iv_serch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String str) {
                return false;
            }

            public boolean onQueryTextChange(String str) {
                if (list != null) {

                    if (adapter != null) {
                        adapter.getFilter().filter(str);
                    }


                }

                return false;
            }
        });

        iv_serch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cl_all_show.setVisibility(View.INVISIBLE);
                rv_layoutt.setVisibility(View.VISIBLE);


            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                adapter.getFilter().filter("");
                return false;

            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {

                cl_all_show.setVisibility(View.VISIBLE);
                rv_layoutt.setVisibility(View.GONE);

                return false;
            }
        });





        iv_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tinyDB.putListObject("videoalldata", pathDAta);
                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(VideoConvertre.this, msg -> {
                    startActivity(new Intent(VideoConvertre.this, VideoMultiPleActivity.class));
                });






            }
        });



    }

    public class BradCatRecver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            switch (action) {
                case "main_service_api":
                    String mess = intent.getStringExtra("CONTROL_SERVICE");
                    if (mess.equals("Show")) {

                        if (dataProccessor.getStr("ListType").equals("yes")) {
                            recyclerView.setLayoutManager(new LinearLayoutManager(VideoConvertre.this));

                        } else {
                            GridLayoutManager gridLayoutManager = new GridLayoutManager(VideoConvertre.this, 2);
                            recyclerView.setLayoutManager(gridLayoutManager);

                        }

                        recyclerView.setAdapter(adapter);


                    } else {


                    }


                    break;
            }


        }
    }


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }


    private void intDArta() {
        recyclerView = (RecyclerView) findViewById(R.id.rec);
        iv_start = (ImageView) findViewById(R.id.iv_start);

        iv_gidelist = findViewById(R.id.iv_gidelist);
        tv_tofile = findViewById(R.id.tv_tofile);
        cl_allfile = findViewById(R.id.cl_allfile);

        cl_all_show = findViewById(R.id.cl_all_show);
        iv_sort = findViewById(R.id.iv_sort);


        imageView = findViewById(R.id.imageView);

        cl_one = findViewById(R.id.cl_one);



        iv_serch = findViewById(R.id.searchView);
        iv_serach = findViewById(R.id.iv_serach);



        rv_layoutt = findViewById(R.id.rv_layoutt);



        tex_vie = findViewById(R.id.tex_vie);



    }


    public void onResume() {
        super.onResume();
    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public class dataget extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            runOnUiThread(new Runnable() {
                @Override
                public void run() {


                    dialog2 = new Dialog(VideoConvertre.this);
                    dialog2.setContentView(R.layout.loaderbanner_dialog2);
                    CardView lv_1 = dialog2.findViewById(R.id.lv_1);
                    ProgressBar mk_lod = dialog2.findViewById(R.id.mk_lod);


                    Window window2 = dialog2.getWindow();
                    WindowManager.LayoutParams wlp1 = window2.getAttributes();
                    window2.setAttributes(wlp1);
                    dialog2.setCancelable(false);
                    window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog2.show();


                }
            });


        }

        @Override
        protected Void doInBackground(Void... voids) {




            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    dialog2.dismiss();





                }
            });

        }
    }

    @SuppressLint("Range")
    private void extraDAtaGet() {


        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();


        String str2;

        String[] strArr2 = {"_id", "_size", "date_modified", "_data", "_display_name", "duration"};


        i = 2;
        switch (i) {
            case 0:
                str2 = "date_modified DESC";
                break;
            case 1:
                str2 = "date_modified";
                break;
            case 2:
                str2 = "duration DESC";
                break;
            case 3:
                str2 = "duration";
                break;
            case 4:
                str2 = "_display_name";
                break;
            case 5:
                str2 = "_display_name DESC";
                break;
            case 6:
                str2 = "_size DESC";
                break;
            case 7:
                str2 = "_size";
                break;
            default:
                str2 = null;
                break;
        }


        Cursor cursor = contentResolver.query(uri, null, null, null, "date_modified DESC");
        list.clear();
        if (cursor != null && cursor.moveToFirst()) {
            do {

                String title = null;
                String duration = null;
                String data = null;
                String resolution = null;
                Video_Item videoModel = new Video_Item();

                try {
                    title = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.TITLE));

                } catch (Exception e) {
                    e.printStackTrace();

                }
                try {
                    duration = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DURATION));

                    videoModel.setDURATION(Long.parseLong(duration));

                } catch (Exception e) {
                    videoModel.setDURATION(Long.valueOf(0));
                    e.printStackTrace();
                    duration = null;

                }
                try {

                    resolution = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.RESOLUTION));


                } catch (Exception e) {
                    e.printStackTrace();

                }
                try {
                    data = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));

                } catch (Exception e) {
                    e.printStackTrace();
                }


                if (resolution != null) {

                    int size = cursor.getColumnIndex(OpenableColumns.SIZE);


                    videoModel.setDATA(data);
                    videoModel.setDISPLAY_NAME("data");


                    if (resolution != null) {



                        if(Long.parseLong(duration)!=0) {


                            videoModel.setSIZE("");
                            list.add(videoModel);

                        }

                        // }


                    }


                }
            } while (cursor.moveToNext());
        }


    }


    private void setData() {


        adapter = new CompressVideoAdapter(VideoConvertre.this, list, list, i,
                true, BASE_TYPE_VIDEO, "", new cuttetinter() {
            @Override
            public void datat(ArrayList<File> pathDAta2) {


                pathDAta = pathDAta2;
                if (pathDAta.size() > 0) {

                    tv_tofile.setText("" + pathDAta.size() + " Files");

                    cl_allfile.setVisibility(View.VISIBLE);
                } else {

                    cl_allfile.setVisibility(View.GONE);

                }


            }
        },tex_vie);


        if (dataProccessor.getStr("ListType").equals("yes")) {
            recyclerView.setLayoutManager(new LinearLayoutManager(VideoConvertre.this));

        } else {
            GridLayoutManager gridLayoutManager = new GridLayoutManager(VideoConvertre.this, 2);
            recyclerView.setLayoutManager(gridLayoutManager);

        }


        recyclerView.setAdapter(adapter);


    }


    public static String formatFileSize(long size) {
        String hrSize = null;

        double b = size;
        double k = size / 1024.0;
        double m = ((size / 1024.0) / 1024.0);
        double g = (((size / 1024.0) / 1024.0) / 1024.0);
        double t = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);

        DecimalFormat dec = new DecimalFormat("0.00");

        if (t > 1) {
            hrSize = dec.format(t).concat(" TB");
        } else if (g > 1) {
            hrSize = dec.format(g).concat(" GB");
        } else if (m > 1) {
            hrSize = dec.format(m).concat(" MB");
        } else if (k > 1) {
            hrSize = dec.format(k).concat(" KB");
        } else {
            hrSize = dec.format(b).concat(" Bytes");
        }

        return hrSize;
    }


    @Override
    public void onBackPressed() {
        finish();
    }

    public int getVideoWidthOrHeight(File file, String widthOrHeight) {
        MediaMetadataRetriever retriever = null;
        Bitmap bmp = null;
        FileInputStream inputStream = null;
        int mWidthHeight = 0;
        try {
            retriever = new MediaMetadataRetriever();
            inputStream = new FileInputStream(file.getAbsolutePath());
            retriever.setDataSource(inputStream.getFD());
            bmp = retriever.getFrameAtTime();
            if (widthOrHeight.equals("width")) {
                mWidthHeight = bmp.getWidth();
            } else {
                mWidthHeight = bmp.getHeight();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            if (retriever != null) {
                retriever.release();
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return mWidthHeight;
    }
}