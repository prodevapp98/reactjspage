package com.si_vidoditor.paras_viddaditorapp.formateconverter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.cuttetinter;

import java.io.File;
import java.util.ArrayList;

public class AudioMustiplaActivity extends AppCompatActivity {


    private TinyDB tinyDB;
    private ArrayList<File> alldat;
    private RecyclerView _rv_ciefile;
    private ImageView imageView;
    private String videoFormat = "mp3";
    private AudioMulAdapter VieDataAdapter;
    private ConstraintLayout btSave;
    private TextView tv_nodatafound;
    private ArrayList<File> pathDAta = new ArrayList<>();
    private ImageView iv_gidelist;
    private ImageView bv_mp3, bv_wav, bv_aac, bv_flac, bv_wam, bv_ogg, bv_ac3;


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_mustipla);

        iniData();

        tinyDB = new TinyDB(AudioMustiplaActivity.this);
        alldat = tinyDB.getListObject("audioalldata", File.class);

        iv_gidelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tinyDB.putListObject("audioalldata", new ArrayList<>());
                finish();


            }
        });

        changeColor(R.color.home_top2s);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();


            }
        });

        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(AudioMustiplaActivity.this, admobBanner,cardBAnner);

        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (pathDAta.size() > 0) {


                    new changeformateaudio(AudioMustiplaActivity.this,
                            pathDAta, videoFormat);


                }


            }
        });


        addadprer();


    }


    private void iniData() {


        bv_mp3 = findViewById(R.id.bv_mp3);
        bv_wav = findViewById(R.id.bv_wav);
        bv_aac = findViewById(R.id.bv_aac);
        bv_flac = findViewById(R.id.bv_flac);
        bv_wam = findViewById(R.id.bv_wam);
        bv_ogg = findViewById(R.id.bv_ogg);
        bv_ac3 = findViewById(R.id.bv_ac3);


        bv_mp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat = "mp3";

                bv_mp3.setImageResource(R.drawable.mp3);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });

        bv_wav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat = "wav";

                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });

        bv_aac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat = "aac";

                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });

        bv_flac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat = "flac";

                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });
        bv_wam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat = "wma";

                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });

        bv_ogg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat = "ogg";

                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg);
                bv_ac3.setImageResource(R.drawable.ac3_i);


            }
        });

        bv_ac3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat = "ac3";


                bv_mp3.setImageResource(R.drawable.mp3_i);
                bv_wav.setImageResource(R.drawable.wav_i);
                bv_aac.setImageResource(R.drawable.aac_i);
                bv_flac.setImageResource(R.drawable.flac_i);
                bv_wam.setImageResource(R.drawable.wma_i);
                bv_ogg.setImageResource(R.drawable.ogg_i);
                bv_ac3.setImageResource(R.drawable.ac3);


            }
        });


        iv_gidelist = findViewById(R.id.iv_gidelist);
        btSave = findViewById(R.id.btSave);
        tv_nodatafound = findViewById(R.id.tv_nodatafound);
        imageView = findViewById(R.id.imageView);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        tinyDB.putListObject("audioalldata", new ArrayList<>());


    }

    private void addadprer() {


        _rv_ciefile = findViewById(R.id._rv_ciefile);

        if (alldat.size() <= 0) {
            tv_nodatafound.setVisibility(View.VISIBLE);
        }


        VieDataAdapter = new AudioMulAdapter(AudioMustiplaActivity.this, alldat, new cuttetinter() {
            @Override
            public void datat(ArrayList<File> pathDAta2) {

                pathDAta = pathDAta2;


            }
        }, "converter");


        _rv_ciefile.setHasFixedSize(true);
        _rv_ciefile.setLayoutManager(new LinearLayoutManager(AudioMustiplaActivity.this));
        _rv_ciefile.setAdapter(VieDataAdapter);


    }

}

