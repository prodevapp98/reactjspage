package com.si_vidoditor.paras_viddaditorapp.formateconverter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.VieDataAdapter;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.cuttetinter;

import java.io.File;
import java.util.ArrayList;


public class VideoMultiPleActivity extends AppCompatActivity {


    private TinyDB tinyDB;
    private ArrayList<File> alldat;
    private RecyclerView _rv_ciefile;
    private ImageView imageView;
    private ArrayList<File> removlist = new ArrayList<>();
    private  String videoFormat= "mp4";
    private com.si_vidoditor.paras_viddaditorapp.videotoaudio.VieDataAdapter VieDataAdapter;
    private ConstraintLayout btSave;
    private TextView tv_nodatafound;
    private ArrayList<File> pathDAta = new ArrayList<>();
    private ImageView iv_gidelist;
    private ImageView bv_mp4, bv_3gp, bv_movv, bv_flv, bv_mkv, bv_avi, bv_m4u;




    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_ple_covert_activty_activty);

        iniData();

        tinyDB = new TinyDB(VideoMultiPleActivity.this);
        alldat = tinyDB.getListObject("videoalldata", File.class);

        iv_gidelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tinyDB.putListObject("videoalldata", new ArrayList<>());
                finish();



            }
        });

        BaseLayoutVidoEditor.showBannerOnce(this, findViewById(R.id.framSmall), findViewById(R.id.rlBanner));

        changeColor(R.color.home_top2s);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();


            }
        });


        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (pathDAta.size() > 0) {




                        new FormatevideoBackground(VideoMultiPleActivity.this,
                                pathDAta, videoFormat);





                }
                else
                {
                    Toast.makeText(
                            VideoMultiPleActivity.this, "Add at least one video", Toast.LENGTH_SHORT).show();
                }


            }
        });


        addadprer();


    }


    private void iniData() {


        bv_mp4 = findViewById(R.id.bv_mp4);
        bv_3gp = findViewById(R.id.bv_3gp);
        bv_movv = findViewById(R.id.bv_movv);
        bv_flv = findViewById(R.id.bv_flv);
        bv_mkv = findViewById(R.id.bv_mkv);
        bv_avi = findViewById(R.id.bv_avi);
        bv_m4u = findViewById(R.id.bv_m4u);


        bv_mp4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat= "mp4";

                bv_mp4.setImageResource(R.drawable.mp4);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.mp4_i);




            }
        });

        bv_3gp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat= "3gp";

                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.mp4_i);



            }
        });

        bv_movv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat= "mov";

                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.mp4_i);



            }
        });

        bv_flv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat= "flv";

                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.mp4_i);



            }
        });
        bv_mkv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat= "mkv";

                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.mp4_i);


            }
        });

        bv_avi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                videoFormat= "avi";
                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi);
                bv_m4u.setImageResource(R.drawable.mp4_i);


            }
        });

        bv_m4u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoFormat= "m4u";
                bv_mp4.setImageResource(R.drawable.mp4_i);
                bv_3gp.setImageResource(R.drawable.gp3_i);
                bv_movv.setImageResource(R.drawable.mov_i);
                bv_flv.setImageResource(R.drawable.flv_i);
                bv_mkv.setImageResource(R.drawable.mkv_i);
                bv_avi.setImageResource(R.drawable.avi_i);
                bv_m4u.setImageResource(R.drawable.m4u);




            }
        });







        iv_gidelist = findViewById(R.id.iv_gidelist);
        btSave = findViewById(R.id.btSave);
        tv_nodatafound = findViewById(R.id.tv_nodatafound);
        imageView = findViewById(R.id.imageView);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        tinyDB.putListObject("videoalldata", new ArrayList<>());


    }

    private void addadprer() {


        _rv_ciefile = findViewById(R.id._rv_ciefile);

        if (alldat.size() <= 0) {
            tv_nodatafound.setVisibility(View.VISIBLE);
        }

        Log.d("TAG", "addaddfprer:  vm="+alldat.size());
        VieDataAdapter = new VieDataAdapter(VideoMultiPleActivity.this, alldat, new cuttetinter() {
            @Override
            public void datat(ArrayList<File> pathDAta2) {

                pathDAta = pathDAta2;


            }
        }, "converter");


        _rv_ciefile.setHasFixedSize(true);
        _rv_ciefile.setLayoutManager(new LinearLayoutManager(VideoMultiPleActivity.this));
        _rv_ciefile.setAdapter(VieDataAdapter);


    }

}