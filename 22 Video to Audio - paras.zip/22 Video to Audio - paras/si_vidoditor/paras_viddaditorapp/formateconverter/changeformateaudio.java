package com.si_vidoditor.paras_viddaditorapp.formateconverter;


import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.outputfolder.UotPutAllActivity;
import java.io.File;
import java.util.ArrayList;





public class changeformateaudio {

    private MaterialDialog progressDialog;
    ArrayList<File> pathDAta;


    Dialog dialog2;
    private TextView tv_re;


    Activity activity;
    String videoFormat;

    int count =0;

    public changeformateaudio(Activity context2, ArrayList<File> inpotfilr, String videoFormat) {


        this.pathDAta = inpotfilr;
        this.activity = context2;
        this.videoFormat = videoFormat;
        new ExtractAudio().execute(new Void[0]);


    }




    @SuppressLint({"StaticFieldLeak"})
    private class ExtractAudio extends AsyncTask<Void, Void, Void> {
        private ExtractAudio() {
        }


        public void onPreExecute() {
            super.onPreExecute();



            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {


                    dialog2 = new Dialog(activity);
                    dialog2.setContentView(R.layout.loadercon_dialogtyry2);

                    tv_re = dialog2.findViewById(R.id.tv_re);



                    Window window2 = dialog2.getWindow();
                    WindowManager.LayoutParams wlp1 = window2.getAttributes();
                    window2.setAttributes(wlp1);
                    dialog2.setCancelable(false);

                    window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog2.show();


                }

            });


        }

        public Void doInBackground(Void... voidArr) {






            for (int i = 0; i < pathDAta.size(); i++) {






                File externalStorageDirectory = activity.getExternalFilesDir("");

                File file = new File(externalStorageDirectory.getAbsolutePath()

                        + "/" + activity.getString(R.string.app_name) + "/ChangeFormat");
                if (!file.exists()) {
                    file.mkdirs();
                }


                String name =pathDAta.get(i).getName() ;

                if(pathDAta.get(i).getName().contains(".")) {
                    if (pathDAta.get(i).getName().indexOf(".") > 0)
                        name = name.substring(0, name.lastIndexOf("."));
                }
                else
                {

                    name= name;
                }


                String mFinalPath = externalStorageDirectory.getAbsolutePath()
                        + "/" + activity.getString(R.string.app_name) + "/ChangeFormat/"
                        + name + "." + videoFormat;


                File inpotfilr = pathDAta.get(i);


                if (new File(mFinalPath).exists()) {



                    String mFinalPath2 = externalStorageDirectory.getAbsolutePath()
                            + "/" + activity.getString(R.string.app_name) + "/ChangeFormat/"
                            + name+System.currentTimeMillis() + "." + videoFormat;



                    String[] strArr =

                            {"-i",
                                    inpotfilr.getAbsolutePath(),
                                    mFinalPath2};



                    long executionId = FFmpeg.executeAsync(strArr, new ExecuteCallback() {

                        @Override
                        public void apply(final long executionId, final int returnCode) {
                            if (returnCode == RETURN_CODE_SUCCESS) {

                                count++;
                                if (count == pathDAta.size()) {

                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));


                                }

                            } else if (returnCode == RETURN_CODE_CANCEL) {

                                count++;


                                if (count == pathDAta.size()) {
                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));
                                }
                            } else {

                                count++;


                                if (count == pathDAta.size()) {
                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));
                                }
                            }

                        }
                    });





                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(mFinalPath)));
                    activity.sendBroadcast(intent);



                }
                else {


                    String[] strArr =

                            {"-i",
                                    inpotfilr.getAbsolutePath(),
                                    mFinalPath};






                    long executionId = FFmpeg.executeAsync(strArr, new ExecuteCallback() {

                        @Override
                        public void apply(final long executionId, final int returnCode) {
                            if (returnCode == RETURN_CODE_SUCCESS) {

                                count++;
                                if (count == pathDAta.size()) {

                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));


                                }

                            } else if (returnCode == RETURN_CODE_CANCEL) {

                                count++;


                                if (count == pathDAta.size()) {
                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));
                                }




                            } else {

                                count++;


                                if (count == pathDAta.size()) {
                                    dialog2.dismiss();
                                    activity.finish();
                                    activity.startActivity(new Intent(activity, UotPutAllActivity.class));
                                }

                            }

                        }
                    });



                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(mFinalPath)));
                    activity.sendBroadcast(intent);
                }


            }


            return null;
        }

        public void onPostExecute(Void r1) {
            super.onPostExecute(r1);


        }
    }



}
