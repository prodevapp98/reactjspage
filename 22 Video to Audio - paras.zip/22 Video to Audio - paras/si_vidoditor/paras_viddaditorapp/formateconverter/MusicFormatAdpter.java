package com.si_vidoditor.paras_viddaditorapp.formateconverter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.si_vidoditor.paras_viddaditorapp.R;

import com.si_vidoditor.paras_viddaditorapp.audiocutter.FilePAthdata2ex;

import com.si_vidoditor.paras_viddaditorapp.audiocutter.albumInfo;


import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class MusicFormatAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {

    private int currentPlayingPosition;
    private boolean flage = true;
    public Activity activity;
    private ArrayList<albumInfo> albu;
    private ArrayList<albumInfo> dup_items;
    private FilePAthdata2ex filePAthdata;
    private MediaPlayer mediaPlayer;
    private Handler handler;
    private MediaPlayer player;
    private Runnable updatePlayer;
    private ArrayList<File> pathDAta = new ArrayList<>();
    private holder playingHolder;
    private TextView noVideoLayout;


    public MusicFormatAdpter(Activity activity, ArrayList<albumInfo> albu, FilePAthdata2ex filePAthdata, TextView noVideoLayout) {

        this.activity = activity;
        this.albu = albu;
        this.dup_items = albu;
        this.filePAthdata = filePAthdata;
        this.currentPlayingPosition = -1;
this.noVideoLayout= noVideoLayout;
    }

    void playerPause(View v, File f) {
        if (player != null) {
            player.pause();
        }
        if (updatePlayer != null) {
            handler.removeCallbacks(updatePlayer);
            updatePlayer = null;
        }
        updatePlayerText(v, f);
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(this.activity);
        return new holder(from.inflate(R.layout.tt_item_formate_co, viewGroup, false));
    }


    public void onViewRecycled(holder holder) {
        super.onViewRecycled(holder);
        if (currentPlayingPosition == holder.getAdapterPosition()) {
            updateNonPlayingView(playingHolder);
            playingHolder = null;
        }
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") int i) {

        handler = new Handler();
        holder holder2 = (holder) viewHolder;
        holder2.pos = i;


        if (i == currentPlayingPosition) {
            playingHolder = holder2;
            updatePlayingView();
        } else {
            updateNonPlayingView(holder2);
        }


        File file = new File(albu.get(i).getPath());
        albumInfo documentInfo = albu.get(i);
        holder2.nameTxt.setText("" +file.getName().toString());

        long milliseconds = albu.get(i).getArt();





        String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(milliseconds)),
                        Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(milliseconds) % TimeUnit.HOURS.toMinutes(1)),
                        Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(milliseconds) % TimeUnit.MINUTES.toSeconds(1))});


        holder2.duration.setText("" + str);


        holder2.id_palypause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {





                if (i == currentPlayingPosition) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                    } else {
                        mediaPlayer.start();
                    }
                } else {
                    currentPlayingPosition = i;
                    if (mediaPlayer != null) {
                        if (null != playingHolder) {
                            updateNonPlayingView(playingHolder);
                        }
                        mediaPlayer.release();
                    }
                    playingHolder = holder2;
                    startMediaPlayer(new File(albu.get(currentPlayingPosition).getPath()));
                }
                updatePlayingView();

                filePAthdata.fitdat2(pathDAta,mediaPlayer,holder2.id_palypause);



            }
        });


        if (pathDAta.size() != 0) {
            if (pathDAta.contains(file)) {
                holder2.iv_selectioon1.setVisibility(View.VISIBLE);

                Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                holder2.nameTxt.setTypeface(typeface);

            } else {
                holder2.iv_selectioon1.setVisibility(View.GONE);

                Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                holder2.nameTxt.setTypeface(typeface);
            }

        } else {
            holder2.iv_selectioon1.setVisibility(View.GONE);

            Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
            holder2.nameTxt.setTypeface(typeface);
        }


        holder2.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (pathDAta.contains(file)) {
                    pathDAta.remove(file);
                    holder2.iv_selectioon1.setVisibility(View.GONE);

                    Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                    holder2.nameTxt.setTypeface(typeface);

                } else {
                    pathDAta.add(file);
                    holder2.iv_selectioon1.setVisibility(View.VISIBLE);

                    Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                    holder2.nameTxt.setTypeface(typeface);

                }


                filePAthdata.fitdat(pathDAta,mediaPlayer,holder2.id_palypause);

            }

        });


    }



    private void startMediaPlayer(File audioResId) {
        mediaPlayer = MediaPlayer.create(activity, Uri.fromFile(audioResId));
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                releaseMediaPlayer();
            }
        });
        mediaPlayer.start();
    }


    private void releaseMediaPlayer() {
        if (null != playingHolder) {
            updateNonPlayingView(playingHolder);
        }
        mediaPlayer.release();
        mediaPlayer = null;
        currentPlayingPosition = -1;
    }


    private void updateNonPlayingView(holder holder) {
        holder.id_palypause.setImageResource(R.drawable.play_converyt);
    }



    private void updatePlayingView() {

        if (mediaPlayer.isPlaying()) {

            playingHolder.id_palypause.setImageResource(R.drawable.pause_convert);
        }

        else {

            playingHolder.id_palypause.setImageResource(R.drawable.play_converyt);
        }
    }


    public Filter getFilter() {
        return new Filter() {
            public FilterResults performFiltering(CharSequence charSequence) {


                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    MusicFormatAdpter videoAdapter = MusicFormatAdpter.this;
                    List unused = videoAdapter.albu = videoAdapter.dup_items;
                } else {
                    ArrayList arrayList = new ArrayList();

                    for (albumInfo videoItem : MusicFormatAdpter.this.dup_items) {


                        if (videoItem.getName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(videoItem);
                        }
                    }
                    List unused2 = MusicFormatAdpter.this.albu = arrayList;


                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = MusicFormatAdpter.this.albu;
                return filterResults;


            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {

                List unused = MusicFormatAdpter.this.albu = (ArrayList<albumInfo>) filterResults.values;
                notifyDataSetChanged();
                if(albu.size()<=0)
                {
                    noVideoLayout.setVisibility(View.VISIBLE);
                }
                else

                {

                    noVideoLayout.setVisibility(View.GONE);
                }





            }
        };
    }

    boolean updatePlayerText(final View v, final File f) {
        ImageView i = (ImageView) v.findViewById(R.id.id_palypause);

        final boolean playing = player != null && player.isPlaying();

        i.setImageResource(playing ? R.drawable.pause_convert : R.drawable.play_converyt);


        int c = 0;


        if (player != null) {
            c = player.getCurrentPosition();
        }




        return playing;

    }


    void updatePlayerRun(final View v, final File f) {
        boolean playing = updatePlayerText(v, f);

        if (updatePlayer != null) {
            handler.removeCallbacks(updatePlayer);
            updatePlayer = null;
        }

        if (!playing) {
            return;
        }

        updatePlayer = new Runnable() {
            @Override
            public void run() {
                updatePlayerRun(v, f);
            }
        };
        handler.postDelayed(updatePlayer, 200);
    }


    void playerPlay(View v, File f) {
        if (player == null)
            player = MediaPlayer.create(activity, Uri.fromFile(f));
        if (player == null) {
            Toast.makeText(activity, R.string.file_not_found, Toast.LENGTH_SHORT).show();
            return;
        }
        player.start();

        updatePlayerRun(v, f);
    }

    public int getItemCount() {
        return this.albu.size();
    }

    class holder extends RecyclerView.ViewHolder {

        TextView nameTxt;

        int pos;
        TextView duration;
        ConstraintLayout linearLayout;
        ImageView thmImg;
        View playerBase;

        ImageView id_palypause;

        ImageView iv_selectioon1;

        holder(View view) {
            super(view);


            nameTxt = view.findViewById(R.id.name);
            duration = view.findViewById(R.id.duration);
            thmImg = view.findViewById(R.id.thmImg);
            id_palypause = view.findViewById(R.id.id_palypause);
            linearLayout = view.findViewById(R.id.card);
            iv_selectioon1 = view.findViewById(R.id.iv_selectioon1);


        }
    }
}
