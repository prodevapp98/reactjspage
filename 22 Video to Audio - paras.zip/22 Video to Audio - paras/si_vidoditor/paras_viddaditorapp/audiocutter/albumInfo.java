package com.si_vidoditor.paras_viddaditorapp.audiocutter;

public class albumInfo {

    private  String name;
    private  long art;
    private  String path;
    private  int id;



    public albumInfo(String name, long art, String path, int id) {

        this.name = name;
        this.art = art;
        this.path = path;
        this.id = id;



    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getArt() {
        return art;
    }

    public void setArt(long art) {
        this.art = art;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
