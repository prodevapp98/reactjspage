package com.si_vidoditor.paras_viddaditorapp.audiocutter;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.si_vidoditor.paras_viddaditorapp.outputfolder.RingToneVAultAdapter.getMimeType;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.afollestad.materialdialogs.MaterialDialog;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class OutputAudioTActivity extends AppCompatActivity implements Runnable {

    SeekBar seekBar;
    MediaPlayer mp = new MediaPlayer();
    String input;
    String output;
    String starttime;
    String endtime;
    String bitrate;
    private ImageView imageView;
    private Dialog dialog2;
    private Bitmap bitmaoAll = null;
    private ImageView iv_shoa;
    private TextView name_s, size_s;
    ImageView iv_playpause;
    private TextView tv_totyal;
    TextView seekBarHint;

    private DataProccessor dataProccessor;
    private ConstraintLayout btn_setac, cl_share, id_openwith;

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }


    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID},
                MediaStore.Audio.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));


            cursor.close();
            return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            return null;

        }


    }


    private void startActivity(Intent intent, @StringRes int resId) {
        try {
            startActivity(intent);
        } catch (Exception e) {

        }
    }

    private Intent shareSingleIntent(Uri uri, String type) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        return intent;
    }

    private boolean isResolvable(Intent intent) {
        PackageManager manager = getPackageManager();
        List<ResolveInfo> resolveInfo = manager.queryIntentActivities(intent, 0);

        return !resolveInfo.isEmpty();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mp != null) {

            if (mp.isPlaying()) {

                iv_playpause.setImageResource(R.drawable.play_acut);
                mp.pause();
            }
        }

    }

    public Uri uri(Context context, File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                return FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", file);
            } catch (Exception e) {
                return Uri.fromFile(file);
            }
        } else {
            return Uri.fromFile(file);
        }
    }


    public static MaterialDialog showDialog(Context context) {

        return new MaterialDialog.Builder(context)
                .backgroundColorRes(R.color.home_top5s)
                .title(R.string.dialog_ringtone_title)
                .titleColor(ContextCompat.getColor(context, R.color.black))
                .content(R.string.dialog_ringtone_message)
                .contentColor(ContextCompat.getColor(context, R.color.black))
                .positiveText(android.R.string.ok)
                .positiveColor(ContextCompat.getColor(context, R.color.thm_5))
                .negativeText(android.R.string.cancel)
                .negativeColor(ContextCompat.getColor(context, R.color.thm_5))
                .onPositive((dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    context.startActivity(intent);
                })
                .show();


    }

    public static boolean requiresDialog(@NonNull Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return !Settings.System.canWrite(context);
        }
        return false;
    }

    private void shareSingle(File fileInfo) {
        try {
            String type = "audio/*";
            Intent intent = shareSingleIntent(uri(OutputAudioTActivity.this, fileInfo), type);

            if (isResolvable(intent)) {
                startActivity(intent, R.string.shareFile_unable);
            } else {
                Toast.makeText(OutputAudioTActivity.this, R.string.shareFile_unable, Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {

        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clearMediaPlayer();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uou_put_trimimg_activty2);

        changeColor(R.color.home_top5s);
        dataProccessor = new DataProccessor(OutputAudioTActivity.this);


        iv_shoa = findViewById(R.id.thumb);
        iv_playpause = findViewById(R.id.iv_playpause);
        seekBar = findViewById(R.id.sv_view);
        seekBarHint = findViewById(R.id.seekBarHint);
        tv_totyal = findViewById(R.id.tv_totyal);


        imageView = findViewById(R.id.imageView);
        name_s = findViewById(R.id.name);
        size_s = findViewById(R.id.size);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        BaseLayoutVidoEditor.showNativeOnce(this, findViewById(R.id.framLarge), findViewById(R.id.rlNative) );

        btn_setac = findViewById(R.id.btn_setac);
        cl_share = findViewById(R.id.cl_share);
        id_openwith = findViewById(R.id.id_openwith);


        id_openwith.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {
                    if (mp.isPlaying()) {
                        iv_playpause.setImageResource(R.drawable.play_acut);
                        mp.pause();
                    }
                }


                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setFlags(335544320);
                if (Build.VERSION.SDK_INT >= 22) {
                    intent.setDataAndType(FileProvider.getUriForFile(OutputAudioTActivity.this, getPackageName()
                            + ".provider", new File(output)), "audio/*");
                } else {
                    intent.setDataAndType(Uri.fromFile(new File(output)), "audio/*");
                }
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, 100);


            }
        });
        cl_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {
                    if (mp.isPlaying()) {
                        iv_playpause.setImageResource(R.drawable.play_acut);
                        mp.pause();
                    }
                }

                shareSingle(new File(output));


            }
        });
        btn_setac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {
                    if (mp.isPlaying()) {
                        iv_playpause.setImageResource(R.drawable.play_acut);
                        mp.pause();
                    }
                }

                Dialog dialog2 = new Dialog(OutputAudioTActivity.this);
                dialog2.setContentView(R.layout.ringtone_dialog);


                ImageView cancel = dialog2.findViewById(R.id.cancel);


                ImageView iv_3 = dialog2.findViewById(R.id.iv_3);
                ImageView iv_2 = dialog2.findViewById(R.id.iv_2);
                ImageView iv_1 = dialog2.findViewById(R.id.iv_1);


                TextView textView15 = dialog2.findViewById(R.id.textView15);
                TextView textView16 = dialog2.findViewById(R.id.textView16);
                TextView textView7 = dialog2.findViewById(R.id.textView7);
                TextView cv_te = dialog2.findViewById(R.id.cv_te);
                TextView tag_te = dialog2.findViewById(R.id.tag_te);


                textView15.setTextColor(getResources().getColor(R.color.thm_5));
                textView16.setTextColor(getResources().getColor(R.color.thm_5));
                textView7.setTextColor(getResources().getColor(R.color.thm_5));
                cv_te.setTextColor(getResources().getColor(R.color.thm_5));
                tag_te.setTextColor(getResources().getColor(R.color.thm_5));
                cancel.setImageResource(R.drawable.cancel_aucut);


                iv_1.setImageResource(R.drawable.ringtone_t2);
                iv_2.setImageResource(R.drawable.set_as_ac);
                iv_3.setImageResource(R.drawable.alarm_3);


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                    }
                });

                ConstraintLayout cl_rintone = dialog2.findViewById(R.id.cl_rintone);
                ConstraintLayout cl_noti = dialog2.findViewById(R.id.cl_noti);
                ConstraintLayout cl_alarm = dialog2.findViewById(R.id.cl_alarm);


                cl_rintone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                        if (requiresDialog(OutputAudioTActivity.this)) {
                            showDialog(OutputAudioTActivity.this);


                        } else {


                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, output);
                                values.put(MediaStore.MediaColumns.TITLE, new File(output).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(output));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                                values.put(MediaStore.Audio.Media.IS_ALARM, false);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);



                                Uri newUri = getImageContentUri(OutputAudioTActivity.this, new File(output));

                                android.media.RingtoneManager.setActualDefaultRingtoneUri(OutputAudioTActivity.this,
                                        RingtoneManager.TYPE_RINGTONE,
                                        newUri);




                                dataProccessor.setStr("ringtone", new File(output).getName());

                                Toast.makeText(OutputAudioTActivity.this, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();



                            }



                            else {


                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputAudioTActivity.this, new File(output));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {

                                    Settings.System.putString(resolver, Settings.System.RINGTONE, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("ringtone", new File(output).getName());

                                Toast.makeText(OutputAudioTActivity.this, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();

                            }

                        }
                    }
                });

                cl_noti.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                        if (requiresDialog(OutputAudioTActivity.this)) {
                            showDialog(OutputAudioTActivity.this);


                        } else {

                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, output);
                                values.put(MediaStore.MediaColumns.TITLE, new File(output).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(output));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, true);
                                values.put(MediaStore.Audio.Media.IS_ALARM, false);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);

                                Uri newUri = getImageContentUri(OutputAudioTActivity.this, new File(output));
                                android.media.RingtoneManager.setActualDefaultRingtoneUri(OutputAudioTActivity.this,
                                        RingtoneManager.TYPE_NOTIFICATION,
                                        newUri);





                                dataProccessor.setStr("notification", new File(output).getName());

                                Toast.makeText(OutputAudioTActivity.this, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();

                            }


                            else {


                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputAudioTActivity.this, new File(output));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {
                                    Settings.System.putString(resolver, Settings.System.NOTIFICATION_SOUND, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("notification", new File(output).getName());

                                Toast.makeText(OutputAudioTActivity.this, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();

                            }

                        }
                    }
                });
                cl_alarm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();
                        if (requiresDialog(OutputAudioTActivity.this)) {
                            showDialog(OutputAudioTActivity.this);


                        } else {

                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, output);
                                values.put(MediaStore.MediaColumns.TITLE, new File(output).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(output));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                                values.put(MediaStore.Audio.Media.IS_ALARM, true);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);



                                Uri newUri = getImageContentUri(OutputAudioTActivity.this, new File(output));
                                android.media.RingtoneManager.setActualDefaultRingtoneUri(OutputAudioTActivity.this,
                                        RingtoneManager.TYPE_ALARM,
                                        newUri);



                                dataProccessor.setStr("alarm", new File(output).getName());


                                Toast.makeText(OutputAudioTActivity.this, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();

                            }




                            else {
                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputAudioTActivity.this, new File(output));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {

                                    Settings.System.putString(resolver, Settings.System.ALARM_ALERT, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("alarm", new File(output).getName());


                                Toast.makeText(OutputAudioTActivity.this, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();

                            }

                        }
                    }
                });


                Window window2 = dialog2.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog2.setCancelable(false);

                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog2.show();


            }
        });


        if (getIntent().getStringExtra("type").equals("cut")) {


            input = getIntent().getStringExtra("input");
            output = getIntent().getStringExtra("output");
            double starttime = getIntent().getDoubleExtra("starttime", 0);
            double endtime = getIntent().getDoubleExtra("endtime", 0);
            bitrate = getIntent().getStringExtra("bitrate");


            new CutAudioBackground(
                    OutputAudioTActivity.this,
                    input,
                    output,
                    starttime, endtime, bitrate);


        } else {


            input = getIntent().getStringExtra("input");
            output = getIntent().getStringExtra("output");
            starttime = getIntent().getStringExtra("starttime");
            endtime = getIntent().getStringExtra("endtime");
            bitrate = getIntent().getStringExtra("bitrate");


            new TrimAudioBackground(OutputAudioTActivity.this,
                    input, output,
                    starttime, endtime, bitrate);


        }


        iv_playpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                try {

                    if (mp == null) {
                        mp = new MediaPlayer();
                        mp.setDataSource(output);
                        mp.prepare();
                        mp.setVolume(0.5f, 0.5f);
                        mp.setLooping(false);
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }




                if (mp.isPlaying()) {
                    iv_playpause.setImageResource(R.drawable.play_acut);
                    mp.pause();


                } else {

                    iv_playpause.setImageResource(R.drawable.pause_cut);

                    mp.start();
                    seekBar.setMax(mp.getDuration());
                    new Thread(OutputAudioTActivity.this).start();


                }


            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

                seekBarHint.setVisibility(View.VISIBLE);
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {
                seekBarHint.setVisibility(View.VISIBLE);


                int x = (int) Math.ceil(progress / 1000f);


                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                seekBarHint.setText("" + str);


                if (x == (int) Math.ceil(seekBar.getMax() / 1000f) && mp != null && !mp.isPlaying()) {


                    iv_playpause.setImageResource(R.drawable.play_acut);
                    clearMediaPlayer();
                    seekBar.setProgress(0);


                }


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {


                if (mp != null && mp.isPlaying()) {
                    mp.seekTo(seekBar.getProgress());
                }
            }
        });

    }

    private void clearMediaPlayer() {
        if (mp != null) {
            mp.stop();
            mp.release();
            mp = null;
        }
    }


    public void run() {

        int currentPosition = mp.getCurrentPosition();
        int total = mp.getDuration();


        while (mp != null && mp.isPlaying() && currentPosition < total) {
            try {
                Thread.sleep(1000);
                currentPosition = mp.getCurrentPosition();
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                return;
            }

            seekBar.setProgress(currentPosition);

        }
    }


    public static Bitmap uriToBitmap(Uri selectedFileUri, Context context) {
        Bitmap image = null;

        try {
            ParcelFileDescriptor parcelFileDescriptor = context.getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }


    public class TrimAudioBackground {

        String inpotfilr;
        String outpiutfile;
        String starttime;
        String endtime;
        Dialog dialog2;
        Activity activity;
        private TextView tv_re;

        private String bitrate;


        public TrimAudioBackground(Activity activity, String inpotfilr, String outpiutfile, String starttimea, String endtimea, String bit) {

            this.inpotfilr = inpotfilr;
            this.outpiutfile = outpiutfile;
            this.starttime = starttimea;
            this.endtime = endtimea;
            this.activity = activity;
            this.bitrate = bit;

            new TrimAudioBackground.ExtractAudio().execute(new Void[0]);





        }





        @SuppressLint({"StaticFieldLeak"})
        private class ExtractAudio extends AsyncTask<Void, Void, Void> {
            private ExtractAudio() {
            }


            public void onPreExecute() {
                super.onPreExecute();

                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        dialog2 = new Dialog(activity);
                        dialog2.setContentView(R.layout.loadercon_dialog2);
                        tv_re = dialog2.findViewById(R.id.tv_re);

                        Window window2 = dialog2.getWindow();
                        WindowManager.LayoutParams wlp1 = window2.getAttributes();
                        window2.setAttributes(wlp1);
                        dialog2.setCancelable(false);


                        TextView tv_re = dialog2.findViewById(R.id.tv_re);
                        ProgressBar progressBar = dialog2.findViewById(R.id.progressBar);

                        tv_re.setTextColor(activity.getResources().getColor(R.color.thm_5));
                        progressBar.setIndeterminateTintList(ColorStateList.valueOf(activity.getResources().getColor(R.color.thm_5)));


                        window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        dialog2.show();


                    }

                });


            }

            public Void doInBackground(Void... voidArr) {







                String a = "" + starttime + "," + endtime;


                String[] strArr = {"-y", "-i", inpotfilr, "-ss",
                        starttime,
                        "-t", "" + endtime + ".0",
                        "-b:a",
                        bitrate,
                        outpiutfile};



                long executionId = FFmpeg.executeAsync(strArr, new ExecuteCallback() {

                    @Override
                    public void apply(final long executionId, final int returnCode) {
                        if (returnCode == RETURN_CODE_SUCCESS) {


                            dialog2.dismiss();
                            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent.setData(Uri.fromFile(new File(output)));
                            sendBroadcast(intent);


                            try {

                                mp.setDataSource(output);
                                mp.prepare();
                                mp.setVolume(0.5f, 0.5f);
                                mp.setLooping(false);


                                long progress = mp.getDuration();
                                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                                tv_totyal.setText("" + str);
                                size_s.setText("" + str);


                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            name_s.setText("" + new File(output).getName());


                        } else if (returnCode == RETURN_CODE_CANCEL) {
                            dialog2.dismiss();

                        } else {
                            dialog2.dismiss();

                        }

                    }
                });


                return null;
            }

            public void onPostExecute(Void r1) {
                super.onPostExecute(r1);





            }
        }







    }


    public class CutAudioBackground {


        private String inpotfilr;
        private String outpiutfile;
        private int starttime;
        private int endtime;
        private Dialog dialog2;
        private Activity activity;

        private TextView tv_re;
        private String bitrate;


        public CutAudioBackground(Activity activity, String inpotfilr, String outpiutfile, double starttimea, double endtimea, String bit) {

            this.inpotfilr = inpotfilr;
            this.outpiutfile = outpiutfile;
            this.starttime = (int) starttimea;
            this.endtime = (int) endtimea;
            this.activity = activity;
            this.bitrate = bit;


            new CutAudioBackground.ExtractAudio().execute(new Void[0]);


        }



        @SuppressLint({"StaticFieldLeak"})
        private class ExtractAudio extends AsyncTask<Void, Void, Void> {
            private ExtractAudio() {
            }


            public void onPreExecute() {
                super.onPreExecute();

                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dialog2 = new Dialog(activity);
                        dialog2.setContentView(R.layout.loadercon_dialog2);
                        tv_re = dialog2.findViewById(R.id.tv_re);

                        Window window2 = dialog2.getWindow();
                        WindowManager.LayoutParams wlp1 = window2.getAttributes();
                        window2.setAttributes(wlp1);
                        dialog2.setCancelable(false);

                        window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        dialog2.show();


                    }

                });


            }

            public Void doInBackground(Void... voidArr) {








                String a = "" + starttime + "," + endtime;


                String[] strArr =
                        {"-i", inpotfilr,
                                "-af", "aselect='not(between(t," + a + "))',asetpts=N/SR/TB",
                                "-b:a",
                                bitrate,
                                outpiutfile};


                long executionId = FFmpeg.executeAsync(strArr, new ExecuteCallback() {

                    @Override
                    public void apply(final long executionId, final int returnCode) {
                        if (returnCode == RETURN_CODE_SUCCESS) {


                            dialog2.dismiss();
                            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent.setData(Uri.fromFile(new File(output)));
                            sendBroadcast(intent);


                            try {

                                mp.setDataSource(output);
                                mp.prepare();
                                mp.setVolume(0.5f, 0.5f);
                                mp.setLooping(false);


                                long progress = mp.getDuration();
                                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                                tv_totyal.setText("" + str);
                                size_s.setText("" + str);


                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            name_s.setText("" + new File(output).getName());


                        } else if (returnCode == RETURN_CODE_CANCEL) {
                            dialog2.dismiss();

                        } else {
                            dialog2.dismiss();

                        }

                    }
                });


                return null;
            }

            public void onPostExecute(Void r1) {
                super.onPostExecute(r1);


            }
        }


    }


}