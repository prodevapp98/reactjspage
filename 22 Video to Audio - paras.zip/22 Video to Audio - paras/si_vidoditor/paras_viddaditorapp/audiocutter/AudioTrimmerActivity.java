//  The MIT License (MIT)

//  Copyright (c) 2018 Intuz Pvt Ltd.

//  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files
//  (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify,
//  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:

//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
//  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package com.si_vidoditor.paras_viddaditorapp.audiocutter;


import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.customAudioViews.MarkerView;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.customAudioViews.SamplePlayer;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.customAudioViews.SoundFile;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.customAudioViews.WaveformView;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


public class AudioTrimmerActivity extends AppCompatActivity implements View.OnClickListener,
        MarkerView.MarkerListener,
        WaveformView.WaveformListener {

    int duration;
    private TextView txtAudioCancele;
    private TextView txtStartPosition;
    private TextView txtStartPosition1;

    private TextView textView12, textView13;

    private float plus_start;

    private TextView txtEndPosition;
    private TextView txtEndPosition1;

    private MarkerView markerStart;
    private MarkerView markerEnd;
    private WaveformView audioWaveform;

    private ImageView txtAudioDone;
    private ImageView txtAudioPlay;
    private boolean isAudioRecording = false;
    private long mRecordingLastUpdateTime;
    private double mRecordingTime;
    private boolean mRecordingKeepGoing;
    private SoundFile mLoadedSoundFile;
    private SoundFile mRecordedSoundFile;
    private SamplePlayer mPlayer;
    private Handler mHandler;
    private boolean mTouchDragging;
    private float mTouchStart;
    private int mTouchInitialOffset;
    private int mTouchInitialStartPos;
    private int mTouchInitialEndPos;
    private float mDensity;
    private int mMarkerLeftInset;
    private int mMarkerRightInset;
    private int mMarkerTopOffset;
    private int mMarkerBottomOffset;
    private int mTextLeftInset;
    private int mTextRightInset;
    private int mTextTopOffset;
    private int mTextBottomOffset;

    private int mOffset;
    private int mOffsetGoal;
    private int mFlingVelocity;
    private int mPlayEndMillSec;
    private int mWidth;
    private int mMaxPos;
    private int mStartPos;
    private int mEndPos;

    private boolean mStartVisible;
    private boolean mEndVisible;
    private int mLastDisplayedStartPos;
    private int mLastDisplayedEndPos;
    private boolean mIsPlaying = false;
    private boolean mKeyDown;
    private Dialog mProgressDialog;
    private long mLoadingLastUpdateTime;
    private boolean mLoadingKeepGoing;
    private File mFile;

    File file;
    String path;
    private ProgressBar pb_load;

    private ConstraintLayout cl_all;
    private TextView textView;
    private TextView tv_total;

    private CardView cv_pro;


    private boolean trimshow;
    private ImageView bv_trim, bv_cut, bv_zoomin, bv_zooout;

    private ImageView imageView5, imageView4;
    private ImageView imageView52, imageView42;

    private ImageView imageView;


    public AudioTrimmerActivity() {
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_trim);
        changeColor(R.color.home_top5s);
        trimshow = true;

        mHandler = new Handler();
        imageView = findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });


        imageView5 = findViewById(R.id.imageView5);
        imageView4 = findViewById(R.id.imageView4);
        imageView52 = findViewById(R.id.imageView52);
        imageView42 = findViewById(R.id.imageView42);


        cl_all = findViewById(R.id.cl_all);
        tv_total = findViewById(R.id.tv_total);
        tv_total = findViewById(R.id.tv_total);

        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(AudioTrimmerActivity.this, admobBanner,cardBAnner);

        txtStartPosition = findViewById(R.id.txtStartPosition);
        txtStartPosition1 = findViewById(R.id.txtStartPosition1);


        pb_load = findViewById(R.id.pb_load);
        cv_pro = findViewById(R.id.cv_pro);
        txtEndPosition = findViewById(R.id.txtEndPosition);
        txtEndPosition1 = findViewById(R.id.txtEndPosition1);
        textView12 = findViewById(R.id.textView12);


        markerStart = findViewById(R.id.markerStart);
        markerEnd = findViewById(R.id.markerEnd);
        audioWaveform = findViewById(R.id.audioWaveform);


        txtAudioDone = findViewById(R.id.llAudioBottom);


        txtAudioPlay = findViewById(R.id.txtAudioPlay);


        txtAudioDone.setClickable(false);
        txtAudioDone.setEnabled(false);

        txtAudioPlay.setClickable(false);
        txtAudioPlay.setEnabled(false);




        mRecordedSoundFile = null;
        mKeyDown = false;
        audioWaveform.setListener(this);

        markerStart.setListener(this);
        markerStart.setAlpha(1f);
        markerStart.setFocusable(true);
        markerStart.setFocusableInTouchMode(true);
        mStartVisible = true;

        markerEnd.setListener(this);
        markerEnd.setAlpha(1f);
        markerEnd.setFocusable(true);
        markerEnd.setFocusableInTouchMode(true);
        mEndVisible = true;

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mDensity = metrics.density;

        /**
         * Change this for marker handle as per your view
         */
        mMarkerLeftInset = (int) (17.5 * mDensity);
        mMarkerRightInset = (int) (19.5 * mDensity);
        mMarkerTopOffset = (int) (6 * mDensity);
        mMarkerBottomOffset = (int) (6 * mDensity);

        /**
         * Change this for duration text as per your view
         */

        mTextLeftInset = (int) (20 * mDensity);
        mTextTopOffset = (int) (-1 * mDensity);
        mTextRightInset = (int) (19 * mDensity);
        mTextBottomOffset = (int) (-40 * mDensity);


        txtAudioDone.setOnClickListener(this);
        txtAudioPlay.setOnClickListener(this);


        mHandler.postDelayed(mTimerRunnable, 100);


        isAudioRecording = true;


        startRecording();


        mRecordingLastUpdateTime = Utility.getCurrentTime();
        mRecordingKeepGoing = true;

        path = getIntent().getStringExtra("path");
        file = new File(path);


        bv_trim = findViewById(R.id.bv_trim);
        bv_cut = findViewById(R.id.bv_cut);
        bv_zoomin = findViewById(R.id.bv_zoomin);
        bv_zooout = findViewById(R.id.bv_zooout);


        bv_trim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                bv_trim.setImageResource(R.drawable.trim_audio);
                bv_cut.setImageResource(R.drawable.cut_audio);


                audioWaveform.changeSelecolot();
                trimshow = true;


            }
        });


        bv_cut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bv_trim.setImageResource(R.drawable.trim_audio_i);
                bv_cut.setImageResource(R.drawable.cut_audio_i);


                audioWaveform.changeSelecolo2();
                trimshow = false;


            }
        });


        bv_zoomin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                audioWaveform.zoomIn();

            }
        });

        bv_zooout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                audioWaveform.zoomOut();

            }
        });


        imageView5.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {


                plus_start = plus_start + 10;

                mStartPos = trap((int) (mTouchInitialStartPos + plus_start));
                mEndPos = trap((int) (mTouchInitialEndPos + plus_start));
                updateDisplay();
                markerTouchEnd(markerStart);


            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                plus_start = plus_start - 10;

                mStartPos = trap((int) (mTouchInitialStartPos + plus_start));
                mEndPos = trap((int) (mTouchInitialEndPos + plus_start));
                updateDisplay();
                markerTouchEnd(markerStart);


            }
        });

        imageView52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plus_start = plus_start + 10;
                mEndPos = trap((int) (mTouchInitialEndPos + plus_start));
                if (mEndPos < mStartPos)
                    mEndPos = mStartPos;

                updateDisplay();
                markerTouchEnd(markerStart);


            }
        });

        imageView42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plus_start = plus_start - 10;
                mEndPos = trap((int) (mTouchInitialEndPos + plus_start));
                if (mEndPos < mStartPos)
                    mEndPos = mStartPos;

                updateDisplay();
                markerTouchEnd(markerStart);

            }
        });


    }


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }


    private Runnable mTimerRunnable = new Runnable() {
        public void run() {


            int totaltime = mEndPos - mStartPos;

            if (mStartPos != mLastDisplayedStartPos) {
                txtStartPosition.setText(formatTime(mStartPos));
                txtStartPosition1.setText(formatTime(mStartPos));
                mLastDisplayedStartPos = mStartPos;
            }

            if (mEndPos != mLastDisplayedEndPos) {
                txtEndPosition.setText(formatTime(mEndPos));
                txtEndPosition1.setText(formatTime(mEndPos));
                mLastDisplayedEndPos = mEndPos;
            }

            tv_total.setText("" + formatTime(totaltime));
            mHandler.postDelayed(mTimerRunnable, 100);


        }
    };


    @Override
    public void onClick(View view) {


        if (view == txtAudioPlay) {


            if (!mIsPlaying) {
                txtAudioPlay.setImageResource(R.drawable.pause_big);
            } else {
                txtAudioPlay.setImageResource(R.drawable.play_big);
            }


            onPlay(mStartPos);
        } else if (view == txtAudioDone) {

            if (tv_total.getText().toString().equals("00:00:00")) {
                Toast.makeText(AudioTrimmerActivity.this, "Please select your video portion!", Toast.LENGTH_SHORT).show();
                return;
            }


            if (trimshow) {


                final Dialog dialog = new Dialog(AudioTrimmerActivity.this);

                dialog.setContentView(R.layout.audio_tag_layout);
                Window window2 = dialog.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog.setCancelable(false);
                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


                Spinner spinner_audioformat = dialog.findViewById(R.id.spinner_audioformat);
                Spinner spinner_bitrate = dialog.findViewById(R.id.spinner_bitrate);

                EditText et_title = dialog.findViewById(R.id.et_title);
                ImageView cancel = dialog.findViewById(R.id.cancel);
                ImageView ok = dialog.findViewById(R.id.ok);

                final String[] audioFormat = {"mp3"};
                final String[] bitrate = {"default"};


                spinner_audioformat.setSelection(0);
                final ArrayList[] arrayList = {new ArrayList()};
                arrayList[0].add("mp3");
                arrayList[0].add("aac");
                arrayList[0].add("wav");

                ArrayAdapter arrayAdapter = new ArrayAdapter(AudioTrimmerActivity.this, R.layout.vector_layputac2, arrayList[0]);
                arrayAdapter.setDropDownViewResource(R.layout.vector_layputac3);

                spinner_audioformat.setAdapter((SpinnerAdapter) arrayAdapter);
                spinner_bitrate.setSelection(0);
                ArrayList arrayList2 = new ArrayList();

                arrayList2.add("default");
                arrayList2.add("128k");
                arrayList2.add("160k");
                arrayList2.add("192k");
                arrayList2.add("220k");
                arrayList2.add("280k");
                arrayList2.add("320k");


                @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                        R.layout.vector_layputac2, arrayList2);
                arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                spinner_audioformat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                        audioFormat[0] = adapterView.getItemAtPosition(i).toString();

                        if (audioFormat[0].equals("aac")) {
                            arrayList2.clear();
                            arrayList2.add("default");
                            @SuppressLint("ResourceType")
                            ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                                    R.layout.vector_layputac2, arrayList2);
                            arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                            spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                        } else {
                            arrayList2.clear();

                            arrayList2.add("default");
                            arrayList2.add("128k");
                            arrayList2.add("160k");
                            arrayList2.add("192k");
                            arrayList2.add("220k");
                            arrayList2.add("280k");
                            arrayList2.add("320k");

                            @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                                    R.layout.vector_layputac2, arrayList2);
                            arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                            spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                        }


                    }
                });


                spinner_bitrate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {


                        bitrate[0] = adapterView.getItemAtPosition(i).toString();


                    }
                });


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (et_title.getText().toString().trim().length() > 0) {

                            String specialCharactersString = "!@#$%&*()'+,-./:;<=>?[]^`{|}";
                            for (int i = 0; i < et_title.getText().toString().length(); i++) {
                                char ch = et_title.getText().toString().charAt(i);
                                if (specialCharactersString.contains(Character.toString(ch))) {

                                    Toast.makeText(AudioTrimmerActivity.this, "Please Enter Valid File Name.", Toast.LENGTH_SHORT).show();
                                    return;

                                }

                            }
                            File externalStorageDirectory =getExternalFilesDir("");
                            File file = new File(externalStorageDirectory.getAbsolutePath()

                                    + "/" + getString(R.string.app_name) + "/AudioTrimmer");
                            if (!file.exists()) {
                                file.mkdirs();
                            }


                            String filename = et_title.getText().toString();


                            String mFinalPath = externalStorageDirectory.getAbsolutePath()
                                    + "/" + getString(R.string.app_name) + "/AudioTrimmer/"
                                    + filename + "." + audioFormat[0];


                            if (new File(mFinalPath).exists()) {


                                Toast.makeText(AudioTrimmerActivity.this, getResources().getString(R.string.error_file_exist), Toast.LENGTH_SHORT).show();
                                return;


                            } else {


                                dialog.dismiss();
                                double startTime = audioWaveform.pixelsToSeconds(mStartPos);
                                double endTime = audioWaveform.pixelsToSeconds(mEndPos);


                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(AudioTrimmerActivity.this, msg -> {
                                    Intent intent = new Intent(AudioTrimmerActivity.this, OutputAudioTActivity.class);

                                    intent.putExtra("input", new File(path).getAbsolutePath());
                                    intent.putExtra("output", mFinalPath);
                                    intent.putExtra("starttime", txtStartPosition1.getText().toString());
                                    intent.putExtra("endtime", tv_total.getText().toString());
                                    intent.putExtra("bitrate", bitrate[0]);
                                    intent.putExtra("type", "trim");

                                    startActivity(intent);
                                });






                            }
                        } else {
                            Toast.makeText(AudioTrimmerActivity.this, "Enter File name!", Toast.LENGTH_SHORT).show();
                            return;


                        }


                    }
                });




            } else {


                //TODO for cutt


                final Dialog dialog = new Dialog(AudioTrimmerActivity.this);

                dialog.setContentView(R.layout.audio_tag_layout);
                Window window2 = dialog.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog.setCancelable(false);
                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


                Spinner spinner_audioformat = dialog.findViewById(R.id.spinner_audioformat);
                Spinner spinner_bitrate = dialog.findViewById(R.id.spinner_bitrate);

                EditText et_title = dialog.findViewById(R.id.et_title);
                ImageView cancel = dialog.findViewById(R.id.cancel);
                ImageView ok = dialog.findViewById(R.id.ok);

                final String[] audioFormat = {"mp3"};
                final String[] bitrate = {"default"};


                spinner_audioformat.setSelection(0);
                final ArrayList[] arrayList = {new ArrayList()};
                arrayList[0].add("mp3");
                arrayList[0].add("aac");

                arrayList[0].add("wav");

                ArrayAdapter arrayAdapter = new ArrayAdapter(AudioTrimmerActivity.this, R.layout.vector_layputac2, arrayList[0]);
                arrayAdapter.setDropDownViewResource(R.layout.vector_layputac3);

                spinner_audioformat.setAdapter((SpinnerAdapter) arrayAdapter);
                spinner_bitrate.setSelection(0);
                ArrayList arrayList2 = new ArrayList();

                arrayList2.add("default");
                arrayList2.add("128k");
                arrayList2.add("160k");
                arrayList2.add("192k");
                arrayList2.add("220k");
                arrayList2.add("280k");
                arrayList2.add("320k");


                @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                        R.layout.vector_layputac2, arrayList2);
                arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                spinner_audioformat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                        audioFormat[0] = adapterView.getItemAtPosition(i).toString();

                        if (audioFormat[0].equals("aac")) {
                            arrayList2.clear();
                            arrayList2.add("default");
                            @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                                    R.layout.vector_layputac2, arrayList2);
                            arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                            spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                        } else {
                            arrayList2.clear();

                            arrayList2.add("default");
                            arrayList2.add("128k");
                            arrayList2.add("160k");
                            arrayList2.add("192k");
                            arrayList2.add("220k");
                            arrayList2.add("280k");
                            arrayList2.add("320k");

                            @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(AudioTrimmerActivity.this,
                                    R.layout.vector_layputac2, arrayList2);
                            arrayAdapter2.setDropDownViewResource(R.layout.vector_layputac3);
                            spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


                        }


                    }
                });


                spinner_bitrate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {


                        bitrate[0] = adapterView.getItemAtPosition(i).toString();


                    }
                });


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (et_title.getText().toString().trim().length() > 0) {


                            File externalStorageDirectory =getExternalFilesDir("");;
                            File file = new File(externalStorageDirectory.getAbsolutePath()

                                    + "/" + getString(R.string.app_name) + "/AudioCutter");
                            if (!file.exists()) {
                                file.mkdirs();
                            }


                            String filename = et_title.getText().toString();


                            String mFinalPath = externalStorageDirectory.getAbsolutePath()
                                    + "/" + getString(R.string.app_name) + "/AudioCutter/"
                                    + filename + "." + audioFormat[0];


                            if (new File(mFinalPath).exists()) {


                                Toast.makeText(AudioTrimmerActivity.this, getResources().getString(R.string.error_file_exist), Toast.LENGTH_SHORT).show();
                                return;


                            } else {
                                dialog.dismiss();
                                double startTime = audioWaveform.pixelsToSeconds(mStartPos);
                                double endTime = audioWaveform.pixelsToSeconds(mEndPos);


                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(AudioTrimmerActivity.this, msg -> {
                                    Intent intent = new Intent(AudioTrimmerActivity.this, OutputAudioTActivity.class);

                                    intent.putExtra("input", new File(path).getAbsolutePath());
                                    intent.putExtra("output", mFinalPath);
                                    intent.putExtra("starttime", startTime);
                                    intent.putExtra("endtime", endTime);
                                    intent.putExtra("bitrate", bitrate[0]);
                                    intent.putExtra("type", "cut");
                                    startActivity(intent);
                                });









                            }
                        } else {
                            Toast.makeText(AudioTrimmerActivity.this, "Enter File name!", Toast.LENGTH_SHORT).show();
                            return;


                        }


                    }
                });



            }


        }


    }


    private void startRecording() {


        final SoundFile.ProgressListener listener =
                new SoundFile.ProgressListener() {
                    public boolean reportProgress(double elapsedTime) {
                        long now = Utility.getCurrentTime();
                        if (now - mRecordingLastUpdateTime > 5) {
                            mRecordingTime = elapsedTime;
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    int min = (int) (mRecordingTime / 60);
                                    float sec = (float) (mRecordingTime - 60 * min);

                                }
                            });
                            mRecordingLastUpdateTime = now;
                        }
                        return mRecordingKeepGoing;
                    }
                };


        Thread mRecordAudioThread = new Thread() {
            public void run() {
                try {

                    mRecordedSoundFile = SoundFile.create(file.getAbsolutePath(), listener);
                    if (mRecordedSoundFile == null) {
                        finish();
                        Runnable runnable = new Runnable() {
                            public void run() {

                            }
                        };
                        mHandler.post(runnable);
                        return;
                    }
                    mPlayer = new SamplePlayer(mRecordedSoundFile);


                    runOnUiThread(new Runnable() {


                        @Override
                        public void run() {


                            txtAudioDone.setClickable(true);
                            txtAudioDone.setEnabled(true);

                            txtAudioPlay.setClickable(true);
                            txtAudioPlay.setEnabled(true);


                            txtAudioPlay.setVisibility(View.VISIBLE);
                            txtAudioDone.setVisibility(View.VISIBLE);

                            pb_load.setVisibility(View.GONE);
                            cv_pro.setVisibility(View.GONE);


                        }
                    });


                    isAudioRecording = false;
                    mRecordingKeepGoing = false;


                } catch (final Exception e) {
                    finish();
                    e.printStackTrace();
                    return;
                }

                Runnable runnable = new Runnable() {
                    public void run() {

                        audioWaveform.setIsDrawBorder(true);
                        finishOpeningSoundFile(mRecordedSoundFile, 0);


                        txtStartPosition.setVisibility(View.VISIBLE);
                        txtStartPosition1.setVisibility(View.VISIBLE);
                        txtEndPosition.setVisibility(View.VISIBLE);
                        txtEndPosition1.setVisibility(View.VISIBLE);
                        markerEnd.setVisibility(View.VISIBLE);
                        markerStart.setVisibility(View.VISIBLE);
                        txtAudioDone.setVisibility(View.VISIBLE);

                    }
                };
                mHandler.post(runnable);
            }
        };
        mRecordAudioThread.start();
    }


    private void finishOpeningSoundFile(SoundFile mSoundFile, int isReset) {
        audioWaveform.setVisibility(View.VISIBLE);


        audioWaveform.setSoundFile(mSoundFile);
        audioWaveform.recomputeHeights(mDensity);

        mMaxPos = audioWaveform.maxPos();
        mLastDisplayedStartPos = -1;
        mLastDisplayedEndPos = -1;

        mTouchDragging = false;

        mOffset = 0;
        mOffsetGoal = 0;
        mFlingVelocity = 0;
        resetPositions();
        if (mEndPos > mMaxPos)
            mEndPos = mMaxPos;

        if (isReset == 1) {
            mStartPos = audioWaveform.secondsToPixels(0);
            mEndPos = audioWaveform.secondsToPixels(audioWaveform.pixelsToSeconds(mMaxPos));
        }

        if (audioWaveform != null && audioWaveform.isInitialized()) {
            double seconds = audioWaveform.pixelsToSeconds(mMaxPos);
            int min = (int) (seconds / 60);
            float sec = (float) (seconds - 60 * min);
            // txtAudioRecordTimeUpdate.setText(String.format(Locale.US, "%02d:%05.2f", min, sec));
        }

        updateDisplay();
    }

    /**
     * Update views
     */

    private synchronized void updateDisplay() {
        if (mIsPlaying) {
            int now = mPlayer.getCurrentPosition();
            int frames = audioWaveform.millisecsToPixels(now);
            audioWaveform.setPlayback(frames);

            setOffsetGoalNoUpdate(frames - mWidth / 2);
            if (now >= mPlayEndMillSec) {
                handlePause();
            }
        }

        if (!mTouchDragging) {
            int offsetDelta;

            if (mFlingVelocity != 0) {
                offsetDelta = mFlingVelocity / 30;
                if (mFlingVelocity > 80) {
                    mFlingVelocity -= 80;
                } else if (mFlingVelocity < -80) {
                    mFlingVelocity += 80;
                } else {
                    mFlingVelocity = 0;
                }

                mOffset += offsetDelta;

                if (mOffset + mWidth / 2 > mMaxPos) {
                    mOffset = mMaxPos - mWidth / 2;
                    mFlingVelocity = 0;
                }
                if (mOffset < 0) {
                    mOffset = 0;
                    mFlingVelocity = 0;
                }
                mOffsetGoal = mOffset;
            } else {
                offsetDelta = mOffsetGoal - mOffset;

                if (offsetDelta > 10)
                    offsetDelta = offsetDelta / 10;
                else if (offsetDelta > 0)
                    offsetDelta = 1;
                else if (offsetDelta < -10)
                    offsetDelta = offsetDelta / 10;
                else if (offsetDelta < 0)
                    offsetDelta = -1;
                else
                    offsetDelta = 0;

                mOffset += offsetDelta;
            }
        }

        audioWaveform.setParameters(mStartPos, mEndPos, mOffset);
        audioWaveform.invalidate();

        markerStart.setContentDescription(
                " Start Marker" +
                        formatTime(mStartPos));
        markerEnd.setContentDescription(
                " End Marker" +
                        formatTime(mEndPos));

        int startX = mStartPos - mOffset - mMarkerLeftInset;
        if (startX + markerStart.getWidth() >= 0) {
            if (!mStartVisible) {
                // Delay this to avoid flicker
                mHandler.postDelayed(new Runnable() {
                    public void run() {
                        mStartVisible = true;
                        markerStart.setAlpha(1f);
                        txtStartPosition.setAlpha(1f);
                        txtStartPosition1.setAlpha(1f);
                    }
                }, 0);
            }
        } else {
            if (mStartVisible) {
                markerStart.setAlpha(0f);
                txtStartPosition.setAlpha(0f);
                txtStartPosition1.setAlpha(0f);
                mStartVisible = false;
            }
            startX = 0;
        }


        int startTextX = mStartPos - mOffset - mTextLeftInset;
        if (startTextX + markerStart.getWidth() < 0) {
            startTextX = 0;
        }


        int endX = mEndPos - mOffset - markerEnd.getWidth() + mMarkerRightInset;
        if (endX + markerEnd.getWidth() >= 0) {
            if (!mEndVisible) {
                // Delay this to avoid flicker
                mHandler.postDelayed(new Runnable() {
                    public void run() {
                        mEndVisible = true;
                        markerEnd.setAlpha(1f);
                    }
                }, 0);
            }
        } else {
            if (mEndVisible) {
                markerEnd.setAlpha(0f);
                mEndVisible = false;
            }
            endX = 0;
        }

        int endTextX = mEndPos - mOffset - txtEndPosition.getWidth() + mTextRightInset;
        if (endTextX + markerEnd.getWidth() < 0) {
            endTextX = 0;
        }


        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);





        params.setMargins(
                startX,
                audioWaveform.getMeasuredHeight() / 2 + mMarkerTopOffset,
                -markerStart.getWidth(),
                -markerStart.getHeight());


        params.addRule(RelativeLayout.ALIGN_TOP);//in my case


        markerStart.setLayoutParams(params);


        params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(
                startTextX,
                mTextTopOffset,
                -txtStartPosition.getWidth(),
                -txtStartPosition.getHeight());


        txtStartPosition.setLayoutParams(params);


        params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(
                endX,
                audioWaveform.getMeasuredHeight() / 2 + mMarkerBottomOffset,
                -markerEnd.getWidth(),
                -markerEnd.getHeight());





        params.addRule(RelativeLayout.ALIGN_TOP);//in my case


        markerEnd.setLayoutParams(params);


        params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(
                endTextX,
                audioWaveform.getMeasuredHeight() - txtEndPosition.getHeight() - mTextBottomOffset,
                -txtEndPosition.getWidth(),
                -txtEndPosition.getHeight());

        txtEndPosition.setLayoutParams(params);
    }

    /**
     * Reset all positions
     */

    private void resetPositions() {
        mStartPos = audioWaveform.secondsToPixels(0.0);
        mEndPos = audioWaveform.secondsToPixels(15.0);
    }

    private void setOffsetGoalNoUpdate(int offset) {
        if (mTouchDragging) {
            return;
        }

        mOffsetGoal = offset;
        if (mOffsetGoal + mWidth / 2 > mMaxPos)
            mOffsetGoal = mMaxPos - mWidth / 2;
        if (mOffsetGoal < 0)
            mOffsetGoal = 0;
    }

    private String formatTime(int pixels) {
        if (audioWaveform != null && audioWaveform.isInitialized()) {
//            return formatDecimal(audioWaveform.pixelsToMillisecs(pixels));

            long millis = audioWaveform.pixelsToMillisecs(pixels);

            String time = String.format("%02d:%02d:%02d",
                    TimeUnit.MILLISECONDS.toHours(millis),
                    TimeUnit.MILLISECONDS.toMinutes(millis) -
                            TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                    TimeUnit.MILLISECONDS.toSeconds(millis) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
            return time;
        } else {
            return "";
        }
    }

    private String formatDecimal(double x) {
        int xWhole = (int) x;
        int xFrac = (int) (100 * (x - xWhole) + 0.5);

        if (xFrac >= 100) {
            xWhole++; //Round up
            xFrac -= 100; //Now we need the remainder after the round up
            if (xFrac < 10) {
                xFrac *= 10; //we need a fraction that is 2 digits long
            }
        }

        if (xFrac < 10) {
            if (xWhole < 10)
                return "0" + xWhole + ".0" + xFrac;
            else
                return xWhole + ".0" + xFrac;
        } else {
            if (xWhole < 10)
                return "0" + xWhole + "." + xFrac;
            else
                return xWhole + "." + xFrac;

        }
    }

    private int trap(int pos) {
        if (pos < 0)
            return 0;
        if (pos > mMaxPos)
            return mMaxPos;
        return pos;
    }

    private void setOffsetGoalStart() {
        setOffsetGoal(mStartPos - mWidth / 2);
    }

    private void setOffsetGoalStartNoUpdate() {
        setOffsetGoalNoUpdate(mStartPos - mWidth / 2);
    }

    private void setOffsetGoalEnd() {
        setOffsetGoal(mEndPos - mWidth / 2);
    }

    private void setOffsetGoalEndNoUpdate() {
        setOffsetGoalNoUpdate(mEndPos - mWidth / 2);
    }

    private void setOffsetGoal(int offset) {
        setOffsetGoalNoUpdate(offset);
        updateDisplay();
    }

    public void markerDraw() {
    }

    public void markerTouchStart(MarkerView marker, float x) {
        mTouchDragging = true;
        mTouchStart = x;
        mTouchInitialStartPos = mStartPos;
        mTouchInitialEndPos = mEndPos;
        handlePause();
    }


    public void markerTouchMove(MarkerView marker, float x) {


        float delta = x - mTouchStart;

        if (marker == markerStart) {


            plus_start = delta;

            mStartPos = trap((int) (mTouchInitialStartPos + delta));


            mEndPos = trap((int) (mTouchInitialEndPos + delta));


        } else {


            mEndPos = trap((int) (mTouchInitialEndPos + delta));
            if (mEndPos < mStartPos)
                mEndPos = mStartPos;


        }

        updateDisplay();
    }


    public void markerTouchEnd(MarkerView marker) {

        mTouchDragging = false;
        if (marker == markerStart) {
            setOffsetGoalStart();
        } else {
            setOffsetGoalEnd();
        }
    }

    public void markerLeft(MarkerView marker, int velocity) {


        mKeyDown = true;

        if (marker == markerStart) {
            int saveStart = mStartPos;
            mStartPos = trap(mStartPos - velocity);
            mEndPos = trap(mEndPos - (saveStart - mStartPos));
            setOffsetGoalStart();
        }

        if (marker == markerEnd) {
            if (mEndPos == mStartPos) {
                mStartPos = trap(mStartPos - velocity);
                mEndPos = mStartPos;
            } else {
                mEndPos = trap(mEndPos - velocity);
            }

            setOffsetGoalEnd();
        }

        updateDisplay();
    }

    public void markerRight(MarkerView marker, int velocity) {


        mKeyDown = true;

        if (marker == markerStart) {
            int saveStart = mStartPos;
            mStartPos += velocity;
            if (mStartPos > mMaxPos)
                mStartPos = mMaxPos;
            mEndPos += (mStartPos - saveStart);
            if (mEndPos > mMaxPos)
                mEndPos = mMaxPos;

            setOffsetGoalStart();
        }

        if (marker == markerEnd) {
            mEndPos += velocity;
            if (mEndPos > mMaxPos)
                mEndPos = mMaxPos;

            setOffsetGoalEnd();
        }

        updateDisplay();
    }

    public void markerEnter(MarkerView marker) {
    }

    public void markerKeyUp() {
        mKeyDown = false;
        updateDisplay();


    }

    public void markerFocus(MarkerView marker) {
        mKeyDown = false;
        if (marker == markerStart) {
            setOffsetGoalStartNoUpdate();
        } else {
            setOffsetGoalEndNoUpdate();
        }

        mHandler.postDelayed(new Runnable() {
            public void run() {
                updateDisplay();
            }
        }, 100);
    }

    //
    // WaveformListener
    //

    /**
     * Every time we get a message that our waveform drew, see if we need to
     * animate and trigger another redraw.
     */
    public void waveformDraw() {
        mWidth = audioWaveform.getMeasuredWidth();
        if (mOffsetGoal != mOffset && !mKeyDown)
            updateDisplay();
        else if (mIsPlaying) {
            updateDisplay();
        } else if (mFlingVelocity != 0) {
            updateDisplay();
        }
    }

    public void waveformTouchStart(float x) {
        mTouchDragging = true;
        mTouchStart = x;
        mTouchInitialOffset = mOffset;
        mFlingVelocity = 0;

    }

    public void waveformTouchMove(float x) {
        mOffset = trap((int) (mTouchInitialOffset + (mTouchStart - x)));
        updateDisplay();
    }

    public void waveformTouchEnd() {

    }

    private synchronized void handlePause() {
        txtAudioPlay.setImageResource(R.drawable.play_big);
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
        }
        audioWaveform.setPlayback(-1);
        mIsPlaying = false;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.stop();
        }
    }


    @Override
    protected void onStop() {
        super.onStop();

        txtAudioPlay.setImageResource(R.drawable.play_big);
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
        }
        audioWaveform.setPlayback(-1);
        mIsPlaying = false;

    }

    private synchronized void onPlay(int startPosition) {
        if (mIsPlaying) {
            handlePause();
            return;
        }

        if (mPlayer == null) {
            // Not initialized yet
            return;
        }

        try {
            int mPlayStartMsec = audioWaveform.pixelsToMillisecs(startPosition);
            if (startPosition < mStartPos) {
                mPlayEndMillSec = audioWaveform.pixelsToMillisecs(mStartPos);
            } else if (startPosition > mEndPos) {
                mPlayEndMillSec = audioWaveform.pixelsToMillisecs(mMaxPos);
            } else {
                mPlayEndMillSec = audioWaveform.pixelsToMillisecs(mEndPos);
            }
            mPlayer.setOnCompletionListener(new SamplePlayer.OnCompletionListener() {
                @Override
                public void onCompletion() {
                    handlePause();
                }
            });
            mIsPlaying = true;

            mPlayer.seekTo(mPlayStartMsec);
            mPlayer.start();
            updateDisplay();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void waveformFling(float vx) {
        mTouchDragging = false;
        mOffsetGoal = mOffset;
        mFlingVelocity = (int) (-vx);
        updateDisplay();
    }

    public void waveformZoomIn() {

    }

    public void waveformZoomOut() {

    }

    /**
     * Save sound file as ringtone
     *
     * @param finish flag for finish
     */

    private void saveRingtone(final int finish) {
        double startTime = audioWaveform.pixelsToSeconds(mStartPos);
        double endTime = audioWaveform.pixelsToSeconds(mEndPos);
        final int startFrame = audioWaveform.secondsToFrames(startTime);
        final int endFrame = audioWaveform.secondsToFrames(endTime - 0.04);
        duration = (int) (endTime - startTime + 0.5);


        mProgressDialog = new Dialog(AudioTrimmerActivity.this);
        mProgressDialog.setContentView(R.layout.loadercon_dialog2);
        Window window2 = mProgressDialog.getWindow();
        WindowManager.LayoutParams wlp1 = window2.getAttributes();
        window2.setAttributes(wlp1);
        mProgressDialog.setCancelable(false);
        window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        mProgressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mProgressDialog.show();

        TextView tv_re = mProgressDialog.findViewById(R.id.tv_re);
        tv_re.setText("" + "Saving...");


        Thread mSaveSoundFileThread = new Thread() {
            public void run() {

                String outPath = makeRingtoneFilename("AUDIO_TEMP", Utility.AUDIO_FORMAT);

                if (outPath == null) {

                    return;
                }
                File outFile = new File(outPath);


                try {
                    mRecordedSoundFile.WriteFile(outFile, startFrame, endFrame - startFrame);
                } catch (Exception e) {
                    if (outFile.exists()) {
                        outFile.delete();
                    }
                    e.printStackTrace();
                }


                final String finalOutPath = outPath;

                Runnable runnable = new Runnable() {
                    public void run() {


                        afterSavingRingtone("AUDIO_TEMP",
                                finalOutPath,
                                duration, finish);


                    }
                };
                mHandler.post(runnable);
            }
        };
        mSaveSoundFileThread.start();
    }


    private void afterSavingRingtone(CharSequence title,
                                     String outPath,
                                     int duration, int finish) {
        File outFile = new File(outPath);
        long fileSize = outFile.length();


        MediaScannerConnection.scanFile(AudioTrimmerActivity.this,
                new String[]{outFile.getAbsolutePath()}, null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });


        if (finish == 0) {


            loadFromFile(outPath);

        } else if (finish == 1) {
            Bundle conData = new Bundle();
            conData.putString("INTENT_AUDIO_FILE", outPath);
            Intent intent = getIntent();
            intent.putExtras(conData);
            setResult(RESULT_OK, intent);
            finish();
        }
    }


    private String makeRingtoneFilename(CharSequence title, String extension) {
        String subDir;
        String externalRootDir = getExternalFilesDir("").getPath();


        if (!externalRootDir.endsWith("/")) {
            externalRootDir += "/";
        }
        subDir = "MyTikTikRingTone/";

        String parentDir = externalRootDir + subDir;


        File parentDirFile = new File(parentDir);
        parentDirFile.mkdirs();

        if (!parentDirFile.isDirectory()) {
            parentDir = externalRootDir;
        }


        String filename = "";
        for (int i = 0; i < title.length(); i++) {
            if (Character.isLetterOrDigit(title.charAt(i))) {
                filename += title.charAt(i);
            }
        }

        String path = null;
        for (int i = 0; i < 100; i++) {
            String testPath;
            if (i > 0)
                testPath = parentDir + filename + i + extension;
            else
                testPath = parentDir + filename + extension;

            try {
                RandomAccessFile f = new RandomAccessFile(new File(testPath), "r");
                f.close();
            } catch (Exception e) {
                // Good, the file didn't exist
                path = testPath;
                break;
            }
        }

        return path;
    }


    private void loadFromFile(String mFilename) {


        mFile = new File(mFilename);

        mLoadingLastUpdateTime = Utility.getCurrentTime();
        mLoadingKeepGoing = true;


        final SoundFile.ProgressListener listener =
                new SoundFile.ProgressListener() {
                    public boolean reportProgress(double fractionComplete) {


                        return mLoadingKeepGoing;

                    }


                };


        Thread mLoadSoundFileThread = new Thread() {
            public void run() {
                try {
                    mLoadedSoundFile = SoundFile.create(mFile.getAbsolutePath(), listener);
                    if (mLoadedSoundFile == null) {
                        mProgressDialog.dismiss();
                        String name = mFile.getName().toLowerCase();
                        String[] components = name.split("\\.");
                        String err;
                        if (components.length < 2) {
                            err = "No Extension";
                        } else {
                            err = "Bad Extension";
                        }
                        final String finalErr = err;

                        return;
                    }
                    mPlayer = new SamplePlayer(mLoadedSoundFile);
                } catch (final Exception e) {
                    mProgressDialog.dismiss();
                    e.printStackTrace();
                    return;
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        int duration2 = duration - 1;


                    }
                });


                mProgressDialog.dismiss();


                if (mLoadingKeepGoing) {
                    Runnable runnable = new Runnable() {
                        public void run() {


                            audioWaveform.setVisibility(View.INVISIBLE);
                            audioWaveform.setBackgroundColor(getResources().getColor(R.color.waveformUnselectedBackground));
                            audioWaveform.setIsDrawBorder(false);
                            finishOpeningSoundFile(mLoadedSoundFile, 0);


                        }
                    };
                    mHandler.post(runnable);
                }
            }
        };
        mLoadSoundFileThread.start();
    }
}
