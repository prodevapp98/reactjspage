package com.si_vidoditor.paras_viddaditorapp.audiocutter;

import android.media.MediaPlayer;
import android.widget.ImageView;

import java.io.File;
import java.util.ArrayList;

public interface FilePAthdata2ex {
    public  void  fitdat(ArrayList<File> pathDAta, MediaPlayer player, ImageView img );
    public  void  fitdat2(ArrayList<File> pathDAta, MediaPlayer player, ImageView img );


}
