package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_vidoditor.paras_viddaditorapp.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class VieDataAdapter extends RecyclerView.Adapter<VieDataAdapter.holder> {
    public final Activity activity;
    private ArrayList<File> albu;
   private cuttetinter cuttetinter;
    String type;

    public class holder extends RecyclerView.ViewHolder {


        private ImageView i1;

        int position;
        private TextView t1;
        private TextView t2;
        private TextView t3;

        private ImageView iv_delete;


        holder(View view) {
            super(view);

            i1 = view.findViewById(R.id.thumb);
            t1 = view.findViewById(R.id.name);
            t2 = view.findViewById(R.id.duration);
            t3 = view.findViewById(R.id.size);
            iv_delete = view.findViewById(R.id.iv_delete);


        }
    }


    public VieDataAdapter(Activity activity, ArrayList<File> albu, cuttetinter cuttetinter, String type) {
        this.activity = activity;
        this.albu = albu;
        this.cuttetinter= cuttetinter;
        this.type= type;

    }

    @Override
    public holder onCreateViewHolder(ViewGroup viewGroup, int i) {


        return new holder(LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.tt_item_video_list2, viewGroup, false));


    }

    public static Long getImageContentUri(Context context, File imageFile) {
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Files.getContentUri("external");
        }


        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                collection,
                new String[]{MediaStore.Files.FileColumns.DURATION},
                MediaStore.Files.FileColumns.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") Long id = cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.DURATION));
            cursor.close();
            return id;
        } else {


            return null;

        }


    }


    @SuppressLint({"StaticFieldLeak", "ClickableViewAccessibility"})
    @Override
    public void onBindViewHolder(holder viewHolder, @SuppressLint("RecyclerView") final int i) {

        File fileinfo = albu.get(i);

        holder holder2 = (holder) viewHolder;
        if (fileinfo!=null){
            if (fileinfo.getName()!=null){
                holder2.t1.setText(fileinfo.getName());
            }

            Glide.with(this.activity).load(fileinfo.getAbsoluteFile()).into(holder2.i1);
        }


        Long duration = getImageContentUri(activity, fileinfo);
        if(duration!=null) {
            String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                    new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(duration)),
                            Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1)),
                            Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1))});

            holder2.t3.setText(str);
        }

        if(type.equals("converter"))
        {


            holder2.t1.setTextColor(activity.getResources().getColor(R.color.thm_2));
            holder2.t3.setTextColor(activity.getResources().getColor(R.color.thm_2));
            holder2.iv_delete.setColorFilter(activity.getResources().getColor(R.color.thm_2));


        }


        holder2.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                albu.remove(i);
                notifyDataSetChanged();


            }
        });

        cuttetinter.datat(albu);





    }

    @Override
    public int getItemCount() {
        return albu.size();
    }


}
