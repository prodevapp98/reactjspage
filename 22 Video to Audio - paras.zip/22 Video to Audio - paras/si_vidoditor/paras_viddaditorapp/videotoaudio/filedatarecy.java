package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import java.io.File;

public interface filedatarecy {

    public  void  recycle(int allfile);
    public  void  recycle2(File allfile);

}
