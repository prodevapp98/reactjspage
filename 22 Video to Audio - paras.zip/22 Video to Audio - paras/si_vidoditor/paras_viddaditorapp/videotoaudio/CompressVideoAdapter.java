package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;
import com.si_vidoditor.paras_viddaditorapp.utils.OnSwipeTouchListener;
import com.si_vidoditor.paras_viddaditorapp.videocutter.CutterActivity;
import com.si_vidoditor.paras_viddaditorapp.videocutter.CutterVideo2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CompressVideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {
    public boolean action = false;
    public final Activity activity;
    public List<Video_Item> dup_items;
    public List<Video_Item> filtered_videoList = new ArrayList();
    private final List<Video_Item> list;

    private DataProccessor dataProccessor;
    private String type;
    public final Boolean view;
    private final int wi;
    String wtsupVideo;
    private static final int DEFAULT_BUFFER_SIZE = 1024 * 1024;
    private ArrayList<File> pathDAta = new ArrayList<>();
    private cuttetinter cuttetinter;
    TextView tex_vie;


    public CompressVideoAdapter(Activity activity, List<Video_Item> list2, List<Video_Item> list3,
                                int i, boolean z, String str, String type, cuttetinter cuttetinter, TextView tex_vie) {
        this.activity = activity;
        this.dup_items = list2;
        this.wi = i;
        this.type = type;
        this.filtered_videoList = list2;
        this.view = Boolean.valueOf(z);
        this.wtsupVideo = str;
        this.list = list2;
        this.cuttetinter = cuttetinter;
        this.tex_vie= tex_vie;

    }

    public int getItemViewType(int i) {
        return this.filtered_videoList.get(i).getViewType() == 1 ? 1 : 2;
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {


        dataProccessor = new DataProccessor(activity);
        LayoutInflater from = LayoutInflater.from(this.activity);

        if (dataProccessor.getStr("ListType").equals("yes")) {

            return new holder(from.inflate(R.layout.tt_item_video_list, viewGroup, false));

        } else {

            return new holder(from.inflate(R.layout.graid_layout, viewGroup, false));


        }


    }

    private boolean isVideoHaveAudioTrack(String path) {
        boolean audioTrack = false;

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(path);
        String hasAudioStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO);
        if (hasAudioStr != null && hasAudioStr.equals("yes")) {
            audioTrack = true;
        } else {
            audioTrack = false;
        }

        return audioTrack;
    }


    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {






        holder holder2 = (holder) viewHolder;
        holder2.position = i;

        File file3 = new File(this.filtered_videoList.get(i).getDATA());
        holder2.t1.setText(file3.getName());
        holder2.t3.setText(Utils.formatMilis(this.filtered_videoList.get(i).getDURATION()));


        if (activity.getIntent().getStringExtra("type").equals("convert")) {

            holder2.t1.setTextColor(activity.getResources().getColor(R.color.thm_1));
            holder2.t3.setTextColor(activity.getResources().getColor(R.color.thm_1));


        } else if (activity.getIntent().getStringExtra("type").equals("trimming")) {

            holder2.t1.setTextColor(activity.getResources().getColor(R.color.thm_4));
            holder2.t3.setTextColor(activity.getResources().getColor(R.color.thm_4));
            holder2.iv_selectioon.setVisibility(View.GONE);


        } else {

            holder2.t1.setTextColor(activity.getResources().getColor(R.color.thm_2));
            holder2.t3.setTextColor(activity.getResources().getColor(R.color.thm_2));
            holder2.iv_selectioon.setImageResource(R.drawable.sele_th2);
            holder2.iv_selectioon1.setImageResource(R.drawable.sele_th21);


        }


        if (!dataProccessor.getStr("ListType").equals("yes")) {

            holder2.t3.setTextColor(activity.getResources().getColor(R.color.white));

            if (activity.getIntent().getStringExtra("type").equals("convert")) {
                holder2.t3.setBackgroundColor(activity.getResources().getColor(R.color.thm_1));

            } else if (activity.getIntent().getStringExtra("type").equals("trimming")) {
                holder2.t3.setBackgroundColor(activity.getResources().getColor(R.color.thm_4));

            } else {
                holder2.t3.setBackgroundColor(activity.getResources().getColor(R.color.thm_2));


            }


        }


        if (this.view.booleanValue()) {
        }
        Glide.with(this.activity).load(this.filtered_videoList.get(i).getDATA()).into(holder2.i1);


        holder2.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (activity.getIntent().getStringExtra("type").equals("convert")
                        || activity.getIntent().getStringExtra("type").equals("trimming")) {

                    if (pathDAta.size() == 0) {
                        String selectedVideoPath = file3.getAbsolutePath();

                        if (activity.getIntent().getStringExtra("type").equals("convert")) {


                            if (isVideoHaveAudioTrack(selectedVideoPath)) {


                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(activity, msg -> {
                                    Intent intent = new Intent(activity, CutterActivity.class);
                                    intent.putExtra("EXTRA_VIDEO_PATH", selectedVideoPath);

                                    intent.putExtra("savb", 1);
                                    intent.putExtra("avint", 1);

                                    activity.startActivity(intent);
                                });

                            }

                            else
                            {

                                Toast.makeText(activity, "Video not contain audio stream", Toast.LENGTH_SHORT).show();
                            }

                        } else if (activity.getIntent().getStringExtra("type").equals("convtref")) {




                        } else {

                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(activity, msg -> {
                                Intent intent = new Intent(activity, CutterVideo2.class);
                                intent.putExtra("EXTRA_VIDEO_PATH", selectedVideoPath);

                                intent.putExtra("savb", 0);
                                intent.putExtra("avint", 2);
                                activity.startActivity(intent);
                            });



                        }


                    }


                } else {

                    if (pathDAta.contains(file3)) {
                        pathDAta.remove(file3);
                        holder2.iv_selectioon1.setVisibility(View.GONE);

                        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                        holder2.t1.setTypeface(typeface);

                    } else {
                        pathDAta.add(file3);
                        holder2.iv_selectioon1.setVisibility(View.VISIBLE);

                        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                        holder2.t1.setTypeface(typeface);

                    }
                    cuttetinter.datat(pathDAta);


                }


            }


        });


        if (pathDAta.size() != 0) {
            if (pathDAta.contains(file3)) {

                Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                holder2.t1.setTypeface(typeface);

                holder2.iv_selectioon1.setVisibility(View.VISIBLE);

            } else {
                Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                holder2.t1.setTypeface(typeface);
                holder2.iv_selectioon1.setVisibility(View.GONE);
            }

        } else {
            Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
            holder2.t1.setTypeface(typeface);
            holder2.iv_selectioon1.setVisibility(View.GONE);

        }


        holder2.iv_selectioon.setOnTouchListener(new OnSwipeTouchListener(activity.getApplicationContext()) {
            @Override
            public void onClick() {
                super.onClick();

                if (activity.getIntent().getStringExtra("type").equals("convert")) {


                    if (pathDAta.contains(file3)) {
                        pathDAta.remove(file3);
                        holder2.iv_selectioon1.setVisibility(View.GONE);


                        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                        holder2.t1.setTypeface(typeface);

                    } else {
                        if (isVideoHaveAudioTrack(file3.getAbsolutePath())) {
                            pathDAta.add(file3);
                            holder2.iv_selectioon1.setVisibility(View.VISIBLE);

                            Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                            holder2.t1.setTypeface(typeface);
                        }

                        else
                        {

                            Toast.makeText(activity, "Video not contain audio stream", Toast.LENGTH_SHORT).show();
                            return;
                        }

                    }


                    cuttetinter.datat(pathDAta);



                }
                else
                {


                    if (pathDAta.contains(file3)) {
                        pathDAta.remove(file3);
                        holder2.iv_selectioon1.setVisibility(View.GONE);


                        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
                        holder2.t1.setTypeface(typeface);

                    } else {
                        pathDAta.add(file3);
                        holder2.iv_selectioon1.setVisibility(View.VISIBLE);

                        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
                        holder2.t1.setTypeface(typeface);
                    }


                    cuttetinter.datat(pathDAta);






                }





            }


        });


    }


    public int getItemCount() {
        return this.filtered_videoList.size();
    }

    public Filter getFilter() {
        return new Filter() {
            public FilterResults performFiltering(CharSequence charSequence) {
                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    CompressVideoAdapter videoAdapter = CompressVideoAdapter.this;
                    List unused = videoAdapter.filtered_videoList = videoAdapter.dup_items;
                } else {
                    ArrayList arrayList = new ArrayList();

                    for (Video_Item videoItem : CompressVideoAdapter.this.dup_items) {


                        File file = new File(videoItem.getDATA());
                        if (file.getName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(videoItem);
                        }
                    }
                    List unused2 = CompressVideoAdapter.this.filtered_videoList = arrayList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = CompressVideoAdapter.this.filtered_videoList;
                return filterResults;
            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                List unused = CompressVideoAdapter.this.filtered_videoList = (List) filterResults.values;
                CompressVideoAdapter.this.notifyDataSetChanged();

                if(filtered_videoList.size()<=0)
                {
                    tex_vie.setVisibility(View.VISIBLE);
                }
                else

                {

                    tex_vie.setVisibility(View.GONE);
                }




            }
        };
    }


    class holder extends RecyclerView.ViewHolder {
        private ImageView i1;

        int position;
        private TextView t1;
        private TextView t2;
        private TextView t3;


        private ImageView iv_selectioon, iv_selectioon1;

        holder(View view) {
            super(view);
            i1 = view.findViewById(R.id.thumb);
            t1 = view.findViewById(R.id.name);
            t2 = view.findViewById(R.id.duration);


            t2 = view.findViewById(R.id.duration);
            t2 = view.findViewById(R.id.duration);

            iv_selectioon = view.findViewById(R.id.iv_selectioon);
            iv_selectioon1 = view.findViewById(R.id.iv_selectioon1);
            this.t3 = (TextView) view.findViewById(R.id.size);


        }

    }


}
