package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import java.io.Serializable;

public class Video_Item implements Serializable {
    private String Bucket;
    public String DATA;
    private String DATE;
    public String DISPLAY_NAME;
    private Long DURATION;
    private String SIZE;
    private String _ID;
    public int viewType;

    public int getViewType() {
        return this.viewType;
    }

    public void setViewType(int i) {
        this.viewType = i;
    }

    public String getBucket() {
        return this.Bucket;
    }

    public void setBucket(String str) {
        this.Bucket = str;
    }

    public Video_Item(String str, String str2, String str3, String str4, String str5, Long str6, String str7) {
        this._ID = str;
        this.SIZE = str2;
        this.DATE = str3;
        this.DATA = str4;
        this.DISPLAY_NAME = str5;
        this.DURATION = str6;
        this.Bucket = str7;
    }

    public Video_Item() {
    }

    public String get_ID() {
        return this._ID;
    }

    public void set_ID(String str) {
        this._ID = str;
    }

    public String getSIZE() {
        return this.SIZE;
    }

    public void setSIZE(String str) {
        this.SIZE = str;
    }

    public String getDATE() {
        return this.DATE;
    }

    public void setDATE(String str) {
        this.DATE = str;
    }

    public String getDATA() {
        return this.DATA;
    }

    public void setDATA(String str) {
        this.DATA = str;
    }

    public String getDISPLAY_NAME() {
        return this.DISPLAY_NAME;
    }

    public void setDISPLAY_NAME(String str) {
        this.DISPLAY_NAME = str;
    }

    public Long getDURATION() {
        return this.DURATION;
    }

    public void setDURATION(Long str) {
        this.DURATION = str;
    }
}
