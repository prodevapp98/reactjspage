package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;




public class TinyDB {

    private Context context;
    private SharedPreferences preferences;
    private String DEFAULT_APP_IMAGEDATA_DIRECTORY;
    private String lastImagePath = "";

    public TinyDB(Context appContext) {
        preferences = PreferenceManager.getDefaultSharedPreferences(appContext);
        context = appContext;
    }






    public ArrayList<Integer> getListInt(String key) {
        String[] myList = TextUtils.split(preferences.getString(key, ""), "‚‗‚");
        ArrayList<String> arrayToList = new ArrayList<String>(Arrays.asList(myList));
        ArrayList<Integer> newList = new ArrayList<Integer>();

        for (String item : arrayToList)
            newList.add(Integer.parseInt(item));

        return newList;
    }






    public void putListInt(String key, ArrayList<Integer> intList) {
    	checkForNullKey(key);
        Integer[] myIntList = intList.toArray(new Integer[intList.size()]);
        preferences.edit().putString(key, TextUtils.join("‚‗‚", myIntList)).apply();
    }




    public Map<String, ?> getAll() {
        return preferences.getAll();
    }



    /**
     * Check if external storage is writable or not
     * @return true if writable, false otherwise
     */
    public static boolean isExternalStorageWritable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    /**
     * Check if external storage is readable or not
     * @return true if readable, false otherwise
     */
    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();

        return Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }
    

    
    /**
     * null keys would corrupt the shared pref file and make them unreadable this is a preventive measure
     * @param key the pref key to check
     */
    private void checkForNullKey(String key){
        if (key == null){
            throw new NullPointerException();
        }
    }




    public void putListDocuObject(String key, ArrayList<String> objArray){
        checkForNullKey(key);
        Gson gson = new Gson();
        ArrayList<String> objStrings = new ArrayList<String>();

        for(Object obj : objArray){
            objStrings.add(gson.toJson(obj));

        }
        putListString(key, objStrings);


    }

    public ArrayList<String> getListdocuObject(String key, Class<?> mClass){
        Gson gson = new Gson();

        ArrayList<String> objStrings = getListString(key);
        ArrayList<String> objects =  new ArrayList<String>();

        for(String jObjString : objStrings){
            String value  = gson.fromJson(jObjString, (Type) mClass);
            objects.add(value);
        }
        return objects;
    }


    public void putListObject(String key, ArrayList<File> objArray){
        checkForNullKey(key);
        Gson gson = new Gson();
        ArrayList<String> objStrings = new ArrayList<String>();

        for(File obj : objArray){
            objStrings.add(gson.toJson(obj ));

//            objStrings.add("{\""+"path\""+":\""+obj.getAbsolutePath()+"\"}");
            Log.d("TAG", "fgputListObject: "+"pit--"+objStrings.get(0));
            Log.d("TAG", "fgputListObject: "+"pit--"+gson.toJson(obj ));
        }
        putListString(key, objStrings);

    }


    public void putListString(String key, ArrayList<String> stringList) {
        checkForNullKey(key);
        String[] myStringList = stringList.toArray(new String[stringList.size()]);
        preferences.edit().putString(key, TextUtils.join("‚‗‚", myStringList)).apply();
    }

    public ArrayList<File> getListObject(String key, Class<?> mClass){
    	Gson gson = new Gson();

    	ArrayList<String> objStrings = getListString(key);
    	ArrayList<File> objects =  new ArrayList<File>();

    	for(String jObjString : objStrings){
            Log.d("TAG", "getLidstObject: "+jObjString);
            File value  = gson.fromJson(jObjString, (Type) mClass);
            Log.d("TAG", "getLidstObject: path= "+value.getAbsolutePath());
            Log.d("TAG", "getLidstObject: name="+value.getName());
    		objects.add(value);
    	}
    	return objects;
    }





    public ArrayList<String> getListString(String key) {
        return new ArrayList<String>(Arrays.asList(TextUtils.split(preferences.getString(key, ""), "‚‗‚")));
    }





}