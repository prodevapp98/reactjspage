package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.outputfolder.UotPutAllActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;


public class MultiPleSelectionActivty extends AppCompatActivity {
    private TinyDB tinyDB;
    private ArrayList<File> alldat;
    private RecyclerView _rv_ciefile;
    private ImageView imageView;
    private ArrayList<File> removlist = new ArrayList<>();


    private VieDataAdapter VieDataAdapter;


    private ConstraintLayout btSave;

    private TextView tv_nodatafound;
    private ArrayList<File> pathDAta = new ArrayList<>();

    private ImageView iv_gidelist;

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_ple_selection_activty);

        iniData();

        tinyDB = new TinyDB(MultiPleSelectionActivty.this);
        alldat = tinyDB.getListObject("videoalldata", File.class);

        iv_gidelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tinyDB.putListObject("videoalldata", new ArrayList<>());
                finish();





            }
        });

        changeColor(R.color.home_top1);

        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(MultiPleSelectionActivty.this, admobBanner,cardBAnner);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();


            }
        });


        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (pathDAta.size() > 0) {
                    new DoBacckfff(MultiPleSelectionActivty.this, "mp3", pathDAta);

                } else {
                    Toast.makeText(MultiPleSelectionActivty.this, "Add at least one file", Toast.LENGTH_SHORT).show();
                }


            }
        });


        addadprer();


    }


    public class DoBacckfff {

        int count = 0;
        int count2 = 0;

        private String album;
        private String artist;
        private String audioFormat;
        private String audioPath;
        private String bitrate;
        private Context context;
        private File root;
        private TextView tv_fileru;
        private ArrayList<File> pathDAta;
        private ProgressBar progressBar;
        private Dialog dialog2;
        private TextView tv_re;
        private String str5;


        public DoBacckfff(
                Context context2,
                String str5,
                ArrayList<File> str7
        ) {
            context = context2;

            this.str5 = str5;


            pathDAta = str7;


            this.root = getExternalFilesDir("");

            File file = new File(root.getAbsolutePath()
                    + "/" + context2.getString(R.string.app_name)
                    + "/VideoToMp3");
            if (!file.exists()) {
                file.mkdirs();
            }


            dialog2 = new Dialog(context2);
            dialog2.setContentView(R.layout.loadercon_dialog2);

            tv_fileru = dialog2.findViewById(R.id.tv_fileru);
            tv_fileru.setVisibility(View.VISIBLE);

            CardView lv_1 = dialog2.findViewById(R.id.lv_1);
            ProgressBar mk_lod = dialog2.findViewById(R.id.mk_lod);
            Window window2 = dialog2.getWindow();
            WindowManager.LayoutParams wlp1 = window2.getAttributes();
            window2.setAttributes(wlp1);
            dialog2.setCancelable(false);

            tv_re = dialog2.findViewById(R.id.tv_re);


            progressBar = dialog2.findViewById(R.id.progressBar);
            window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog2.show();


            new DoBacckfff.ExtractAudio().execute(new Void[0]);
        }


        @SuppressLint({"StaticFieldLeak"})
        private class ExtractAudio extends AsyncTask<Void, Void, Void> {
            private ExtractAudio() {
            }


            public void onPreExecute() {
                super.onPreExecute();


            }

            public Void doInBackground(Void... voidArr) {
                tv_fileru.setText("" + (0) + "/" + pathDAta.size());

                for (int i = 0; i < pathDAta.size(); i++) {


                    count2++;
                    audioPath =
                            root.getAbsolutePath() + "/"
                                    + context.getString(R.string.app_name)

                                    + "/VideoToMp3/" + "VideoToMp3_c" + count2 + System.currentTimeMillis() + "." + str5;


                    String[] strArr = {"-y", "-i", pathDAta.get(i).getAbsolutePath(),
                            "-vn",
                            audioPath};


                    long executionId2 = FFmpeg.executeAsync(strArr, new ExecuteCallback() {

                        @Override
                        public void apply(final long executionId2, final int returnCode2) {
                            if (returnCode2 == RETURN_CODE_SUCCESS) {


                                count++;

                                tv_fileru.setText("" + (count) + "/" + pathDAta.size());


                                bitrate = "default";
                                if (count == pathDAta.size()) {
                                    dialog2.dismiss();
                                    finish();

                                    startActivity(new Intent(MultiPleSelectionActivty.this, UotPutAllActivity.class));
                                }


                                return;




//
//            progressDialog.setContent("Saving File");
//            progressDialog.show();


                            } else if (returnCode2 == RETURN_CODE_CANCEL) {
                                dialog2.dismiss();

                            } else {
                                dialog2.dismiss();

                            }

                        }
                    });


                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(audioPath)));
                    sendBroadcast(intent);


                }


                return null;
            }

            public void onPostExecute(Void r1) {
                super.onPostExecute(r1);
            }
        }


        private int getID() {
            return new AtomicInteger(0).incrementAndGet();
        }

        private void cancelNotification(Context context2, int i) {
            ((NotificationManager) context2.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(i);
        }
    }

    private void iniData() {

        iv_gidelist = findViewById(R.id.iv_gidelist);
        btSave = findViewById(R.id.btSave);
        tv_nodatafound = findViewById(R.id.tv_nodatafound);
        imageView = findViewById(R.id.imageView);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        tinyDB.putListObject("videoalldata", new ArrayList<>());


    }

    private void addadprer() {


        _rv_ciefile = findViewById(R.id._rv_ciefile);

        if (alldat.size() <= 0) {
            tv_nodatafound.setVisibility(View.VISIBLE);
        }

        Log.d("TAG", "addaddfprer:  ms="+alldat.size());
        VieDataAdapter = new VieDataAdapter(MultiPleSelectionActivty.this, alldat, new cuttetinter() {
            @Override
            public void datat(ArrayList<File> pathDAta2) {

                pathDAta = pathDAta2;


            }
        }, "cutter");


        _rv_ciefile.setHasFixedSize(true);
        _rv_ciefile.setLayoutManager(new LinearLayoutManager(MultiPleSelectionActivty.this));
        _rv_ciefile.setAdapter(VieDataAdapter);


    }

}