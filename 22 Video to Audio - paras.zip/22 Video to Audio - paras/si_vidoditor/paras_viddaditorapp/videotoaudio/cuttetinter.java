package com.si_vidoditor.paras_viddaditorapp.videotoaudio;

import java.io.File;
import java.util.ArrayList;

public interface cuttetinter {

    public void datat( ArrayList<File> pathDAta);
}
