package com.si_vidoditor.paras_viddaditorapp.Adapters;

import static com.si_vidoditor.paras_viddaditorapp.outputfolder.RingToneVAultAdapter.getMimeType;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.si_vidoditor.paras_viddaditorapp.R;

import com.si_vidoditor.paras_viddaditorapp.audiocutter.FilePAthdata2ex;

import com.si_vidoditor.paras_viddaditorapp.audiocutter.albumInfo;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class RingtoneAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {
    private boolean flage = true;
    public Activity activity;
    private ArrayList<albumInfo> albu;
    private ArrayList<albumInfo> dup_items;
    private FilePAthdata2ex filePAthdata;
    private MediaPlayer mediaPlayer;
    Handler handler;
    MediaPlayer player;
    Runnable updatePlayer;
    String type;

    private DataProccessor dataProccessor;
    private int currentPlayingPosition;

    private holder playingHolder;
    TextView noVideoLayout;

    public RingtoneAdapter(Activity activity, ArrayList<albumInfo> albu, FilePAthdata2ex filePAthdata, String type1, TextView noVideoLayout) {
        this.activity = activity;
        this.albu = albu;
        this.dup_items = albu;
        this.filePAthdata = filePAthdata;
        this.type = type1;
        this.currentPlayingPosition = -1;
        dataProccessor = new DataProccessor(activity);
        this.noVideoLayout = noVideoLayout;

    }


    private void updateNonPlayingView(holder holder) {


        holder.id_palypause.setImageResource(R.drawable.play_yellow);
        Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
        holder.nameTxt.setTypeface(typeface);


    }

    private void updatePlayingView() {

        if (mediaPlayer.isPlaying()) {
            Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_bold);
            playingHolder.nameTxt.setTypeface(typeface);

            playingHolder.id_palypause.setImageResource(R.drawable.pause_yellow);
        } else {
            Typeface typeface = ResourcesCompat.getFont(activity, R.font.sfpro_reg);
            playingHolder.nameTxt.setTypeface(typeface);
            playingHolder.id_palypause.setImageResource(R.drawable.play_yellow);
        }
    }


    public void onViewRecycled(holder holder) {
        super.onViewRecycled(holder);
        if (currentPlayingPosition == holder.getAdapterPosition()) {
            updateNonPlayingView(playingHolder);
            playingHolder = null;
        }
    }

    private void startMediaPlayer(File audioResId) {
        mediaPlayer = MediaPlayer.create(activity, Uri.fromFile(audioResId));
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                releaseMediaPlayer();
            }
        });
        mediaPlayer.start();
    }

    private void releaseMediaPlayer() {
        if (null != playingHolder) {
            updateNonPlayingView(playingHolder);
        }
        mediaPlayer.release();
        mediaPlayer = null;
        currentPlayingPosition = -1;
    }


    void playerPause(View v, File f) {
        if (player != null) {
            player.pause();
        }
        if (updatePlayer != null) {
            handler.removeCallbacks(updatePlayer);
            updatePlayer = null;
        }
        updatePlayerText(v, f);
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(this.activity);
        return new RingtoneAdapter.holder(from.inflate(R.layout.tt_ring_folder7, viewGroup, false));
    }

    public static Uri getSongFileUri(int songId) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId);
    }


    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") int i) {

        handler = new Handler();
        RingtoneAdapter.holder holder2 = (RingtoneAdapter.holder) viewHolder;
        holder2.pos = i;


        final Uri uri = getSongFileUri(albu.get(i).getId());

        Bitmap bitmap;
        try {
            bitmap = MediaStore.Images.Media.getBitmap(activity.getContentResolver(), uri);
        } catch (IOException e) {
            e.printStackTrace();
        }


        if (i == currentPlayingPosition) {
            playingHolder = holder2;
            updatePlayingView();
        } else {
            updateNonPlayingView(holder2);
        }


        File file = new File(albu.get(i).getPath());
        albumInfo documentInfo = albu.get(i);
        holder2.nameTxt.setText("" + albu.get(i).getName());

        long milliseconds = albu.get(i).getArt();


        String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(milliseconds)),
                        Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(milliseconds) % TimeUnit.HOURS.toMinutes(1)),
                        Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(milliseconds) % TimeUnit.MINUTES.toSeconds(1))});


        holder2.duration.setText("" + str);


        if (type.equals("ringtone")) {


            if (dataProccessor.getStr("ringtone") != null) {

                if (dataProccessor.getStr("ringtone").equals(albu.get(i).getName())) {
                    holder2.id_apply.setImageResource(R.drawable.s_applied);

                } else {
                    holder2.id_apply.setImageResource(R.drawable.s_apply);
                }


            }


        } else if (type.equals("notification")) {
            if (dataProccessor.getStr("notification") != null) {

                if (dataProccessor.getStr("notification").equals(albu.get(i).getName())) {
                    holder2.id_apply.setImageResource(R.drawable.s_applied);

                } else {
                    holder2.id_apply.setImageResource(R.drawable.s_apply);
                }


            }


        } else {
            if (dataProccessor.getStr("alarm") != null) {

                if (dataProccessor.getStr("alarm").equals(albu.get(i).getName())) {
                    holder2.id_apply.setImageResource(R.drawable.s_applied);

                } else {
                    holder2.id_apply.setImageResource(R.drawable.s_apply);
                }


            }


        }


        holder2.id_apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (type.equals("ringtone")) {


                    if (requiresDialog(activity)) {
                        showDialog(activity);


                    }


                    else {


                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                            ContentValues values = new ContentValues();
                            values.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
                            values.put(MediaStore.MediaColumns.TITLE, new File(file.getAbsolutePath()).getName());
                            values.put(MediaStore.MediaColumns.SIZE, 215454);
                            values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(file.getAbsolutePath()));
                            values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                            values.put(MediaStore.Audio.Media.DURATION, 230);
                            values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
                            values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                            values.put(MediaStore.Audio.Media.IS_ALARM, false);
                            values.put(MediaStore.Audio.Media.IS_MUSIC, false);


                            final Uri newUri = getSongFileUri(albu.get(i).getId());

                            RingtoneManager.setActualDefaultRingtoneUri(activity, RingtoneManager.TYPE_RINGTONE,
                                    newUri);


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("ringtone", albu.get(i).getName());

                            Toast.makeText(activity, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();


                        } else {


                            final ContentResolver resolver = activity.getContentResolver();
                            final Uri uri = getSongFileUri(albu.get(i).getId());

                            final ContentValues values = new ContentValues(2);
                            values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                            values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                            values.put(MediaStore.MediaColumns.SIZE, 215454);
                            values.put(MediaStore.Audio.Media.DURATION, 230);


                            try {

                                resolver.update(uri, values, null, null);

                            } catch (@NonNull Exception e) {


                                e.printStackTrace();
                                return;
                            }


                            try {
                                try (Cursor cursor = resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                        new String[]{MediaStore.MediaColumns.TITLE},
                                        BaseColumns._ID + "=?",
                                        new String[]{String.valueOf(albu.get(i).getId())},
                                        null)) {
                                    if (cursor != null && cursor.getCount() == 1) {
                                        cursor.moveToFirst();
                                        Settings.System.putString(resolver, Settings.System.RINGTONE, uri.toString());

                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("ringtone", albu.get(i).getName());

                            Toast.makeText(activity, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();


                        }
                    }


                } else if (type.equals("notification")) {

                    if (requiresDialog(activity)) {
                        showDialog(activity);


                    } else {


                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                            ContentValues values = new ContentValues();
                            values.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
                            values.put(MediaStore.MediaColumns.TITLE, new File(file.getAbsolutePath()).getName());
                            values.put(MediaStore.MediaColumns.SIZE, 215454);
                            values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(file.getAbsolutePath()));
                            values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                            values.put(MediaStore.Audio.Media.DURATION, 230);
                            values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                            values.put(MediaStore.Audio.Media.IS_NOTIFICATION, true);
                            values.put(MediaStore.Audio.Media.IS_ALARM, false);
                            values.put(MediaStore.Audio.Media.IS_MUSIC, false);


                            final Uri newUri = getSongFileUri(albu.get(i).getId());

                            RingtoneManager.setActualDefaultRingtoneUri(activity, RingtoneManager.TYPE_NOTIFICATION,
                                    newUri);


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("notification", albu.get(i).getName());

                            Toast.makeText(activity, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();


                        } else {


                            final ContentResolver resolver = activity.getContentResolver();
                            final Uri uri = getSongFileUri(albu.get(i).getId());

                            try {
                                final ContentValues values = new ContentValues(2);
                                values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                resolver.update(uri, values, null, null);


                            } catch (@NonNull Exception e) {
                                e.printStackTrace();
                                return;
                            }

                            try {
                                try (Cursor cursor = resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                        new String[]{MediaStore.MediaColumns.TITLE},
                                        BaseColumns._ID + "=?",
                                        new String[]{String.valueOf(albu.get(i).getId())},
                                        null)) {
                                    if (cursor != null && cursor.getCount() == 1) {
                                        cursor.moveToFirst();
                                        Settings.System.putString(resolver, Settings.System.NOTIFICATION_SOUND, uri.toString());

                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("notification", albu.get(i).getName());

                            Toast.makeText(activity, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();


                        }


                    }
                }



                    else {

                    if (requiresDialog(activity)) {
                        showDialog(activity);


                    }

                    else {

                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                            ContentValues values = new ContentValues();
                            values.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
                            values.put(MediaStore.MediaColumns.TITLE, new File(file.getAbsolutePath()).getName());
                            values.put(MediaStore.MediaColumns.SIZE, 215454);
                            values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(file.getAbsolutePath()));
                            values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                            values.put(MediaStore.Audio.Media.DURATION, 230);
                            values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                            values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                            values.put(MediaStore.Audio.Media.IS_ALARM, true);
                            values.put(MediaStore.Audio.Media.IS_MUSIC, false);


                            final Uri newUri = getSongFileUri(albu.get(i).getId());
                            RingtoneManager.setActualDefaultRingtoneUri(activity, RingtoneManager.TYPE_ALARM,
                                    newUri);


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("alarm", albu.get(i).getName());

                            Toast.makeText(activity, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();


                        } else {


                            final ContentResolver resolver = activity.getContentResolver();
                            final Uri uri = getSongFileUri(albu.get(i).getId());

                            try {
                                final ContentValues values = new ContentValues(2);
                                values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                resolver.update(uri, values, null, null);


                            } catch (@NonNull Exception e) {
                                e.printStackTrace();
                                return;
                            }

                            try {
                                try (Cursor cursor = resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                        new String[]{MediaStore.MediaColumns.TITLE},
                                        BaseColumns._ID + "=?",
                                        new String[]{String.valueOf(albu.get(i).getId())},
                                        null)) {
                                    if (cursor != null && cursor.getCount() == 1) {
                                        cursor.moveToFirst();
                                        Settings.System.putString(resolver, Settings.System.ALARM_ALERT, uri.toString());

                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                            if (i == i) {
                                holder2.id_apply.setImageResource(R.drawable.s_applied);

                            } else {
                                holder2.id_apply.setImageResource(R.drawable.s_apply);
                            }

                            dataProccessor.setStr("alarm", albu.get(i).getName());

                            Toast.makeText(activity, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();
                            activity.finish();
                        }
                    }


                }


            }
        });


        holder2.id_palypause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (i == currentPlayingPosition) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                    } else {
                        mediaPlayer.start();
                    }
                } else {
                    currentPlayingPosition = i;
                    if (mediaPlayer != null) {
                        if (null != playingHolder) {
                            updateNonPlayingView(playingHolder);
                        }
                        mediaPlayer.release();
                    }
                    playingHolder = holder2;
                    startMediaPlayer(new File(albu.get(currentPlayingPosition).getPath()));
                }
                updatePlayingView();


                filePAthdata.fitdat2(null, mediaPlayer, holder2.id_palypause);


            }
        });


    }


    public Filter getFilter() {
        return new Filter() {
            public FilterResults performFiltering(CharSequence charSequence) {


                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    RingtoneAdapter videoAdapter = RingtoneAdapter.this;
                    List unused = videoAdapter.albu = videoAdapter.dup_items;
                } else {
                    ArrayList arrayList = new ArrayList();

                    for (albumInfo videoItem : RingtoneAdapter.this.dup_items) {


                        if (videoItem.getName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(videoItem);
                        }
                    }
                    List unused2 = RingtoneAdapter.this.albu = arrayList;


                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = RingtoneAdapter.this.albu;
                return filterResults;


            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {

                List unused = RingtoneAdapter.this.albu = (ArrayList<albumInfo>) filterResults.values;
                notifyDataSetChanged();

                if(albu.size()<=0)
                {
                    noVideoLayout.setVisibility(View.VISIBLE);
                }
                else

                {

                    noVideoLayout.setVisibility(View.GONE);
                }
            }
        };
    }

    boolean updatePlayerText(final View v, final File f) {
        ImageView i = (ImageView) v.findViewById(R.id.id_palypause);

        final boolean playing = player != null && player.isPlaying();

        i.setImageResource(playing ? R.drawable.pause_yellow : R.drawable.play_yellow);


        int c = 0;


        if (player != null) {
            c = player.getCurrentPosition();
        }


        return playing;

    }


    public static MaterialDialog showDialog(Context context) {

        return new MaterialDialog.Builder(context)
                .backgroundColorRes(R.color.home_top6s)
                .title(R.string.dialog_ringtone_title)
                .titleColor(ContextCompat.getColor(context, R.color.black))
                .content(R.string.dialog_ringtone_message)
                .contentColor(ContextCompat.getColor(context, R.color.black))
                .positiveText(android.R.string.ok)
                .positiveColor(ContextCompat.getColor(context, R.color.thm_6))
                .negativeText(android.R.string.cancel)
                .negativeColor(ContextCompat.getColor(context, R.color.thm_6))
                .onPositive((dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    context.startActivity(intent);
                })
                .show();


    }

    public static boolean requiresDialog(@NonNull Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return !Settings.System.canWrite(context);
        }
        return false;
    }


    void updatePlayerRun(final View v, final File f) {
        boolean playing = updatePlayerText(v, f);

        if (updatePlayer != null) {
            handler.removeCallbacks(updatePlayer);
            updatePlayer = null;
        }

        if (!playing) {
            return;
        }

        updatePlayer = new Runnable() {
            @Override
            public void run() {
                updatePlayerRun(v, f);
            }
        };
        handler.postDelayed(updatePlayer, 200);
    }


    void playerPlay(View v, File f) {
        if (player == null)
            player = MediaPlayer.create(activity, Uri.fromFile(f));
        if (player == null) {
            Toast.makeText(activity, R.string.file_not_found, Toast.LENGTH_SHORT).show();
            return;
        }
        player.start();

        updatePlayerRun(v, f);
    }

    public int getItemCount() {
        return this.albu.size();
    }

    class holder extends RecyclerView.ViewHolder {

        TextView nameTxt;

        int pos;
        TextView duration;
        ConstraintLayout linearLayout;
        ImageView thmImg;
        View playerBase;

        private ImageView id_apply;

        ImageView id_palypause;

        holder(View view) {
            super(view);


            nameTxt = view.findViewById(R.id.name);
            duration = view.findViewById(R.id.duration);
            thmImg = view.findViewById(R.id.thmImg);
            id_palypause = view.findViewById(R.id.id_palypause);
            linearLayout = view.findViewById(R.id.card);
            id_apply = view.findViewById(R.id.id_apply);


        }
    }
}
