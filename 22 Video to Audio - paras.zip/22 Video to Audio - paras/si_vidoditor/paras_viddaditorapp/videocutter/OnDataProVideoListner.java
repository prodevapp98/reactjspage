package com.si_vidoditor.paras_viddaditorapp.videocutter;



public interface OnDataProVideoListner {
    void updateProgress(int i, int i2, float f);
}


