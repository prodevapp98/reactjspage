package com.si_vidoditor.paras_viddaditorapp.videocutter;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.si_vidoditor.paras_viddaditorapp.outputfolder.RingToneVAultAdapter.getMimeType;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;

import org.cmc.music.common.ID3WriteException;
import org.cmc.music.metadata.ImageData;
import org.cmc.music.metadata.MusicMetadata;
import org.cmc.music.metadata.MusicMetadataSet;
import org.cmc.music.myid3.MyID3;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;




public class OutputTrimimgActivity extends AppCompatActivity implements Runnable {

    SeekBar seekBar;
    MediaPlayer mp = new MediaPlayer();
    int idm = 0;
    private ImageView imageView;
    private Dialog dialog2;
    private Bitmap bitmaoAll = null;
    private ImageView iv_shoa;
    String path;
    private TextView name_s, size_s;
    ImageView iv_playpause;
    private TextView tv_totyal;
    TextView seekBarHint;
    private DataProccessor dataProccessor;


    private ConstraintLayout btn_setac, cl_share, id_openwith;

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clearMediaPlayer();
    }

    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID},
                MediaStore.Audio.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));


            cursor.close();
            return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {






            return null;

        }


    }

    private void startActivity(Intent intent, @StringRes int resId) {
        try {
            startActivity(intent);
        } catch (Exception e) {

        }
    }

    private Intent shareSingleIntent(Uri uri, String type) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        return intent;
    }

    private boolean isResolvable(Intent intent) {
        PackageManager manager = getPackageManager();
        List<ResolveInfo> resolveInfo = manager.queryIntentActivities(intent, 0);

        return !resolveInfo.isEmpty();
    }


    public Uri uri(Context context, File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                return FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", file);
            } catch (Exception e) {
                return Uri.fromFile(file);
            }
        } else {
            return Uri.fromFile(file);
        }
    }


    private void shareSingle(File fileInfo) {
        try {
            String type = "audio/*";
            Intent intent = shareSingleIntent(uri(OutputTrimimgActivity.this, fileInfo), type);

            if (isResolvable(intent)) {
                startActivity(intent, R.string.shareFile_unable);
            } else {
                Toast.makeText(OutputTrimimgActivity.this, R.string.shareFile_unable, Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {

        }
    }

    public static MaterialDialog showDialog(Context context) {

        return new MaterialDialog.Builder(context)
                .backgroundColorRes(R.color.home_top1)
                .title(R.string.dialog_ringtone_title)
                .titleColor(ContextCompat.getColor(context, R.color.black))
                .content(R.string.dialog_ringtone_message)
                .contentColor(ContextCompat.getColor(context, R.color.black))
                .positiveText(android.R.string.ok)
                .positiveColor(ContextCompat.getColor(context, R.color.thm_1))
                .negativeText(android.R.string.cancel)
                .negativeColor(ContextCompat.getColor(context, R.color.thm_1))
                .onPositive((dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    context.startActivity(intent);
                })
                .show();


    }

    public static boolean requiresDialog(@NonNull Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return !Settings.System.canWrite(context);
        }
        return false;
    }


    @Override
    protected void onPause() {
        super.onPause();

        if (mp != null) {

            if (mp.isPlaying()) {

                iv_playpause.setImageResource(R.drawable.ic_playvi4);
                mp.pause();
            }
        }

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onStart() {
        super.onStart();


    }

    public static Uri getSongFileUri(int songId) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uou_put_trimimg_activty);

        dataProccessor = new DataProccessor(OutputTrimimgActivity.this);


        changeColor(R.color.home_top1);
        iv_shoa = findViewById(R.id.thumb);
        iv_playpause = findViewById(R.id.iv_playpause);
        seekBar = findViewById(R.id.sv_view);
        seekBarHint = findViewById(R.id.seekBarHint);
        tv_totyal = findViewById(R.id.tv_totyal);


        imageView = findViewById(R.id.imageView);
        name_s = findViewById(R.id.name);
        size_s = findViewById(R.id.size);


        btn_setac = findViewById(R.id.btn_setac);
        cl_share = findViewById(R.id.cl_share);
        id_openwith = findViewById(R.id.id_openwith);

        BaseLayoutVidoEditor.showNativeOnce(this, findViewById(R.id.framLarge), findViewById(R.id.rlNative) );

        id_openwith.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {

                    if (mp.isPlaying()) {

                        iv_playpause.setImageResource(R.drawable.ic_playvi4);
                        mp.pause();
                    }
                }

                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setFlags(335544320);
                if (Build.VERSION.SDK_INT >= 22) {
                    intent.setDataAndType(FileProvider.getUriForFile(OutputTrimimgActivity.this, getPackageName()
                            + ".provider", new File(path)), "audio/*");
                } else {
                    intent.setDataAndType(Uri.fromFile(new File(path)), "audio/*");
                }
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, 100);


            }
        });


        cl_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {
                    if (mp.isPlaying()) {

                        iv_playpause.setImageResource(R.drawable.ic_playvi4);
                        mp.pause();
                    }
                }


                shareSingle(new File(path));
            }
        });

        btn_setac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp != null) {

                    if (mp.isPlaying()) {

                        iv_playpause.setImageResource(R.drawable.ic_playvi4);
                        mp.pause();
                    }
                }


                Dialog dialog2 = new Dialog(OutputTrimimgActivity.this);
                dialog2.setContentView(R.layout.ringtone_dialog);


                ImageView cancel = dialog2.findViewById(R.id.cancel);
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                    }
                });

                ConstraintLayout cl_rintone = dialog2.findViewById(R.id.cl_rintone);
                ConstraintLayout cl_noti = dialog2.findViewById(R.id.cl_noti);
                ConstraintLayout cl_alarm = dialog2.findViewById(R.id.cl_alarm);


                cl_rintone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                        if (requiresDialog(OutputTrimimgActivity.this)) {
                            showDialog(OutputTrimimgActivity.this);


                        } else {



                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, path);
                                values.put(MediaStore.MediaColumns.TITLE, new File(path).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(path));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                                values.put(MediaStore.Audio.Media.IS_ALARM, false);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);


                                Uri newUri = getImageContentUri(OutputTrimimgActivity.this, new File(path));


                                RingtoneManager.setActualDefaultRingtoneUri(OutputTrimimgActivity.this,
                                        RingtoneManager.TYPE_RINGTONE,
                                        newUri);




                                dataProccessor.setStr("ringtone", new File(path).getName());

                                Toast.makeText(OutputTrimimgActivity.this, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();

                            }



                            else {


                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputTrimimgActivity.this, new File(path));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {

                                    Settings.System.putString(resolver, Settings.System.RINGTONE, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("ringtone", new File(path).getName());

                                Toast.makeText(OutputTrimimgActivity.this, "Set Ringtone Successfully", Toast.LENGTH_SHORT).show();


                            }






                        }

                    }
                });

                cl_noti.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                        if (requiresDialog(OutputTrimimgActivity.this)) {
                            showDialog(OutputTrimimgActivity.this);


                        } else {




                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, path);
                                values.put(MediaStore.MediaColumns.TITLE, new File(path).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(path));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, true);
                                values.put(MediaStore.Audio.Media.IS_ALARM, false);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);



                                Uri newUri = getImageContentUri(OutputTrimimgActivity.this, new File(path));
                                RingtoneManager.setActualDefaultRingtoneUri(OutputTrimimgActivity.this,
                                        RingtoneManager.TYPE_NOTIFICATION,
                                        newUri);




                                dataProccessor.setStr("notification", new File(path).getName());

                                Toast.makeText(OutputTrimimgActivity.this, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();


                            }


                            else {
                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputTrimimgActivity.this, new File(path));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {
                                    Settings.System.putString(resolver, Settings.System.NOTIFICATION_SOUND, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("notification", new File(path).getName());

                                Toast.makeText(OutputTrimimgActivity.this, "Set Notification Sound Successfully", Toast.LENGTH_SHORT).show();

                            }

                        }
                    }
                });
                cl_alarm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();

                        if (requiresDialog(OutputTrimimgActivity.this)) {
                            showDialog(OutputTrimimgActivity.this);


                        } else {


                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.MediaColumns.DATA, path);
                                values.put(MediaStore.MediaColumns.TITLE, new File(path).getName());
                                values.put(MediaStore.MediaColumns.SIZE, 215454);
                                values.put(MediaStore.MediaColumns.MIME_TYPE, getMimeType(path));
                                values.put(MediaStore.Audio.Media.ARTIST, R.string.app_name);
                                values.put(MediaStore.Audio.Media.DURATION, 230);
                                values.put(MediaStore.Audio.Media.IS_RINGTONE, false);
                                values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
                                values.put(MediaStore.Audio.Media.IS_ALARM, true);
                                values.put(MediaStore.Audio.Media.IS_MUSIC, false);



                                Uri newUri = getImageContentUri(OutputTrimimgActivity.this, new File(path));

                                RingtoneManager.setActualDefaultRingtoneUri(OutputTrimimgActivity.this,
                                        RingtoneManager.TYPE_ALARM,
                                        newUri);



                                dataProccessor.setStr("alarm", new File(path).getName());
                                Toast.makeText(OutputTrimimgActivity.this, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();



                            }


                            else {

                                ContentResolver resolver = getContentResolver();

                                Uri uri = getImageContentUri(OutputTrimimgActivity.this, new File(path));


                                try {
                                    final ContentValues values = new ContentValues(2);
                                    values.put(MediaStore.Audio.AudioColumns.IS_RINGTONE, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_ALARM, "1");
                                    values.put(MediaStore.Audio.AudioColumns.IS_NOTIFICATION, "1");
                                    values.put(MediaStore.MediaColumns.SIZE, 215454);
                                    values.put(MediaStore.Audio.Media.DURATION, 230);
                                    resolver.update(uri, values, null, null);


                                } catch (@NonNull Exception e) {
                                    e.printStackTrace();
                                    return;
                                }

                                try {

                                    Settings.System.putString(resolver, Settings.System.ALARM_ALERT, uri.toString());


                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                                dataProccessor.setStr("alarm", new File(path).getName());


                                Toast.makeText(OutputTrimimgActivity.this, "Set Alarm Sound Successfully", Toast.LENGTH_SHORT).show();

                            }
                        }

                    }
                });


                Window window2 = dialog2.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog2.setCancelable(false);

                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog2.show();


            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        String genre = getIntent().getStringExtra("genre");
        String artist = getIntent().getStringExtra("artist");
        String album = getIntent().getStringExtra("album");
        String title = getIntent().getStringExtra("title");
        String audioFormat = getIntent().getStringExtra("audioFormat");
        String bitrate = getIntent().getStringExtra("bitrate");
        String srcimg = getIntent().getStringExtra("srcimg");
        String name = getIntent().getStringExtra("name");
        String duration = getIntent().getStringExtra("duration");
        Integer pd = getIntent().getIntExtra("pd", 0);
        String startTime = getIntent().getStringExtra("startTime");
        String endTime = getIntent().getStringExtra("endTime");
        String channel = getIntent().getStringExtra("channel");
        String coverimage = getIntent().getStringExtra("coverimage");
        path = getIntent().getStringExtra("path");





        if (audioFormat.equals("mp3")) {

            if (coverimage != null) {

                bitmaoAll = uriToBitmap(Uri.parse(coverimage), OutputTrimimgActivity.this);

                try {
                    int w = bitmaoAll.getWidth();
                    int h = bitmaoAll.getHeight();
                    float s = Math.max(w / 2048.0f, h / 2048.0f);

                    if (s > 1.0f) {
                        w /= s;
                        h /= s;
                        bitmaoAll = Bitmap.createScaledBitmap(bitmaoAll, w, h, false);
                    } else {
                        bitmaoAll = bitmaoAll;
                    }


                    iv_shoa.setImageBitmap(bitmaoAll);


                } catch (Exception e) {
                    e.printStackTrace();


                }
            }


        }


        new DoBacckfff(bitmaoAll, endTime,
                OutputTrimimgActivity.this,
                genre,
                artist,
                album,
                title,
                audioFormat,
                bitrate,
                srcimg.toString(),
                name,
                duration,
                pd,
                startTime,
                channel);


        iv_playpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                try {

                    if (mp == null) {
                        mp = new MediaPlayer();
                        mp.setDataSource(path);
                        mp.prepare();
                        mp.setVolume(0.5f, 0.5f);
                        mp.setLooping(false);
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }



                if (mp.isPlaying()) {
                    iv_playpause.setImageResource(R.drawable.ic_playvi4);
                    mp.pause();


                } else {

                    iv_playpause.setImageResource(R.drawable.pause_21);

                    mp.start();
                    seekBar.setMax(mp.getDuration());
                    new Thread(OutputTrimimgActivity.this).start();


                }


            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

                seekBarHint.setVisibility(View.VISIBLE);
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {
                seekBarHint.setVisibility(View.VISIBLE);


                int x = (int) Math.ceil(progress / 1000f);

                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                seekBarHint.setText("" + str);





                if (x == (int) Math.ceil(seekBar.getMax() / 1000f) && mp != null && !mp.isPlaying()) {


                    iv_playpause.setImageResource(R.drawable.ic_playvi4);
                    clearMediaPlayer();
                    seekBar.setProgress(0);


                }


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {


                if (mp != null && mp.isPlaying()) {
                    mp.seekTo(seekBar.getProgress());
                }
            }
        });

    }

    private void clearMediaPlayer() {
        if (mp != null) {
            mp.stop();
            mp.release();
            mp = null;
        }
    }


    public void run() {

        int currentPosition = mp.getCurrentPosition();
        int total = mp.getDuration();


        while (mp != null && mp.isPlaying() && currentPosition < total) {
            try {
                Thread.sleep(1000);
                currentPosition = mp.getCurrentPosition();
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                return;
            }

            seekBar.setProgress(currentPosition);

        }
    }


    public class DoBacckfff {

        private String album;
        private String artist;
        private String audioFormat;
        private String audioPath1;
        private String audioPath;
        private String bitrate;
        private Context context;
        private String genre;
        private String name;
        private File root;
        private File temp;

        private String title;
        private String videoPath;
        private Bitmap bitmaoAll;
        private ProgressBar progressBar;
        public String duration;
        public int pd;
        public String startTime;
        private String channel;

        private Dialog dialog2;

        private String chantype;

        private TextView tv_re;


        private String endtime;

        private File file2;

        public DoBacckfff(Bitmap bitmaoAll1,
                          String endtime1,
                          Context context2, String str,
                          String str2, String str3,
                          String str4, String str5, String str6,
                          String str7,
                          String str8,
                          String duration1,
                          int pd1,
                          String startTime1,
                          String channel) {
            context = context2;
            genre = str;
            artist = str2;
            album = str3;
            title = str4;
            audioFormat = str5;
            bitrate = str6;
            videoPath = str7;
            name = str8;
            this.endtime = endtime1;
            duration = duration1;
            pd = pd1;
            startTime = startTime1;
            this.channel = channel;

            if (channel.equals("Stereo")) {
                chantype = "-ac 2";
            } else {
                chantype = "-ac 1";

            }

            if (audioFormat.equals("mp3")) {

                bitmaoAll = bitmaoAll1;
            } else {
                bitmaoAll = null;

            }





            this.root = getExternalFilesDir("");;


            File file = new File(this.root.getAbsolutePath() +
                    "/" + context2.getString(R.string.app_name)
                    + "/VideoToMp3");
            if (!file.exists()) {
                file.mkdirs();
            }


            file2 = new File(this.root.getAbsolutePath() +
                    "/" + context2.getString(R.string.app_name)
                    + "/VideoToMp3Te");


            if (!file2.exists()) {
                file2.mkdirs();
            }


            String extension = videoPath.substring(videoPath.lastIndexOf("."));

            if (str8.contains(".")) {
                if (str8.indexOf(".") > 0)
                    str8 = str8.substring(0, name.lastIndexOf("."));
            }





            this.audioPath1 = this.root.getAbsolutePath() +
                    "/" + context2.getString(R.string.app_name)

                    + "/VideoToMp3Te/" + str8 + "Ext" + extension;


            this.audioPath = this.root.getAbsolutePath() +
                    "/" + context2.getString(R.string.app_name)
                    + "/VideoToMp3/" + str8 + "." + str5;






            StringBuilder sb = new StringBuilder();
            sb.append(this.root.getAbsolutePath());
            sb.append("/");
            sb.append(context2.getString(R.string.app_name));
            sb.append("/Temp");


            this.temp = new File(sb.toString());
            if (!this.temp.exists()) {
                this.temp.mkdirs();
            }


            dialog2 = new Dialog(context2);
            dialog2.setContentView(R.layout.loadercon_dialog2);
            CardView lv_1 = dialog2.findViewById(R.id.lv_1);
            ProgressBar mk_lod = dialog2.findViewById(R.id.mk_lod);
            Window window2 = dialog2.getWindow();
            WindowManager.LayoutParams wlp1 = window2.getAttributes();
            window2.setAttributes(wlp1);
            dialog2.setCancelable(false);

            tv_re = dialog2.findViewById(R.id.tv_re);
            progressBar = dialog2.findViewById(R.id.progressBar);

            window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog2.show();




            new ExtractAudio().execute(new Void[0]);
        }

        private void setMetaData(String str) {
            MusicMetadataSet musicMetadataSet;
            File file = new File(str);
            try {
                musicMetadataSet = new MyID3().read(file);
            } catch (IOException e) {
                e.printStackTrace();
                musicMetadataSet = null;
            }
            if (musicMetadataSet == null) {
                Log.i("NULL", "NULL");
                return;
            }
            MusicMetadata musicMetadata = new MusicMetadata("name");




            if (bitmaoAll != null) {
                Bitmap bitmap = bitmaoAll;

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] bitmapdata = stream.toByteArray();
                ImageData imageData = new ImageData(bitmapdata, "image/jpeg", "arun photo", 1);

                musicMetadata.addPicture(imageData);

            }


            musicMetadata.setSongTitle(this.title);
            musicMetadata.setArtist(this.artist);
            musicMetadata.setAlbum(this.album);
            musicMetadata.setGenre(this.genre);


            try {
                new MyID3().update(file, musicMetadataSet, musicMetadata);

            } catch (UnsupportedEncodingException e2) {
                e2.printStackTrace();
            } catch (ID3WriteException e3) {
                e3.printStackTrace();
            } catch (IOException e4) {
                e4.printStackTrace();
            }
        }


        @SuppressLint({"StaticFieldLeak"})
        private class ExtractAudio extends AsyncTask<Void, Void, Void> {
            private ExtractAudio() {
            }


            public void onPreExecute() {
                super.onPreExecute();


            }

            public Void doInBackground(Void... voidArr) {



                String[] cmd =
                        {"-i", videoPath, "-ss", startTime, "-to", endtime, "-c:v", "copy",
                                "-c:a", "copy", audioPath1};


                long executionId = FFmpeg.executeAsync(cmd, new ExecuteCallback() {

                    @Override
                    public void apply(final long executionId, final int returnCode) {
                        if (returnCode == RETURN_CODE_SUCCESS) {





                            new ExtractAudio2(dialog2).execute();


                        } else if (returnCode == RETURN_CODE_CANCEL) {
                            dialog2.dismiss();

                        } else {
                            dialog2.dismiss();

                        }

                    }
                });





                return null;
            }

            public void onPostExecute(Void r1) {
                super.onPostExecute(r1);
            }
        }

        private void dataConvert(String[] cmd, Dialog dialog2) {

            long executionId2 = FFmpeg.executeAsync(cmd, new ExecuteCallback() {

                @Override
                public void apply(final long executionId2, final int returnCode2) {
                    if (returnCode2 == RETURN_CODE_SUCCESS) {


                        if (bitrate.equals("default")) {

                            setMetaData(audioPath);


                            if (file2.exists()) {
                                for (int i = 0; i < file2.listFiles().length; i++) {
                                    if (file2.listFiles()[i].exists()) {
                                        file2.listFiles()[i].delete();
                                    }
                                }

                                file2.delete();


                            }

                            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent.setData(Uri.fromFile(file2));
                            sendBroadcast(intent);


                            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent2.setData(Uri.fromFile(new File(audioPath)));
                            sendBroadcast(intent2);


                            dialog2.dismiss();




                try {


                    mp.setDataSource(path);
                    mp.prepare();
                    mp.setVolume(0.5f, 0.5f);
                    mp.setLooping(false);


                    long progress = mp.getDuration();
                    String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                            new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                    Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                    Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                    tv_totyal.setText("" + str);
                    size_s.setText("" +str);


                } catch (Exception e) {
                    e.printStackTrace();
                }

                name_s.setText("" + new File(audioPath).getName());




                        }



                        else {



                            if (file2.exists()) {
                                for (int i = 0; i < file2.listFiles().length; i++) {
                                    if (file2.listFiles()[i].exists()) {
                                        file2.listFiles()[i].delete();
                                    }
                                }

                                file2.delete();


                            }

                            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent.setData(Uri.fromFile(file2));
                            sendBroadcast(intent);


                            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent2.setData(Uri.fromFile(new File(audioPath)));
                            sendBroadcast(intent2);

                            try {


                                mp.setDataSource(path);
                                mp.prepare();
                                mp.setVolume(0.5f, 0.5f);
                                mp.setLooping(false);


                                long progress = mp.getDuration();
                                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(progress)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(progress) % TimeUnit.HOURS.toMinutes(1)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(progress) % TimeUnit.MINUTES.toSeconds(1))});


                                tv_totyal.setText("" + str);
                                size_s.setText("" +str);


                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            name_s.setText("" + new File(audioPath).getName());



                            dialog2.dismiss();



                        }







                    } else if (returnCode2 == RETURN_CODE_CANCEL) {
                        dialog2.dismiss();

                    } else {
                        dialog2.dismiss();

                    }

                }
            });


        }


        private class ExtractAudio2 extends AsyncTask<Void, Void, Void> {
            private ExtractAudio2(Dialog dialog) {
            }


            public void onPreExecute() {
                super.onPreExecute();


            }

            public Void doInBackground(Void... voidArr) {




                if (bitrate.equals("default")) {

                    String[] strArr = {"-y", "-i", audioPath1,
                            "-vn",
                            audioPath};
                    dataConvert(strArr, dialog2);


                } else {



                    String[] strArr = {"-y", "-i", audioPath1,
                            "-vn",
                            audioPath};
                    dataConvert(strArr, dialog2);


                }


                return null;
            }

            public void onPostExecute(Void r1) {
                super.onPostExecute(r1);
            }
        }


        private void deleteDirectory(File file) {
            if (file.isDirectory()) {
                for (String str : file.list()) {
                    new File(file, str).delete();
                }
            }
        }

        private int getID() {
            return new AtomicInteger(0).incrementAndGet();
        }

        private void cancelNotification(Context context2, int i) {
            ((NotificationManager) context2.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(i);
        }


    }


    public static Bitmap uriToBitmap(Uri selectedFileUri, Context context) {
        Bitmap image = null;

        try {
            ParcelFileDescriptor parcelFileDescriptor = context.getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }


}