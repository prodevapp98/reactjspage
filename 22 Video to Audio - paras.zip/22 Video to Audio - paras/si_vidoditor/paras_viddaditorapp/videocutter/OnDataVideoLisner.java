package com.si_vidoditor.paras_viddaditorapp.videocutter;

public interface OnDataVideoLisner {
    void onVideoPrepared();
}
