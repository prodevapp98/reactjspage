package com.si_vidoditor.paras_viddaditorapp.videocutter;

import android.net.Uri;

public interface onTrimDataLisner {
    void cancelAction();

    void getResult(Uri uri);

    void onError(String str);

    void onTrimStarted();
}
