package com.si_vidoditor.paras_viddaditorapp.videocutter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;


import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.utils.RunThredEx;
import com.si_vidoditor.paras_viddaditorapp.view.VTOBackgroundExecutor;
import com.si_vidoditor.paras_viddaditorapp.view.VTOOnRangeSeekBarListener;
import com.si_vidoditor.paras_viddaditorapp.view.VTOProgressBarView;
import com.si_vidoditor.paras_viddaditorapp.view.VTORangeSeekBarView;
import com.si_vidoditor.paras_viddaditorapp.view.VTOTimeLineView;
import com.si_vidoditor.paras_viddaditorapp.view.VTOTrimVideoUtils;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class CutterActivity extends AppCompatActivity
        implements onTrimDataLisner, OnDataVideoLisner, AdapterView.OnItemSelectedListener {
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public int avint;
    public int savb;



    private static final String TAG = "HgLVideoTrimmer";
    String album;
    String artist;
    String channel = "Stereo";

    private Bitmap bitmaoAll = null;
    private String coverimage = null;


    private ConstraintLayout btSave, btSave2;

    String audioFormat;
    private ConstraintLayout audioSetting;
    String bitrate;
    private ConstraintLayout btn_edit_tag;

    private EditText et_audioname;
    String genre;

    private int mDuration;
    private int mEndPosition;
    private String mFinalPath;
    private SeekBar mHolderTopView;
    private ConstraintLayout constraintLayout6;

    private LinearLayout mLinearVideo;
    private List<OnDataProVideoListner> mListeners;
    private int mMaxDuration;

    private OnDataVideoLisner mOnHgLVideoListener;
    private onTrimDataLisner mOnTrimVideoListener;
    private long mOriginSizeFile;
    private ImageView mPlayView;
    private VTORangeSeekBarView mRangeSeekBarView;
    private boolean mResetSeekBar;
    private Uri mSrc;
    private int mStartPosition;
    private TextView mTextSize;
    private TextView mTextTime;
    private ConstraintLayout mTimeInfoContainer;
    private VTOTimeLineView mTimeLineView;
    private int mTimeVideo;
    private VTOProgressBarView mVideoProgressIndicator;
    private VideoView mVideoView;
    private Spinner spinner_audioformat;
    private Spinner spinner_bitrate;
    String title;


    private ImageView iv_shoa;

    private ConstraintLayout cl_coversong;


    public String duration;
    public int pd;
    public String startTime;
    public String endTime;

    private Dialog dialog2;

    private ConstraintLayout constraintLayout;
    private ConstraintLayout constraintLayout2;


    private TextView textView12;
    private TextView iv_totaltime;

    private View view3423;

    private ConstraintLayout constraintLayout3, cl_alltotal, constraintLayout8;

    private ImageView imageView4, imageView5, imageView42, imageView52;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_si_trimmer);


        Intent intent = getIntent();
        avint = intent.getIntExtra("avint", 0);
        savb = intent.getIntExtra("savb", 0);




        showDialog();


        String str = "";
        int i = 10;

        if (intent != null) {
            str = intent.getStringExtra("EXTRA_VIDEO_PATH");
            MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();

            try {
                mediaMetadataRetriever.setDataSource(getApplicationContext(), Uri.fromFile(new File(str)));
                long parseLong = Long.parseLong(mediaMetadataRetriever.extractMetadata(9));
                mediaMetadataRetriever.release();

                i = (int) parseLong;
            }
            catch (Exception e)
            {

                if(dialog2!=null) {
                    dialog2.dismiss();
                }
                Toast.makeText(CutterActivity.this, "File not converted properly!", Toast.LENGTH_SHORT).show();
                finish();
            }





        }

        mDuration = 0;
        mTimeVideo = 0;
        mStartPosition = 0;
        mEndPosition = 0;
        mResetSeekBar = true;

        genre = "Unknown";
        audioFormat = "mp3";
        bitrate = "default";




        new Handler().postDelayed(new Runnable() {

            public void run() {
                if(dialog2!= null) {
                    dialog2.dismiss();
                }
            }
        }, 3000);


        mDuration = 0;
        mTimeVideo = 0;
        mStartPosition = 0;
        mEndPosition = 0;
        mResetSeekBar = true;
        genre = "Unknown";
        audioFormat = "mp3";
        bitrate = "default";
        init();

        setMaxDuration(i);
        setOnTrimVideoListener(this);
        setOnHgLVideoListener(this);
        setVideoURI(Uri.parse(str), Uri.fromFile(new File(str)));
        setVideoInformationVisibility(true);





        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRangeSeekBarView.plussk1();

            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRangeSeekBarView.minussk1();
            }
        });

        imageView42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRangeSeekBarView.minussk2();




            }
        });

        imageView52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mRangeSeekBarView.plussk2();

            }
        });





    }

    private void showDialog() {
        dialog2 = new Dialog(CutterActivity.this);
        dialog2.setContentView(R.layout.loaderbanner_dialog2);
        CardView lv_1 = dialog2.findViewById(R.id.lv_1);
        ProgressBar mk_lod = dialog2.findViewById(R.id.mk_lod);
        if (savb == 1) {


        } else {

            lv_1.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.home_top4)));
            mk_lod.setIndeterminateTintList(ColorStateList.valueOf(getResources().getColor(R.color.thm_4)));

        }


        Window window2 = dialog2.getWindow();
        WindowManager.LayoutParams wlp1 = window2.getAttributes();
        window2.setAttributes(wlp1);
        dialog2.setCancelable(false);
        window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog2.show();

    }

    @Override
    public void onTrimStarted() {

        dialog2 = new Dialog(CutterActivity.this);
        dialog2.setContentView(R.layout.loadercon_dialog2);
        CardView lv_1 = dialog2.findViewById(R.id.lv_1);
        ProgressBar mk_lod = dialog2.findViewById(R.id.mk_lod);
        Window window2 = dialog2.getWindow();
        WindowManager.LayoutParams wlp1 = window2.getAttributes();
        window2.setAttributes(wlp1);
        dialog2.setCancelable(false);



        TextView tv_re = dialog2.findViewById(R.id.tv_re);
        ProgressBar progressBar = dialog2.findViewById(R.id.progressBar);

        tv_re.setTextColor(getResources().getColor(R.color.thm_4));
        progressBar.setIndeterminateTintList(ColorStateList.valueOf(getResources().getColor(R.color.thm_4)));

        window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog2.show();








    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @SuppressLint("ResourceType")
    private void init() {


        imageView4 = findViewById(R.id.imageView4);
        imageView5 = findViewById(R.id.imageView5);
        imageView42 = findViewById(R.id.imageView42);
        imageView52 = findViewById(R.id.imageView52);
        btSave = findViewById(R.id.btSave);
        btSave2 = findViewById(R.id.btSave2);


        mHolderTopView = findViewById(R.id.handlerTop);
        mVideoProgressIndicator = findViewById(R.id.timeVideoView);
        mRangeSeekBarView = findViewById(R.id.timeLineBar);
        mLinearVideo = findViewById(R.id.layout_surface_view);
        mVideoView = findViewById(R.id.video_loader);

        constraintLayout6 = findViewById(R.id.constraintLayout6);
        constraintLayout2 = findViewById(R.id.constraintLayout2);
        view3423 = findViewById(R.id.view3423);


        cl_coversong = findViewById(R.id.cl_coversong);
        constraintLayout = findViewById(R.id.constraintLayout);
        textView12 = findViewById(R.id.textView12);


        constraintLayout3 = findViewById(R.id.constraintLayout3);
        cl_alltotal = findViewById(R.id.cl_alltotal);
        constraintLayout8 = findViewById(R.id.constraintLayout8);


        mPlayView = findViewById(R.id.icon_video_play);
        mTimeInfoContainer = findViewById(R.id.timeText);
        mTextSize = findViewById(R.id.textSize);
        mTextTime = findViewById(R.id.textTime);
        iv_totaltime = findViewById(R.id.iv_totaltime);
        mTimeLineView = findViewById(R.id.timeLineView);
        audioSetting = findViewById(R.id.audio_setting);
        et_audioname = findViewById(R.id.et_filename);
        spinner_audioformat = findViewById(R.id.spinner_audioformat);
        spinner_bitrate = findViewById(R.id.spinner_bitrate);
        btn_edit_tag = findViewById(R.id.btn_edittag);
        iv_shoa = findViewById(R.id.iv_shoa);

        setUpListeners();
        setUpMargins();

        spinner_audioformat.setOnItemSelectedListener(this);
        spinner_bitrate.setOnItemSelectedListener(this);


        if (savb == 1) {

            et_audioname.setTextColor(getResources().getColor(R.color.thm_1));
            mTextSize.setTextColor(getResources().getColor(R.color.thm_1));
            mTextTime.setTextColor(getResources().getColor(R.color.thm_1));
            iv_totaltime.setTextColor(getResources().getColor(R.color.thm_1));

            et_audioname.setHintTextColor(getResources().getColor(R.color.thm_1));


            constraintLayout.setBackgroundColor(getResources().getColor(R.color.home_top1));

            constraintLayout2.setBackgroundColor(getResources().getColor(R.color.cl_1t));
            view3423.setBackgroundColor(getResources().getColor(R.color.thm_1));
            textView12.setTextColor(getResources().getColor(R.color.thm_1));
            audioSetting.setVisibility(View.VISIBLE);
            changeColor(R.color.home_top1);


            constraintLayout3.setBackground(getResources().getDrawable(R.drawable.shape_thm2));
            cl_alltotal.setBackground(getResources().getDrawable(R.drawable.shape_thm2));
            constraintLayout8.setBackground(getResources().getDrawable(R.drawable.shape_thm2));


        } else {

            et_audioname.setTextColor(getResources().getColor(R.color.thm_4));
            mTextSize.setTextColor(getResources().getColor(R.color.thm_4));
            mTextTime.setTextColor(getResources().getColor(R.color.thm_4));
            iv_totaltime.setTextColor(getResources().getColor(R.color.thm_4));

            et_audioname.setHintTextColor(getResources().getColor(R.color.thm_4));
            view3423.setBackgroundColor(getResources().getColor(R.color.thm_4));

            constraintLayout.setBackgroundColor(getResources().getColor(R.color.home_top4));
            constraintLayout2.setBackgroundColor(getResources().getColor(R.color.cl_4t));
            textView12.setTextColor(getResources().getColor(R.color.thm_4));

            changeColor(R.color.home_top4);
            audioSetting.setVisibility(View.GONE);


            constraintLayout3.setBackground(getResources().getDrawable(R.drawable.shape_thm4));
            cl_alltotal.setBackground(getResources().getDrawable(R.drawable.shape_thm4));
            constraintLayout8.setBackground(getResources().getDrawable(R.drawable.shape_thm4));


            imageView4.setImageResource(R.drawable.minus_vcu);
            imageView5.setImageResource(R.drawable.plus_vcut);

            imageView42.setImageResource(R.drawable.minus_vcu);
            imageView52.setImageResource(R.drawable.plus_vcut);
            btSave2.setVisibility(View.VISIBLE);
            btSave.setVisibility(View.GONE);


        }


        this.spinner_audioformat.setSelection(0);
        ArrayList arrayList = new ArrayList();
        arrayList.add("mp3");
        arrayList.add("aac");

        arrayList.add("wav");

        ArrayAdapter arrayAdapter = new ArrayAdapter(CutterActivity.this, R.layout.vector_layput2, arrayList);
        arrayAdapter.setDropDownViewResource(R.layout.vector_layput3);

        spinner_audioformat.setAdapter((SpinnerAdapter) arrayAdapter);
        spinner_bitrate.setSelection(0);
        ArrayList arrayList2 = new ArrayList();

        arrayList2.add("default");
        arrayList2.add("128k");
        arrayList2.add("160k");
        arrayList2.add("192k");
        arrayList2.add("220k");
        arrayList2.add("280k");
        arrayList2.add("320k");


        @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(CutterActivity.this,
                R.layout.vector_layput2, arrayList2);
        arrayAdapter2.setDropDownViewResource(R.layout.vector_layput3);
        this.spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);


        cl_coversong.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 102);


            }
        });


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void getResult(Uri uri) {

        runOnUiThread(new Runnable() {

            public void run() {
                avint = 2;


                /* SI_TrimmerActivity.this.startActivity(new Intent(SI_TrimmerActivity.this.getApplicationContext(), SI_AudioListActivity.class));*/
            }
        });
    }

    public static Bitmap uriToBitmap(Uri selectedFileUri, Context context) {
        Bitmap image = null;

        try {
            ParcelFileDescriptor parcelFileDescriptor = context.getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);


        if (i == 102) {


            try {

                final Uri imageUri = intent.getData();
                coverimage = imageUri.toString();



            } catch (Exception e) {

            }


        }


    }

    @Override
    public void cancelAction() {


        finish();
    }

    @Override
    public void onError(String str) {
        runOnUiThread(new Runnable() {

            public void run() {
            }
        });
    }

    @Override
    public void onVideoPrepared() {
        runOnUiThread(new Runnable() {
            public void run() {
            }
        });
    }


    @SuppressLint({"ClickableViewAccessibility"})
    private void setUpListeners() {
        this.mListeners = new ArrayList();
        this.mListeners.add(new OnDataProVideoListner() {

            @Override
            public void updateProgress(int i, int i2, float f) {
                updateVideoProgress(i);
            }
        });

        this.mListeners.add(this.mVideoProgressIndicator);

        findViewById(R.id.imageView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });


        btSave.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {



                if (et_audioname.getText().toString().startsWith(" ") && et_audioname.getText().toString().endsWith(" ")) {


                    Toast.makeText(CutterActivity.this, "Please Enter name...", Toast.LENGTH_SHORT).show();



                } else {


                    String specialCharactersString = "!@#$%&*()'+,-./:;<=>?[]^`{|}";
                    for (int i=0; i < et_audioname.getText().toString().length() ; i++)
                    {
                        char ch = et_audioname.getText().toString().charAt(i);
                        if(specialCharactersString.contains(Character.toString(ch))) {

                            Toast.makeText(CutterActivity.this,  "Please Enter Valid File Name.", Toast.LENGTH_SHORT).show();
                            return;


                        }

                    }




                    if (et_audioname.getText().toString().length() > 0) {
                        if (savb == 0) {
                            onSaveClicked();
                            return;
                        }
                        mVideoView.stopPlayback();



                        if (new File(getExternalFilesDir("").getAbsolutePath()


                                + "/" + getString(R.string.app_name)


                                + "/VideoToMp3/" + et_audioname.getText().
                                toString() + "." + audioFormat).exists()) {
                            Toast.makeText(CutterActivity.this, getResources().getString(R.string.error_file_exist), Toast.LENGTH_SHORT).show();
                            return;
                        }


                        if(iv_totaltime.getText().toString().equals("00:00"))
                        {
                            return;
                        }


                        VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(CutterActivity.this, msg -> {
                            Intent intent = new Intent(CutterActivity.this, OutputTrimimgActivity.class);


                            String path = new File(getExternalFilesDir("").getAbsolutePath()


                                    + "/" + getString(R.string.app_name)
                                    + "/VideoToMp3/" + et_audioname.getText().
                                    toString() + "." + audioFormat).getAbsolutePath();


                            intent.putExtra("genre", genre);
                            intent.putExtra("genre", genre);
                            intent.putExtra("artist", artist);
                            intent.putExtra("album", album);
                            intent.putExtra("title", title);
                            intent.putExtra("audioFormat", audioFormat);
                            intent.putExtra("bitrate", bitrate);
                            intent.putExtra("srcimg", mSrc.toString());
                            intent.putExtra("name", et_audioname.getText().toString());
                            intent.putExtra("duration", duration);
                            intent.putExtra("pd", pd);
                            intent.putExtra("startTime", startTime);
                            intent.putExtra("endTime", endTime);
                            intent.putExtra("channel", channel);
                            intent.putExtra("coverimage", coverimage);
                            intent.putExtra("path", path);
                            startActivity(intent);
                        });






                    } else {


                        Toast.makeText(CutterActivity.this, "Please Enter Valid File Name.", Toast.LENGTH_SHORT).show();


                    }

                }







            }
        });


        btSave2.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {

                if (et_audioname.getText().toString().startsWith(" ") && et_audioname.getText().toString().endsWith(" ")) {
                    Toast.makeText(CutterActivity.this, "Please Enter name...", Toast.LENGTH_SHORT).show();
                } else {
                    if (et_audioname.getText().toString().length() > 0) {
                        if (savb == 0) {
                            onSaveClicked();
                            return;
                        }
                        mVideoView.stopPlayback();
                        if (new File(getExternalFilesDir("").getAbsolutePath()


                                + "/" + getString(R.string.app_name)


                                + "/VideoToMp3/" + et_audioname.getText().
                                toString() + "." + audioFormat).exists()) {
                            Toast.makeText(CutterActivity.this, getResources().getString(R.string.error_file_exist), Toast.LENGTH_SHORT).show();
                            return;
                        }


                        VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(CutterActivity.this, msg -> {
                            Intent intent = new Intent(CutterActivity.this, OutputTrimimgActivity.class);


                            String path = new File(getExternalFilesDir("").getAbsolutePath()


                                    + "/" + getString(R.string.app_name)
                                    + "/VideoToMp3/" + et_audioname.getText().
                                    toString() + "." + audioFormat).getAbsolutePath();


                            intent.putExtra("genre", genre);
                            intent.putExtra("genre", genre);
                            intent.putExtra("artist", artist);
                            intent.putExtra("album", album);
                            intent.putExtra("title", title);
                            intent.putExtra("audioFormat", audioFormat);
                            intent.putExtra("bitrate", bitrate);
                            intent.putExtra("srcimg", mSrc.toString());
                            intent.putExtra("name", et_audioname.getText().toString());
                            intent.putExtra("duration", duration);
                            intent.putExtra("pd", pd);
                            intent.putExtra("startTime", startTime);
                            intent.putExtra("endTime", endTime);
                            intent.putExtra("channel", channel);
                            intent.putExtra("coverimage", coverimage);
                            intent.putExtra("path", path);


                            startActivity(intent);
                        });




                    } else {


                        Toast.makeText(CutterActivity.this, "Please Enter Valid File Name.", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });


        constraintLayout6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final Dialog dialog = new Dialog(CutterActivity.this);

                dialog.setContentView(R.layout.quility_dialog);
                Window window2 = dialog.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog.setCancelable(false);
                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


                ImageView button = (ImageView) dialog.findViewById(R.id.ok);
                ImageView button2 = (ImageView) dialog.findViewById(R.id.cancel);


                Spinner spinner = (Spinner) dialog.findViewById(R.id.spinner_genre);
                spinner.setSelection(0);
                ArrayList arrayList = new ArrayList();


                arrayList.add("Stereo");
                arrayList.add("Mono");


                ArrayAdapter arrayAdapter = new ArrayAdapter(CutterActivity.this, R.layout.vector_layput2, arrayList);
                arrayAdapter.setDropDownViewResource(R.layout.vector_layput3);
                spinner.setAdapter((SpinnerAdapter) arrayAdapter);


                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });


                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });


                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                        channel = adapterView.getItemAtPosition(i).toString();

                    }
                });


            }
        });


        btn_edit_tag.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("ResourceType")
            public void onClick(View view) {
                final Dialog dialog = new Dialog(CutterActivity.this);

                dialog.setContentView(R.layout.si_tag_layout);
                Window window2 = dialog.getWindow();
                WindowManager.LayoutParams wlp1 = window2.getAttributes();
                window2.setAttributes(wlp1);
                dialog.setCancelable(false);
                window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


                final EditText editText = (EditText) dialog.findViewById(R.id.et_title);
                final EditText editText2 = (EditText) dialog.findViewById(R.id.et_album);
                final EditText editText3 = (EditText) dialog.findViewById(R.id.et_artist);


                ImageView button = (ImageView) dialog.findViewById(R.id.ok);
                ImageView button2 = (ImageView) dialog.findViewById(R.id.cancel);


                Spinner spinner = (Spinner) dialog.findViewById(R.id.spinner_genre);
                spinner.setSelection(0);
                ArrayList arrayList = new ArrayList();
                arrayList.add("Unknown");
                arrayList.add("Classical");
                arrayList.add("Country");
                arrayList.add("Disco");
                arrayList.add("Rock");
                arrayList.add("Jazz");
                arrayList.add("Pop");
                arrayList.add("Metal");
                arrayList.add("Hip-Hop");
                arrayList.add("Blues");
                arrayList.add("Reggae");
                ArrayAdapter arrayAdapter = new ArrayAdapter(CutterActivity.this, R.layout.vector_layput2, arrayList);
                arrayAdapter.setDropDownViewResource(R.layout.vector_layput3);


                spinner.setAdapter((SpinnerAdapter) arrayAdapter);
                button.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View view) {

                        if(editText.getText().toString().trim().length()>0) {
                            if(editText3.getText().toString().trim().length()>0) {
                                if(editText2.getText().toString().trim().length()>0) {

                                    dialog.dismiss();
                                    album = editText2.getText().toString();
                                    artist = editText3.getText().toString();
                                    title = editText.getText().toString();
                                }
                                else
                                {
                                    Toast.makeText(CutterActivity.this, "Enter album", Toast.LENGTH_SHORT).show();
                                }



                            }

                            else
                            {
                                Toast.makeText(CutterActivity.this, "Enter artist", Toast.LENGTH_SHORT).show();
                            }


                        }
                        else
                        {
                            Toast.makeText(CutterActivity.this, "Enter title", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });


                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                    }

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                        genre = adapterView.getItemAtPosition(i).toString();

                    }
                });


                dialog.show();
            }
        });



        mPlayView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickVideoPlayPause();
            }
        });




        this.mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {

            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                if (mOnTrimVideoListener == null) {
                    return false;
                }
                onTrimDataLisner onTrimVideoListener = mOnTrimVideoListener;
                onTrimVideoListener.onError("Something went wrong reason : " + i);
                return false;
            }
        });

        this.mVideoView.setOnTouchListener(new View.OnTouchListener() {

            public boolean onTouch(View view, @NonNull MotionEvent motionEvent) {

                return true;
            }
        });


        this.mRangeSeekBarView.addOnRangeSeekBarListener(this.mVideoProgressIndicator);
        this.mRangeSeekBarView.addOnRangeSeekBarListener(new VTOOnRangeSeekBarListener() {

            @Override
            public void onCreate(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
            }

            @Override
            public void onSeekStart(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
            }

            @Override
            public void onSeek(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
                onSeekThumbs(i, f);
            }

            @Override
            public void onSeekStop(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
                onStopSeekThumbs();
            }
        });
        this.mHolderTopView.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                onPlayerIndicatorSeekChanged(i, z);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                onPlayerIndicatorSeekStart();
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                onPlayerIndicatorSeekStop(seekBar);
            }
        });


        this.mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

            public void onPrepared(MediaPlayer mediaPlayer) {

                onVideoPrepared(mediaPlayer);



            }
        });

        mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
                finish();
                return false;



            }
        });
        this.mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

            public void onCompletion(MediaPlayer mediaPlayer) {
                onVideoCompleted();
            }
        });
    }

    @RequiresApi(api = 16)
    private void setUpMargins() {
        int widthBitmap = this.mRangeSeekBarView.getThumbs().get(0).getWidthBitmap();
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.mHolderTopView.getLayoutParams();
        int minimumWidth = widthBitmap - (this.mHolderTopView.getThumb().getMinimumWidth() / 2);
        layoutParams.setMargins(minimumWidth, 0, minimumWidth, 0);
        this.mHolderTopView.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.mTimeLineView.getLayoutParams();
        layoutParams2.setMargins(widthBitmap, 0, widthBitmap, 0);
        this.mTimeLineView.setLayoutParams(layoutParams2);
        RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) this.mVideoProgressIndicator.getLayoutParams();
        layoutParams3.setMargins(widthBitmap, 0, widthBitmap, 0);
        this.mVideoProgressIndicator.setLayoutParams(layoutParams3);
    }


    private void onSaveClicked() {
        if (mStartPosition > 0 || this.mEndPosition < this.mDuration) {
            mPlayView.setVisibility(View.VISIBLE);
            mVideoView.pause();
            mPlayView.setImageResource(R.drawable.ic_playvi);
            MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
            mediaMetadataRetriever.setDataSource(CutterActivity.this, this.mSrc);
            long parseLong = Long.parseLong(mediaMetadataRetriever.extractMetadata(9));


            final File file = new File(this.mSrc.getPath());


            if (this.mTimeVideo < 1000) {
                if (parseLong - ((long) this.mEndPosition) > ((long) (1000 - this.mTimeVideo))) {
                    this.mEndPosition += 1000 - this.mTimeVideo;
                } else if (this.mStartPosition > 1000 - this.mTimeVideo) {
                    this.mStartPosition -= 1000 - this.mTimeVideo;
                }
            }

            if (this.mOnTrimVideoListener != null) {
                this.mOnTrimVideoListener.onTrimStarted();
            }


            VTOBackgroundExecutor.execute(new VTOBackgroundExecutor.Task("", 0, "") {

                @Override
                public void execute() {
                    try {
                        VTOTrimVideoUtils.startTrim(CutterActivity.this,file, getDestinationPath(), (long) mStartPosition,
                                mEndPosition, mOnTrimVideoListener);
                    } catch (Throwable th) {
                        Thread.getDefaultUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), th);
                    }
                }
            });
        } else if (this.mOnTrimVideoListener != null) {
            Toast.makeText(CutterActivity.this, getResources().getString(R.string.error_no_selection), Toast.LENGTH_SHORT).show();
        }
    }

    private void onClickVideoPlayPause() {
        if (mVideoView.isPlaying()) {
            mPlayView.setVisibility(View.VISIBLE);


            this.mVideoView.pause();
            mPlayView.setImageResource(R.drawable.ic_playvi);

            return;
        }

        mPlayView.setImageResource(R.drawable.pause_2_oop);

        this.mPlayView.setVisibility(View.VISIBLE);
        if (mResetSeekBar) {
            mResetSeekBar = false;
            mVideoView.seekTo(this.mStartPosition);
        }

        this.mVideoView.start();
    }

    private void onCancelClicked() {
        this.mVideoView.stopPlayback();
        if (mOnTrimVideoListener != null) {
            mOnTrimVideoListener.cancelAction();
        }
    }

    private String getDestinationPath() {

        if (this.mFinalPath == null) {
            File externalStorageDirectory =getExternalFilesDir("");
            File file = new File(externalStorageDirectory.getAbsolutePath()
                    + "/" + getString(R.string.app_name) + "/VideoCutter");
            if (!file.exists()) {
                file.mkdirs();
            }


            this.mFinalPath = externalStorageDirectory.getAbsolutePath()
                    + "/" + getString(R.string.app_name) + "/VideoCutter/"
                    + this.et_audioname.getText().toString();


            String str = TAG;
            StringBuilder sb = new StringBuilder();
            sb.append("Using default path ");
            sb.append(this.mFinalPath);
            Log.d(str, sb.toString());
        }
        return this.mFinalPath;
    }

    private void onPlayerIndicatorSeekChanged(int i, boolean z) {
        int i2 = (int) ((((long) this.mDuration) * ((long) i)) / 1000);

        if (z) {
            if (i2 < mStartPosition) {
                setProgressBarPosition(mStartPosition);
                i2 = mStartPosition;

            } else if (i2 > mEndPosition) {
                setProgressBarPosition(mEndPosition);
                i2 = mEndPosition;
            }
            setTimeVideo(i2);
        }
    }

    private void onPlayerIndicatorSeekStart() {

        mVideoView.pause();
        mPlayView.setImageResource(R.drawable.ic_playvi);
        mPlayView.setVisibility(View.VISIBLE);
        notifyProgressUpdate(false);
    }

    private void onPlayerIndicatorSeekStop(@NonNull SeekBar seekBar) {

        mVideoView.pause();
        mPlayView.setImageResource(R.drawable.ic_playvi);
        mPlayView.setVisibility(View.VISIBLE);
        int progress = (int) ((((long) this.mDuration) * ((long) seekBar.getProgress())) / 1000);
        mVideoView.seekTo(progress);
        setTimeVideo(progress);
        notifyProgressUpdate(false);
    }

    private void onVideoPrepared(@NonNull MediaPlayer mediaPlayer) {




        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        android.widget.LinearLayout.LayoutParams params = (android.widget.LinearLayout.LayoutParams) mVideoView.getLayoutParams();
        params.width = (int)(300*metrics.density);
        params.height = (int)(250*metrics.density);
        params.leftMargin = 30;
        mVideoView.setLayoutParams(params);

        mPlayView.setVisibility(View.VISIBLE);
        mDuration = mVideoView.getDuration();
        setSeekBarPosition();
        setTimeFrames();
        setTimeVideo(0);
        if (mOnHgLVideoListener != null) {
            mOnHgLVideoListener.onVideoPrepared();
        }
    }

    private void setSeekBarPosition() {

        if (mDuration >= this.mMaxDuration) {
            mStartPosition = (this.mDuration / 2) - (this.mMaxDuration / 2);
            mEndPosition = (this.mDuration / 2) + (this.mMaxDuration / 2);
            mRangeSeekBarView.setThumbValue(0, (float) ((this.mStartPosition * 100) / this.mDuration));
            mRangeSeekBarView.setThumbValue(1, (float) ((this.mEndPosition * 100) / this.mDuration));
        } else {
            mStartPosition = 0;
            mEndPosition = this.mDuration;
        }
        setProgressBarPosition(this.mStartPosition);
        mVideoView.seekTo(this.mStartPosition);
        mTimeVideo = this.mDuration;
        mRangeSeekBarView.initMaxWidth();
    }

    private void setTimeFrames() {
        String string = getString(R.string.short_seconds);
        mTextSize.setText(String.format("%s", VTOTrimVideoUtils.stringForTime(this.mStartPosition)));
        mTextTime.setText(String.format("%s", VTOTrimVideoUtils.stringForTime(this.mEndPosition)));
        int duratopnn= mEndPosition-mStartPosition;
        iv_totaltime.setText(String.format("%s", VTOTrimVideoUtils.stringForTime(duratopnn)));



        startTime = this.mTextSize.getText().toString();
        endTime =  mTextTime.getText().toString();







        duration = String.format("%s", VTOTrimVideoUtils.stringForTime(this.mEndPosition - this.mStartPosition));


        pd = this.mEndPosition - this.mStartPosition;



    }

    private void setTimeVideo(int i) {
        this.mTextSize.setText(String.format("%s", VTOTrimVideoUtils.stringForTime(i)));
    }

    private void onSeekThumbs(int i, float f) {
        switch (i) {
            case 0:
                mStartPosition = (int) ((((float) this.mDuration) * f) / 100.0f);
                mVideoView.seekTo(this.mStartPosition);
                break;
            case 1:
                this.mEndPosition = (int) ((((float) this.mDuration) * f) / 100.0f);
                break;
        }
        setProgressBarPosition(this.mStartPosition);
        setTimeFrames();
        this.mTimeVideo = this.mEndPosition - this.mStartPosition;
    }

    private void onStopSeekThumbs() {
        mVideoView.pause();
        mPlayView.setImageResource(R.drawable.ic_playvi);
        mPlayView.setVisibility(View.VISIBLE);
    }

    private void onVideoCompleted() {
        this.mVideoView.seekTo(this.mStartPosition);
    }

    private void notifyProgressUpdate(boolean z) {
        if (this.mDuration != 0) {
            int currentPosition = this.mVideoView.getCurrentPosition();
            if (z) {
                for (OnDataProVideoListner onProgressVideoListener : this.mListeners) {
                    onProgressVideoListener.updateProgress(currentPosition, this.mDuration, (float) ((currentPosition * 100) / this.mDuration));
                }
                return;
            }
            this.mListeners.get(1).updateProgress(currentPosition, this.mDuration, (float) ((currentPosition * 100) / this.mDuration));
        }
    }

    private void updateVideoProgress(int i) {
        if (this.mVideoView != null) {
            if (i >= this.mEndPosition) {

                mVideoView.pause();
                mPlayView.setImageResource(R.drawable.ic_playvi);
                mPlayView.setVisibility(View.VISIBLE);
                mResetSeekBar = true;
                return;
            }
            if (this.mHolderTopView != null) {
                setProgressBarPosition(i);
            }
            setTimeVideo(i);
        }
    }

    private void setProgressBarPosition(int i) {
        if (mDuration > 0) {
            mHolderTopView.setProgress((int) ((((long) i) * 1000) / ((long) this.mDuration)));
        }
    }

    public void setVideoInformationVisibility(boolean z) {
        this.mTimeInfoContainer.setVisibility(z ? View.VISIBLE : View.GONE);
    }

    public void setOnTrimVideoListener(onTrimDataLisner onTrimVideoListener) {
        this.mOnTrimVideoListener = onTrimVideoListener;
    }

    public void setOnHgLVideoListener(OnDataVideoLisner onHgLVideoListener) {
        this.mOnHgLVideoListener = onHgLVideoListener;
    }

    public void setDestinationPath(String str) {
        this.mFinalPath = str;
        String str2 = TAG;

    }

    public void destroy() {
        VTOBackgroundExecutor.cancelAll("", true);
        RunThredEx.cancelAll("");
    }

    public void setMaxDuration(int i) {
        this.mMaxDuration = i;
    }

    public void setVideoURI(Uri uri, Uri uri2) {


        this.mSrc = uri;
        this.et_audioname.setText(this.mSrc.toString().substring(this.mSrc.toString().lastIndexOf("/") + 1)
                .replace(".mp4", ""));
        if (mOriginSizeFile == 0) {
            try {
                mOriginSizeFile = new File(this.mSrc.getPath()).length();
                long j = this.mOriginSizeFile / 1024;
            }
            catch (Exception e)
            {
                if(dialog2!=null) {
                    dialog2.dismiss();
                }
                dialog2= null;
                Toast.makeText(CutterActivity.this, "Can't play this video", Toast.LENGTH_SHORT).show();
                finish();
            }

        }
        mVideoView.setVideoURI(this.mSrc);
        mVideoView.requestFocus();
        mTimeLineView.setVideo(uri2);


    }

    @SuppressLint("ResourceType")
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {

        switch (adapterView.getId()) {


            case R.id.spinner_audioformat:
                this.audioFormat = adapterView.getItemAtPosition(i).toString();





                ArrayList arrayList2 = new ArrayList();

                if (audioFormat.equals("mp3")) {

                    cl_coversong.setVisibility(View.VISIBLE);
                } else {

                    cl_coversong.setVisibility(View.GONE);

                }


                if (audioFormat.equals("aac")) {
                    arrayList2.add("default");
                    @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(CutterActivity.this,
                            R.layout.vector_layput2, arrayList2);
                    arrayAdapter2.setDropDownViewResource(R.layout.vector_layput3);
                    this.spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);
                } else {
                    arrayList2.add("default");
                    arrayList2.add("128k");
                    arrayList2.add("160k");
                    arrayList2.add("192k");
                    arrayList2.add("220k");
                    arrayList2.add("280k");
                    arrayList2.add("320k");

                    @SuppressLint("ResourceType") ArrayAdapter arrayAdapter2 = new ArrayAdapter(CutterActivity.this,
                            R.layout.vector_layput2, arrayList2);
                    arrayAdapter2.setDropDownViewResource(R.layout.vector_layput3);
                    this.spinner_bitrate.setAdapter((SpinnerAdapter) arrayAdapter2);
                }

                return;
            case R.id.spinner_bitrate:

                this.bitrate = adapterView.getItemAtPosition(i).toString();

                return;
            default:
                return;
        }
    }


}
