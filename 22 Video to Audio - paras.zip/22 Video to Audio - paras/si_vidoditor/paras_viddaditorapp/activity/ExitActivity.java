package com.si_vidoditor.paras_viddaditorapp.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;

import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;


public class ExitActivity extends AppCompatActivity {

    public void changeColor(int resourseColor) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit);


        TextView no = (TextView) findViewById(R.id.no);
        TextView yes = (TextView) findViewById(R.id.yes);
        TextView app_name = (TextView) findViewById(R.id.app_name);


        changeColor(R.color.black);

        BaseLayoutVidoEditor.showNativeOnce(this, findViewById(R.id.framLarge), findViewById(R.id.rlNative) );

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();


            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        finish();
    }
}