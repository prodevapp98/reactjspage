package com.si_vidoditor.paras_viddaditorapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.marge.ApiEditorApiClient;
import com.si_vidoditor.paras_viddaditorapp.appclass.InterfaceEditorsApi;
import com.si_vidoditor.paras_viddaditorapp.appclass.AppopnEditManager;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;
import com.si_vidoditor.paras_viddaditorapp.Models.ResponseEditorModel;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;

import retrofit2.Call;
import retrofit2.Callback;

public class SplashActivty extends AppCompatActivity {
    public void changeColor(int resourseColor) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    public static SplashActivty splashActivty;
    Dialog popupConnectivity;

    public static SplashActivty getSplashActivty() {
        return splashActivty;
    }

    Handler runHandler;
    Runnable runRunnable;

    int counterSecond = 13000;
    private long mLastClickTime = System.currentTimeMillis();

    VideotoaudoApplication videotoaudoApplication = VideotoaudoApplication.getVideotoaudoApplication();

    void hideDismissDialog() {
        try {
            if (popupConnectivity != null && popupConnectivity.isShowing()) {
                popupConnectivity.dismiss();
            }
        } catch (Exception e) {
        }
    }


    private static final long CLICK_TIME_INTERVAL = 1200;

    public void openInternetDialog() {
        popupConnectivity = new Dialog(SplashActivty.this);
        popupConnectivity.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        popupConnectivity.requestWindowFeature(1);
        popupConnectivity.setContentView(R.layout.dialog_connection);
        popupConnectivity.setCancelable(false);


        Window window = popupConnectivity.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        popupConnectivity.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        TextView clickToQuit = (TextView) popupConnectivity.findViewById(R.id.clickQuit);
        TextView clickToRetry = (TextView) popupConnectivity.findViewById(R.id.clickRetry);

        try {
            runHandler.removeCallbacks(runRunnable);
        } catch (Exception e) {
        }

        clickToQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupConnectivity.dismiss();
                finishAffinity();

            }
        });

        clickToRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;

                try {
                    runHandler.removeCallbacks(runRunnable);
                } catch (Exception e) {
                }


                if (networkConnAvailable()) {
                    VideotoaudoApplication.isVidoSplashNot = false;
                    hideDismissDialog();

                    listOfApiData();
                    handlerFromStaring();

                } else {
                    Toast.makeText(SplashActivty.this, "Check your internet connection!", Toast.LENGTH_SHORT).show();
                }

            }
        });
        try {
            if (!isFinishing()) {
                popupConnectivity.show();
            }

        } catch (Exception e) {

        }


    }

    public void showActivityGo() {
        VideotoaudoApplication.isVidoSplashNot = true;
        hideDismissDialog();

        try {
            if (runHandler != null) {
                runHandler.removeCallbacks(runRunnable);
            }
        } catch (Exception e) {
        }


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                VideotoaudoApplication videotoaudoApplication = VideotoaudoApplication.getVideotoaudoApplication();
                if (videotoaudoApplication != null && videotoaudoApplication.getEditorAppDetailModel() != null && videotoaudoApplication.getEditorAppDetailModel().getAppscreennumber() != null && !TextUtils.isEmpty(videotoaudoApplication.getEditorAppDetailModel().getAppscreennumber())) {
                    int counterName = 0;
                    try {
                        counterName = Integer.valueOf(videotoaudoApplication.getEditorAppDetailModel().getAppscreennumber());
                    } catch (Exception e) {

                    }

                    if (counterName >= 1) {
                        Intent goIntent = new Intent(SplashActivty.this, StartActivity.class);
                        startActivity(goIntent);
                        finish();
                    } else {
                        Intent goIntent = new Intent(SplashActivty.this, MainActivity.class);
                        startActivity(goIntent);
                        finish();
                    }
                } else {
                    Intent goIntent = new Intent(SplashActivty.this, MainActivity.class);
                    startActivity(goIntent);
                    finish();
                }


            }
        }, 250);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        VideotoaudoApplication.isVidoSplashNot = false;
        AppopnEditManager.editorOpenFlag = false;
        VideoCallbackNextManager.flagFromWithoutSplashBig = false;
        BaseLayoutVidoEditor.flagFromWithoutSplashNative = false;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_activty);
        changeColor(R.color.black);

        splashActivty = this;

        if (networkConnAvailable()) {

            listOfApiData();
            handlerFromStaring();
        } else {
            openInternetDialog();
        }
    }

    private boolean networkConnAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }

    }

    public void pauseRunRunnable() {
        VideotoaudoApplication.isVidoSplashNot = true;
        try {
            if (runHandler != null) {
                runHandler.removeCallbacks(runRunnable);
            }
        } catch (Exception e) {
        }


        hideDismissDialog();
    }


    public void listOfApiData() {
        try {
            VideoCallbackNextManager.getVideoCallbackNext();
            Call<ResponseEditorModel> call = ApiEditorApiClient.getClient().create(InterfaceEditorsApi.class).getAll("com.jayandroid.androidapp");

            call.enqueue(new Callback<ResponseEditorModel>() {
                @Override
                public void onResponse(Call<ResponseEditorModel> call, retrofit2.Response<ResponseEditorModel> response) {
                    if (response.isSuccessful()) {



                        VideotoaudoApplication.getVideotoaudoApplication().setEditorAppDetailModel(response.body().getAppdetail());
                        linkInterCounter();

                        VideotoaudoApplication.getVideotoaudoApplication().setEditorAdsDetail(response.body().getAdsdetail());


                    } else {

                        linkInterCounter();
                    }
                }

                @Override
                public void onFailure(Call<ResponseEditorModel> call, Throwable t) {

                    linkInterCounter();
                }
            });
        } catch (Exception e) {

        }

    }

    public static boolean loadOnceCheck = false;

    private void linkInterCounter() {
        videotoaudoApplication.openInitApp();

        try {
            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();

            if (editorAppDetailModel != null && editorAppDetailModel.getAdstatus() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdstatus()) && editorAppDetailModel.getAdstatus().equalsIgnoreCase("1")) {

                if (editorAppDetailModel.getAdmobnew() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmobnew())) {
                    if (VideotoaudoApplication.appopnEditManager != null) {
                        AppopnEditManager.appopenRefetch();
                    }
                } else if (editorAppDetailModel.getAdmob2appopen() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmob2appopen()) && VideotoaudoApplication.appopnEditManager != null) {
                    AppopnEditManager.fetchOptionAppopen();
                }

                try {
                    if (editorAppDetailModel.getCounter() != null && !TextUtils.isEmpty(editorAppDetailModel.getCounter())) {
                        VideoCallbackNextManager.clickToOpenNumbers = Integer.valueOf(editorAppDetailModel.getCounter());
                    }
                } catch (Exception e) {
                    VideoCallbackNextManager.clickToOpenNumbers = 3;
                }


            } else {
                showActivityGo();
            }

        } catch (Exception e) {

        }

    }


    public void apiDemResponse() {
        if (!loadOnceCheck) {

            loadOnceCheck = true;
            VideoCallbackNextManager.flagFromWithoutSplashBig = false;
            BaseLayoutVidoEditor.flagFromWithoutSplashNative = false;

            BaseLayoutVidoEditor.loadN1(this);
            VideoCallbackNextManager.getVideoCallbackNext().findintercallback(SplashActivty.this);

            BaseLayoutVidoEditor.loadN2(this);

            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();

            if (editorAppDetailModel != null && editorAppDetailModel.getAdmobinter() != null && TextUtils.isEmpty(editorAppDetailModel.getAdmobinter())) {
                VideoCallbackNextManager.getVideoCallbackNext().loadReturn(SplashActivty.this);
            } else if (editorAppDetailModel != null && editorAppDetailModel.getCounter() != null && !TextUtils.isEmpty(editorAppDetailModel.getCounter())) {

                try {
                    int counterName = Integer.valueOf(editorAppDetailModel.getCounter());
                    if (counterName <= 1) {
                        VideoCallbackNextManager.getVideoCallbackNext().loadReturn(SplashActivty.this);
                    }
                } catch (Exception e) {

                }
            }

        }

    }


    void handlerFromStaring() {
        VideotoaudoApplication.isVidoSplashNot = false;

        try {
            if (runHandler != null) {
                runHandler.removeCallbacks(runRunnable);
            }
        } catch (Exception e) {
        }

        runRunnable = new Runnable() {
            @Override
            public void run() {
                VideotoaudoApplication.isVidoSplashNot = true;

                if (networkConnAvailable()) {
                    apiDemResponse();
                    showActivityGo();

                } else {
                    try {
                        if (popupConnectivity != null && popupConnectivity.isShowing()) {
                            popupConnectivity.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    openInternetDialog();
                }

            }


        };

        runHandler = new Handler();
        runHandler.postDelayed(runRunnable, Long.valueOf(counterSecond));
    }




    @Override
    public void onBackPressed() {

    }
    @Override
    protected void onDestroy() {
        try {
            if (runHandler != null) {
                runHandler.removeCallbacks(runRunnable);
            }
        } catch (Exception e) {
        }

        VideotoaudoApplication.isVidoSplashNot = true;
        super.onDestroy();
    }
}