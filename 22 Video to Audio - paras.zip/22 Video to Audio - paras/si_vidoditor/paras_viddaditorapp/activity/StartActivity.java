package com.si_vidoditor.paras_viddaditorapp.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;

import org.jetbrains.annotations.NotNull;

public class StartActivity extends AppCompatActivity {

    private ConstraintLayout bv_start, bv_forcha;
    TextView iv_priv;

    private static final String[] LOCATION_AND_CONTACTS =
            {
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE

            };
    private static final int RC_LOCATION_CONTACTS_PERM = 124;


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(StartActivity.this, ExitActivity.class);
        startActivity(intent);

    }

    boolean checkAllPermission() {
        String[] strArr = new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE};

        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        if ((ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            return true;
        }
        ActivityCompat.requestPermissions(this, strArr, 121);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 121) {
            try {
                if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(StartActivity.this, msg -> {
                        startActivity(new Intent(StartActivity.this, MainActivity.class));
                    });


                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                        if (!ActivityCompat.shouldShowRequestPermissionRationale(StartActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) ||
                                !ActivityCompat.shouldShowRequestPermissionRationale(StartActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                            final Dialog dialogSetting = new Dialog(StartActivity.this);
                            dialogSetting.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialogSetting.setCancelable(true);
                            dialogSetting.setContentView(R.layout.dialog_setting);
                            dialogSetting.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                            Window window = dialogSetting.getWindow();
                            window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                            dialogSetting.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            WindowManager.LayoutParams attributes = window.getAttributes();
                            attributes.gravity = Gravity.CENTER;
                            window.addFlags(2);
                            window.setDimAmount(0.82f);
                            window.setAttributes(attributes);

                            TextView clickQuit = dialogSetting.findViewById(R.id.clickQuit);

                            clickQuit.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialogSetting.dismiss();
                                }
                            });

                            TextView yesSetting = dialogSetting.findViewById(R.id.yesSetting);
                            yesSetting.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                    dialogSetting.dismiss();
                                }
                            });
                            dialogSetting.show();
                        }

                    } else {

                    }
                }
            } catch (Exception e) {

            }

        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        bv_start = findViewById(R.id.bv_covert);
        bv_forcha = findViewById(R.id.bv_forcha);
        iv_priv = findViewById(R.id.textView9);
        changeColor(R.color.black);


        bv_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkAllPermission()) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(StartActivity.this, msg -> {
                        startActivity(new Intent(StartActivity.this, MainActivity.class));
                    });

                }

            }
        });

        BaseLayoutVidoEditor.showBannerOnce(this, findViewById(R.id.framSmall), findViewById(R.id.rlBanner));
        bv_forcha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(StartActivity.this, msg -> {
                    startActivity(new Intent(StartActivity.this, MoraAppsActivty.class));
                });
            }
        });


        iv_priv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel() != null) {
                        if (VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy() != null && !VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy().trim().isEmpty()) {

                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy()));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.setPackage("com.android.chrome");
                            try {
                                startActivity(i);
                            } catch (ActivityNotFoundException e) {
                                i.setPackage(null);
                                startActivity(i);
                            }
                        } else {
                            Toast.makeText(StartActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(StartActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(StartActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }


    public void changeColor(int resourseColor) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }

    }

}