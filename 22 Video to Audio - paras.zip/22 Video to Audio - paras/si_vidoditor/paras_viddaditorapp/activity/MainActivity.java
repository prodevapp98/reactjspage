package com.si_vidoditor.paras_viddaditorapp.activity;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.MusicAddCAtivity;
import com.si_vidoditor.paras_viddaditorapp.formateconverter.AudioConverter;
import com.si_vidoditor.paras_viddaditorapp.formateconverter.VideoConvertre;
import com.si_vidoditor.paras_viddaditorapp.marge.MusicMargeAudioActivity;
import com.si_vidoditor.paras_viddaditorapp.outputfolder.UotPutAllActivity;
import com.si_vidoditor.paras_viddaditorapp.ringtone.SetRingtoneActivty;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.CopressVideoListActivity;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;
import com.si_vidoditor.paras_viddaditorapp.videocutter.AllVideoListActivity;

import org.jetbrains.annotations.NotNull;


public class MainActivity extends AppCompatActivity {

    private ConstraintLayout bv_covert, bv_videcuteer,
            bv_forcha, bv_audimar, bv_audiofor, bv_setring, bv_data;
    private DataProccessor dataProccessor;
    public String duration;

    private ConstraintLayout cl_share, cl_rate, cl_privacy, cl_moraap;
    private ImageView imageView;
    private DrawerLayout drwer_lauot;

    public void changeColor(int resourseColor) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setContentView(R.layout.activity_main);
        changeColor(R.color.home_top);
        dataProccessor = new DataProccessor(MainActivity.this);


        drwer_lauot = findViewById(R.id.drwer_lauot);
        imageView = findViewById(R.id.imageView);

        cl_share = findViewById(R.id.cl_recyclebin);
        cl_rate = findViewById(R.id.cl_fav);
        cl_privacy = findViewById(R.id.cl_resetde);
        cl_moraap = findViewById(R.id.cl_moraap);

        bv_covert = findViewById(R.id.bv_covert);
        bv_videcuteer = findViewById(R.id.bv_videcuteer);
        bv_audiofor = findViewById(R.id.bv_audiofor);
        bv_forcha = findViewById(R.id.bv_forcha);
        bv_audimar = findViewById(R.id.bv_audimar);
        bv_setring = findViewById(R.id.bv_setring);
        bv_data = findViewById(R.id.bv_data);
        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(MainActivity.this, admobBanner, cardBAnner);

        if (dataProccessor.getStr("ListType") == null) {
            dataProccessor.setStr("ListType", "yes");
        }


        inivClick();


    }

    boolean checkForPermission(int codeActivity) {
        String[] strArr = new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE};

        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        if ((ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            return true;
        }
        ActivityCompat.requestPermissions(this, strArr, codeActivity);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        try {
            if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                if (requestCode == 121) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, UotPutAllActivity.class));
                    });

                } else if (requestCode == 122) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, SetRingtoneActivty.class));
                    });
                } else if (requestCode == 123) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, MusicMargeAudioActivity.class));
                    });

                } else if (requestCode == 124) {
                    final Dialog dialog = new Dialog(MainActivity.this);

                    dialog.setContentView(R.layout.select_type);
                    Window window2 = dialog.getWindow();
                    WindowManager.LayoutParams wlp1 = window2.getAttributes();
                    window2.setAttributes(wlp1);
                    dialog.setCancelable(true);
                    window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.show();


                    ConstraintLayout cl_coversong = dialog.findViewById(R.id.cl_coversong);
                    ConstraintLayout btn_edittag = dialog.findViewById(R.id.btn_edittag);


                    cl_coversong.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();


                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                                startActivity(new Intent(MainActivity.this, AudioConverter.class));
                            });


                        }
                    });


                    btn_edittag.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            dialog.dismiss();

                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                                startActivity(new Intent(MainActivity.this, VideoConvertre.class).putExtra("type", "convtref"));
                            });


                        }
                    });
                } else if (requestCode == 125) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, MusicAddCAtivity.class));
                    });
                } else if (requestCode == 126) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, CopressVideoListActivity.class)
                                .putExtra("type", "convert"));
                    });
                } else if (requestCode == 127) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, AllVideoListActivity.class)
                                .putExtra("type", "trimming"));
                    });

                }

            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    if (!ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) ||
                            !ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                        final Dialog dialogSetting = new Dialog(MainActivity.this);
                        dialogSetting.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialogSetting.setCancelable(true);
                        dialogSetting.setContentView(R.layout.dialog_setting);
                        dialogSetting.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


                        Window window = dialogSetting.getWindow();
                        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                        dialogSetting.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        WindowManager.LayoutParams attributes = window.getAttributes();
                        attributes.gravity = Gravity.CENTER;
                        window.addFlags(2);
                        window.setDimAmount(0.82f);
                        window.setAttributes(attributes);

                        TextView clickQuit = dialogSetting.findViewById(R.id.clickQuit);

                        clickQuit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialogSetting.dismiss();
                            }
                        });

                        TextView yesSetting = dialogSetting.findViewById(R.id.yesSetting);
                        yesSetting.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent();
                                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                                dialogSetting.dismiss();
                            }
                        });
                        dialogSetting.show();
                    }

                } else {

                }
            }
        } catch (Exception e) {

        }


    }

    @Override
    public void onBackPressed() {

        VideotoaudoApplication myApp = VideotoaudoApplication.getVideotoaudoApplication();
        if (myApp.getEditorAppDetailModel() != null && myApp.getEditorAppDetailModel().getAppscreennumber() != null && !TextUtils.isEmpty(myApp.getEditorAppDetailModel().getAppscreennumber())) {
            if (myApp.getEditorAppDetailModel().getAppscreennumber().equalsIgnoreCase("0")) {
                startActivity(new Intent(MainActivity.this, ExitActivity.class));
            } else {
                finish();
            }
        } else {
            startActivity(new Intent(MainActivity.this, ExitActivity.class));
        }

    }

    private void inivClick() {

        cl_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                drwer_lauot.closeDrawers();
                final String appPackageName = getPackageName();
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.putExtra(Intent.EXTRA_TEXT, "Check out the App at: https://play.google.com/store/apps/details?id="
                        + appPackageName);
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "Share App"));

            }
        });


        cl_moraap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                drwer_lauot.closeDrawers();

                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                    startActivity(new Intent(MainActivity.this, MoraAppsActivty.class));
                });


            }
        });


        cl_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drwer_lauot.closeDrawers();

                try {
                    if (VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel() != null) {
                        if (VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy() != null && !VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy().trim().isEmpty()) {

                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getPrivacy()));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.setPackage("com.android.chrome");
                            try {
                                startActivity(i);
                            } catch (ActivityNotFoundException e) {
                                i.setPackage(null);
                                startActivity(i);
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                }


            }
        });


        cl_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drwer_lauot.closeDrawers();

                try {
                    Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
                    Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);

                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, " Sorry, Not able to open!", Toast.LENGTH_SHORT).show();
                }


            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                drwer_lauot.openDrawer(Gravity.LEFT);

            }
        });


        bv_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(121)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, UotPutAllActivity.class));
                    });

                }


            }
        });


        bv_setring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(122)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, SetRingtoneActivty.class));
                    });
                }


            }
        });


        bv_audimar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(123)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, MusicMargeAudioActivity.class));
                    });

                }


            }
        });


        bv_forcha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (checkForPermission(124)) {
                    final Dialog dialog = new Dialog(MainActivity.this);

                    dialog.setContentView(R.layout.select_type);
                    Window window2 = dialog.getWindow();
                    WindowManager.LayoutParams wlp1 = window2.getAttributes();
                    window2.setAttributes(wlp1);
                    dialog.setCancelable(true);
                    window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.show();


                    ConstraintLayout cl_coversong = dialog.findViewById(R.id.cl_coversong);
                    ConstraintLayout btn_edittag = dialog.findViewById(R.id.btn_edittag);


                    cl_coversong.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();


                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                                startActivity(new Intent(MainActivity.this, AudioConverter.class));
                            });


                        }
                    });


                    btn_edittag.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            dialog.dismiss();

                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                                startActivity(new Intent(MainActivity.this, VideoConvertre.class).putExtra("type", "convtref"));
                            });


                        }
                    });
                }


            }
        });


        bv_audiofor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(125)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, MusicAddCAtivity.class));
                    });
                }


            }
        });


        bv_covert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(126)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, CopressVideoListActivity.class)
                                .putExtra("type", "convert"));
                    });
                }


            }
        });

        bv_videcuteer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkForPermission(127)) {
                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MainActivity.this, msg -> {
                        startActivity(new Intent(MainActivity.this, AllVideoListActivity.class)
                                .putExtra("type", "trimming"));
                    });

                }


            }
        });


    }


}