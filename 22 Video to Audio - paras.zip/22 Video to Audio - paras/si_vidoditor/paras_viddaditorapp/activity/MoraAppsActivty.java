package com.si_vidoditor.paras_viddaditorapp.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.material.imageview.ShapeableImageView;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAdsDetail;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import java.util.ArrayList;
import java.util.List;



public class MoraAppsActivty extends AppCompatActivity {

    ArrayList<EditorAdsDetail> adArrayList = new ArrayList<>();
    RecyclerView rvAdListView;
    MoviesAdapter mAdapter;
    TextView tv_nodata;
    private ConstraintLayout cl_all;
    private  ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mora_apps_activty);

        cl_all = findViewById(R.id.cl_all);
        tv_nodata = findViewById(R.id.tv_nodata);
        imageView = findViewById(R.id.imageView);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();

            }
        });





        adArrayList = VideotoaudoApplication.getVideotoaudoApplication().getEditorAdsDetail();
        rvAdListView = findViewById(R.id.rvAdListView);


        if (adArrayList == null || adArrayList.size() == 0) {
            rvAdListView.setVisibility(View.GONE);
            tv_nodata.setVisibility(View.VISIBLE);

        } else {

            rvAdListView.setVisibility(View.VISIBLE);
            tv_nodata.setVisibility(View.GONE);
            mAdapter = new MoviesAdapter(adArrayList);
            rvAdListView.setLayoutManager(new GridLayoutManager(MoraAppsActivty.this, 3));
            rvAdListView.setItemAnimator(new DefaultItemAnimator());
            rvAdListView.setAdapter(mAdapter);
        }



    }

    public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MyViewHolder> {

        private List<EditorAdsDetail> moviesList;

        public class MyViewHolder extends RecyclerView.ViewHolder {
            public ShapeableImageView ivAppLogo;
            private CardView cl_2;
            TextView tvAppName;


            public MyViewHolder(View view) {
                super(view);
                ivAppLogo = view.findViewById(R.id.ivAppLogo);
                cl_2 = view.findViewById(R.id.cl_all);
                tvAppName = view.findViewById(R.id.tvAppName);

            }
        }

        public MoviesAdapter(List<EditorAdsDetail> moviesList) {
            this.moviesList = moviesList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.app_list_row, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            final EditorAdsDetail movie = moviesList.get(position);
            Glide.with(MoraAppsActivty.this).load(movie.getApp_icon()).into(holder.ivAppLogo);

            try {
                holder.tvAppName.setText(movie.getApp_name());
                holder.tvAppName.setSelected(true);
            }catch (Exception e){

            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse(movie.getApp_url()));
                    try {
                        startActivity(goToMarket);
                    } catch (ActivityNotFoundException e) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(movie.getApp_url())));
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return moviesList.size();
        }
    }




}