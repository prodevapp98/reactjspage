package com.si_vidoditor.paras_viddaditorapp.marge;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.si_vidoditor.paras_viddaditorapp.Adapters.MusicMargeAdpter;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.FilePAthdata2ex;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.BlacklistStore;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.albumInfo;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class MusicMargeAudioActivity extends AppCompatActivity {


    private TinyDB tinyDB;
    private ArrayList<albumInfo> albumSongList = new ArrayList<>();
    private TextView noVideoLayout;
    private ImageView imageView;
    private RecyclerView recyclerView;
    private ArrayList<File> pathDAta2 = new ArrayList<>();
    private Dialog dialog;
    private ArrayList<File> fileData = new ArrayList<>();
    private ConstraintLayout cl_all;
    private MusicMargeAdpter adapter;
    private SearchView iv_serch;
    private ImageView iv_serach;
    private ConstraintLayout cl_all_show, rv_layoutt;
    private int sort = 0;
    private ImageView iv_sort;
    private TextView tv_tofile;
    private ConstraintLayout cl_allfile;
    private ImageView iv_start;
    private MediaPlayer player;
    private ImageView img;


    @Override
    protected void onPause() {
        super.onPause();

        if (player != null) {

            if (player.isPlaying()) {
                if (img != null) {
                    img.setImageResource(R.drawable.play_green);
                    player.pause();

                }

            }
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marge_converter);

        tinyDB = new TinyDB(MusicMargeAudioActivity.this);

        iniviews();


        changeColor(R.color.home_top3s);


        iv_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                PopupWindow pwindow = new PopupWindow(MusicMargeAudioActivity.this);
                pwindow.setBackgroundDrawable(new BitmapDrawable());
                View inflate = getLayoutInflater().inflate(R.layout.sortpopupsds3, (ViewGroup) null);


                pwindow.setContentView(inflate);
                pwindow.setFocusable(true);
                pwindow.setWindowLayoutMode(-2, -2);
                pwindow.setOutsideTouchable(true);
                pwindow.showAsDropDown(iv_sort, 0, 20);


                TextView tv_asending = inflate.findViewById(R.id.tv_list);
                TextView tv_dessendin = inflate.findViewById(R.id.tv_grid);
                TextView tv_date = inflate.findViewById(R.id.tv_date);


                TextView tv_filco = inflate.findViewById(R.id.tv_filco);


                ImageView circleImageView = inflate.findViewById(R.id.circleImageView);
                ImageView circleImageView2 = inflate.findViewById(R.id.circleImageView2);
                ImageView circleImageView3 = inflate.findViewById(R.id.circleImageView3);
                ImageView circleImageView4 = inflate.findViewById(R.id.circleImageView4);


                if (sort == 0) {
                    circleImageView.setVisibility(View.VISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 1) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.VISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 2) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.VISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 3) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.VISIBLE);

                }


                tv_asending.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        cl_allfile.setVisibility(View.GONE);


                        sort = 0;
                        pwindow.dismiss();


                        Collections.sort(albumSongList, new Comparator<albumInfo>() {
                            @Override
                            public int compare(albumInfo lhs, albumInfo rhs) {

                                File file1 = new File(lhs.getPath());
                                File file2 = new File(rhs.getPath());

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });
                        if (player != null) {
                            if (player.isPlaying()) {
                                if (img != null) {
                                    img.setImageResource(R.drawable.play_green);
                                    player.pause();

                                }

                            }
                        }

                        setdataRecy();


                    }
                });


                tv_dessendin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);
                        pwindow.dismiss();
                        sort = 1;

                        Collections.sort(albumSongList, new Comparator<albumInfo>() {
                            @Override
                            public int compare(albumInfo lhs, albumInfo rhs) {
                                File file1 = new File(lhs.getPath());
                                File file2 = new File(rhs.getPath());

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });

                        Collections.reverse(albumSongList);


                        if (player != null) {
                            if (player.isPlaying()) {
                                if (img != null) {
                                    img.setImageResource(R.drawable.play_green);
                                    player.pause();

                                }

                            }
                        }

                        setdataRecy();


                    }
                });

                tv_date.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        cl_allfile.setVisibility(View.GONE);
                        pwindow.dismiss();
                        sort = 2;


                        Collections.sort(albumSongList, new Comparator<albumInfo>() {
                            DateFormat f = new SimpleDateFormat("dd-MM-yyyy");

                            @Override
                            public int compare(albumInfo lhs, albumInfo rhs) {
                                try {

                                    SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yyyy");
                                    Date lastModDate = new Date(new File(lhs.getPath()).lastModified());
                                    String ThiedTime = currentDate.format(lastModDate);

                                    Date lastModDate2 = new Date(new File(rhs.getPath()).lastModified());

                                    String ThiedTime2 = currentDate.format(lastModDate2);

                                    return f.parse(ThiedTime).compareTo(f.parse(ThiedTime2));


                                } catch (ParseException e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });


                        if (player != null) {
                            if (player.isPlaying()) {
                                if (img != null) {
                                    img.setImageResource(R.drawable.play_green);
                                    player.pause();

                                }

                            }
                        }

                        setdataRecy();


                    }
                });

                tv_filco.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cl_allfile.setVisibility(View.GONE);


                        pwindow.dismiss();
                        sort = 3;
                        Collections.sort(albumSongList, new Comparator<albumInfo>() {


                            @Override
                            public int compare(albumInfo lhs, albumInfo rhs) {
                                try {


                                    Long duration1 = Long.valueOf(lhs.getArt());
                                    Long duration2 = Long.valueOf(rhs.getArt());


                                    if (duration1 == null) {
                                        duration1 = Long.valueOf(0);
                                    }
                                    if (duration2 == null) {
                                        duration2 = Long.valueOf(0);
                                    }


                                    return duration1.compareTo(duration2);


                                } catch (Exception e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });

                        if (player != null) {
                            if (player.isPlaying()) {
                                if (img != null) {
                                    img.setImageResource(R.drawable.play_green);
                                    player.pause();

                                }

                            }
                        }

                        setdataRecy();

                    }
                });


            }
        });

        BaseLayoutVidoEditor.showBannerOnce(this, findViewById(R.id.framSmall), findViewById(R.id.rlBanner));


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });


        inttFind();


    }

    private void iniviews() {
        imageView = findViewById(R.id.imageView);
        iv_start = findViewById(R.id.iv_start);
        tv_tofile = findViewById(R.id.tv_tofile);
        iv_sort = findViewById(R.id.iv_sort);
        recyclerView = findViewById(R.id.rec);
        cl_all = findViewById(R.id.cl_all);
        noVideoLayout = findViewById(R.id.noVideoLayout);
        cl_allfile = findViewById(R.id.cl_allfile);


        iv_start.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (pathDAta2.size() > 1) {


                            if (player != null) {
                                if (player.isPlaying()) {


                                    if (img != null) {
                                        img.setImageResource(R.drawable.play_green);
                                    }
                                    player.stop();





                                }
                            }


                            if (img != null) {
                                img.setImageResource(R.drawable.play_green);
                            }






                            tinyDB.putListObject("margealldata", pathDAta2);


                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MusicMargeAudioActivity.this, msg -> {
                                startActivity(new Intent(MusicMargeAudioActivity.this, MargeMultipleActivity.class));
                            });

                        } else {
                            Toast.makeText(MusicMargeAudioActivity.this, "Add at least two file!", Toast.LENGTH_SHORT).show();


                        }


                    }
                }
        );


    }


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }


    private void inttFind() {


        recyclerView = findViewById(R.id.rec);
        iv_serch = findViewById(R.id.searchView);
        iv_serach = findViewById(R.id.iv_serach);
        cl_all_show = findViewById(R.id.cl_all_show);
        rv_layoutt = findViewById(R.id.rv_layoutt);


        iv_serach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_serch.performClick();
            }
        });


        iv_serch.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            iv_serch.setIconified(false);

                                        }
                                    }
        );


        iv_serch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String str) {
                return false;
            }

            public boolean onQueryTextChange(String str) {


                if (player != null) {
                    if (player.isPlaying()) {
                        if (img != null) {
                            img.setImageResource(R.drawable.play_green);
                            player.pause();

                        }

                    }
                }



                if (albumSongList != null) {

                    if (adapter != null) {
                        adapter.getFilter().filter(str);
                    }


                }

                return false;
            }
        });

        iv_serch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cl_all_show.setVisibility(View.INVISIBLE);
                rv_layoutt.setVisibility(View.VISIBLE);


            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                adapter.getFilter().filter("");
                return false;

            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {

                cl_all_show.setVisibility(View.VISIBLE);
                rv_layoutt.setVisibility(View.GONE);

                return false;
            }
        });


        recyclerView.setLayoutManager(new LinearLayoutManager(MusicMargeAudioActivity.this));
        noVideoLayout = findViewById(R.id.noVideoLayout);
        songs();


    }


    @SuppressLint("Range")
    public void songs() {
        Uri uri = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
        Cursor cursor;

        String[] column = {MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.MIME_TYPE,};


        String orderBy = MediaStore.Audio.Media.TITLE;

        String selection = null;

        String[] selectionValues = null;


        final String BASE_SELECTION = MediaStore.Audio.AudioColumns.IS_MUSIC + "=1" + " AND "
                + MediaStore.Audio.AudioColumns.TITLE + " != ''";
        final String[] BASE_PROJECTION = new String[]{
                BaseColumns._ID,// 0
                MediaStore.Audio.AudioColumns.TITLE,// 1
                MediaStore.Audio.AudioColumns.TRACK,// 2
                MediaStore.Audio.AudioColumns.YEAR,// 3
                MediaStore.Audio.AudioColumns.DURATION,// 4
                MediaStore.Audio.AudioColumns.DATA,// 5
                MediaStore.Audio.AudioColumns.DATE_MODIFIED,// 6
                MediaStore.Audio.AudioColumns.ALBUM_ID,// 7
                MediaStore.Audio.AudioColumns.ALBUM,// 8
                MediaStore.Audio.AudioColumns.ARTIST_ID,// 9
                MediaStore.Audio.AudioColumns.ARTIST,// 10
        };


        if (selection != null && !selection.trim().equals("")) {
            selection = addMinDurationFilter(BASE_SELECTION) + " AND " + selection;
        } else {
            selection = addMinDurationFilter(BASE_SELECTION);
        }

        // Blacklist
        ArrayList<String> paths = BlacklistStore.getInstance(MusicMargeAudioActivity.this).getPaths();
        if (!paths.isEmpty()) {
            selection = generateBlacklistSelection(selection, paths.size());
            selectionValues = addBlacklistSelectionValues(selectionValues, paths);


            StringBuilder values = new StringBuilder();
            for (String value :
                    selectionValues) {
                values.append("[").append(value).append("], ");
            }

        }


        String sortOrder2 = MediaStore.MediaColumns.DISPLAY_NAME + "";
        cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                BASE_PROJECTION, selection, selectionValues, sortOrder2);


        if (cursor != null && cursor.moveToFirst()) {
            do {


                final int id = cursor.getInt(0);
                final String name = cursor.getString(1);
                final int trackNumber = cursor.getInt(2);
                final int year = cursor.getInt(3);
                final long duration = cursor.getLong(4);
                final String path = cursor.getString(5);
                final long dateModified = cursor.getLong(6);
                final int albumId = cursor.getInt(7);
                final String albumName = cursor.getString(8);
                final int artistId = cursor.getInt(9);
                final String art2 = cursor.getString(10);


                albumInfo s = new albumInfo(name, duration, path, id);


                albumSongList.add(s);

            } while (cursor.moveToNext());
        }

        sort = 0;
        setdataRecy();


    }

    private void setdataRecy() {
        if (albumSongList.size() > 0) {


            adapter = new MusicMargeAdpter(MusicMargeAudioActivity.this, albumSongList, new FilePAthdata2ex() {
                @Override
                public void fitdat(ArrayList<File> pathDAta, MediaPlayer player2, ImageView img2) {

                    pathDAta2 = pathDAta;

                    tv_tofile.setText("" + pathDAta2.size() + " Files");

                    if (pathDAta2.size() > 0) {
                        cl_allfile.setVisibility(View.VISIBLE);
                    } else {

                        cl_allfile.setVisibility(View.GONE);
                    }


                }

                @Override
                public void fitdat2(ArrayList<File> pathDAta, MediaPlayer player2, ImageView img2) {


                    player = player2;
                    img = img2;


                }
            }, noVideoLayout);

            recyclerView.setAdapter(adapter);


        } else {

            noVideoLayout.setVisibility(View.VISIBLE);
        }

    }


    private static String generateBlacklistSelection(String selection, int pathCount) {
        StringBuilder newSelection = new StringBuilder(selection != null && !selection.trim().equals("") ? selection + " AND " : "");
        newSelection.append(MediaStore.Audio.AudioColumns.DATA + " NOT LIKE ?");
        for (int i = 0; i < pathCount - 1; i++) {
            newSelection.append(" AND " + MediaStore.Audio.AudioColumns.DATA + " NOT LIKE ?");
        }
        return newSelection.toString();
    }


    private static String addMinDurationFilter(String selection) {
        return selection + " AND " + MediaStore.Audio.AudioColumns.DURATION + " > "
                + VideotoaudoApplication.getVideotoaudoApplication().getPreferencesUtility().getMinDuration();
    }

    private static String[] addBlacklistSelectionValues(String[] selectionValues, ArrayList<String> paths) {
        if (selectionValues == null) selectionValues = new String[0];
        String[] newSelectionValues = new String[selectionValues.length + paths.size()];
        System.arraycopy(selectionValues, 0, newSelectionValues, 0, selectionValues.length);
        for (int i = selectionValues.length; i < newSelectionValues.length; i++) {
            newSelectionValues[i] = paths.get(i - selectionValues.length) + "%";
        }
        return newSelectionValues;
    }
}