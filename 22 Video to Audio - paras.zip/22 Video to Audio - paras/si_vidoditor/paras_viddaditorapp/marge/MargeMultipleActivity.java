package com.si_vidoditor.paras_viddaditorapp.marge;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.cuttetinter;

import java.io.File;
import java.util.ArrayList;

public class MargeMultipleActivity extends AppCompatActivity {


    private TinyDB tinyDB;
    private ArrayList<File> alldat;
    private RecyclerView _rv_ciefile;
    private ImageView imageView;
    private ArrayList<File> removlist = new ArrayList<>();
    private TextView textView;
    private String videoFormat = "mp3";
    private MultMargeMulAdapter VieDataAdapter;
    private ConstraintLayout btSave;
    private TextView tv_nodatafound;
    private ArrayList<File> pathDAta = new ArrayList<>();
    private ImageView iv_gidelist;
    private TextView textView13;

    private EditText editText;




    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marge_multiple);


        iv_gidelist = findViewById(R.id.iv_gidelist);
        textView13 = findViewById(R.id.textView13);
        imageView = findViewById(R.id.imageView);
        btSave = findViewById(R.id.btSave);
        editText = findViewById(R.id.editText);
        editText.setText("FilesMerged"+System.currentTimeMillis());





        tinyDB = new TinyDB(MargeMultipleActivity.this);
        alldat = tinyDB.getListObject("margealldata", File.class);



        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(MargeMultipleActivity.this, admobBanner,cardBAnner);


        iv_gidelist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tinyDB.putListObject("margealldata", new ArrayList<>());
                finish();


            }
        });

        changeColor(R.color.home_top3s);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();


            }
        });


        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (pathDAta.size() > 1) {

                    if(editText.getText().toString().trim().length()>0) {


                        String specialCharactersString = "!@#$%&*()'+,-./:;<=>?[]^`{|}";
                        for (int i=0; i < editText.getText().toString().length() ; i++)
                        {
                            char ch = editText.getText().toString().charAt(i);
                            if(specialCharactersString.contains(Character.toString(ch))) {

                                Toast.makeText(MargeMultipleActivity.this,  "Please Enter Valid File Name.", Toast.LENGTH_SHORT).show();
                                return;

                            }

                        }







                        File externalStorageDirectory =getExternalFilesDir("");


                        File file = new File(externalStorageDirectory.getAbsolutePath()
                                + "/" + getString(R.string.app_name) + "/MargeAudio");
                        if (!file.exists()) {
                            file.mkdirs();
                        }


                        String mFinalPath = externalStorageDirectory.getAbsolutePath()
                                + "/" + getString(R.string.app_name) + "/MargeAudio/"
                                + editText.getText().toString() + ".mp3";





                        if (new File(mFinalPath).exists()) {
                            Toast.makeText(MargeMultipleActivity.this, getResources().getString(R.string.error_file_exist), Toast.LENGTH_SHORT).show();
                            return;
                        }




                        tinyDB.putListObject("outmargealldata", pathDAta);



                        VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(MargeMultipleActivity.this, msg -> {
                            Intent intent = new Intent(MargeMultipleActivity.this, MArgeOutputActivity.class)
                                    .putExtra("input",mFinalPath );
                            startActivity(intent);
                        });










                    }


                    else

                    {
                        Toast.makeText(MargeMultipleActivity.this, "Enter file name!", Toast.LENGTH_SHORT).show();
                    }




                }
                else
                {
                    Toast.makeText(MargeMultipleActivity.this, "Add at least two file!", Toast.LENGTH_SHORT).show();


                }


            }
        });


        addadprer();


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

        tinyDB.putListObject("margealldata", new ArrayList<>());


    }

    private void addadprer() {


        _rv_ciefile = findViewById(R.id._rv_ciefile);

        if (alldat.size() <= 0) {
            tv_nodatafound.setVisibility(View.VISIBLE);
        }


        VieDataAdapter = new MultMargeMulAdapter(MargeMultipleActivity.this, alldat, new cuttetinter() {
            @Override
            public void datat(ArrayList<File> pathDAta2) {

                pathDAta = pathDAta2;

                if(pathDAta.size()>=0)
                {
                    textView13.setText("" + pathDAta.size() + " files to be merged");

                }
                else
                {

                    textView13.setText("0"  + " files to be merged");
                }


            }
        }, "converter");






        _rv_ciefile.setHasFixedSize(true);
        _rv_ciefile.setLayoutManager(new LinearLayoutManager(MargeMultipleActivity.this));
        ItemTouchHelper.Callback callback =
                new ItemMoveCallback(VieDataAdapter);
        ItemTouchHelper touchHelper = new ItemTouchHelper(callback);
        touchHelper.attachToRecyclerView(_rv_ciefile);

        _rv_ciefile.setAdapter(VieDataAdapter);


    }

}

