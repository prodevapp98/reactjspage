package com.si_vidoditor.paras_viddaditorapp.marge;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.michaelrocks.paranoid.Obfuscate;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Obfuscate
public class ApiEditorApiClient {

    public static final String BASE_URL = "http://100.24.22.170/admin-app/";

    private static Retrofit retrofitApi = null;

    static Gson gson = new GsonBuilder()
            .setLenient()
            .create();

    static OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

    public static Retrofit getClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        httpClient.addInterceptor(logging);

        if (retrofitApi == null) {

            retrofitApi = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .client(httpClient.build())
                    .build();
        }
        return retrofitApi;
    }

}
