package com.si_vidoditor.paras_viddaditorapp.marge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.cuttetinter;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MultMargeMulAdapter  extends RecyclerView.Adapter<MultMargeMulAdapter.holder>
        implements ItemMoveCallback.ItemTouchHelperContract


{
    public Activity activity;
    private ArrayList<File> albu;
    private cuttetinter cuttetinter;
    String type;

    public class holder extends RecyclerView.ViewHolder {


        private ImageView i1;
        private TextView t1;
        private TextView t2;
        private TextView t3;
        private ImageView iv_delete;





        holder(View view) {
            super(view);

            i1 = view.findViewById(R.id.thumb);
            t1 = view.findViewById(R.id.name);
            t2 = view.findViewById(R.id.duration);
            t3 = view.findViewById(R.id.size);
            iv_delete = view.findViewById(R.id.iv_delete);


        }
    }


    public MultMargeMulAdapter(Activity activity, ArrayList<File> albu,cuttetinter cuttetinter, String type) {
        this.activity = activity;
        this.albu = albu;
        this.cuttetinter= cuttetinter;
        this.type= type;

    }

    @Override
    public MultMargeMulAdapter.holder onCreateViewHolder(ViewGroup viewGroup, int i) {


        return new MultMargeMulAdapter.holder(LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.tt_item_margemul_list2, viewGroup, false));


    }

    public static Long getImageContentUri(Context context, File imageFile) {
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Files.getContentUri("external");
        }


        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                collection,
                new String[]{MediaStore.Files.FileColumns.DURATION},
                MediaStore.Files.FileColumns.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") Long id = cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.DURATION));
            cursor.close();
            return id;
        } else {


            return null;

        }


    }
    @SuppressLint({"StaticFieldLeak", "ClickableViewAccessibility"})
    @Override
    public void onBindViewHolder(MultMargeMulAdapter.holder viewHolder, @SuppressLint("RecyclerView") final int i) {

        File fileinfo = albu.get(i);

        MultMargeMulAdapter.holder holder2 = (MultMargeMulAdapter.holder) viewHolder;
        holder2.t1.setText(fileinfo.getName());




        Long duration = getImageContentUri(activity, fileinfo);
        if(duration!=null) {
            String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                    new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(duration)),
                            Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1)),
                            Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1))});

            holder2.t3.setText(str);
        }




        holder2.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                albu.remove(i);
                notifyDataSetChanged();
                cuttetinter.datat(albu);

            }
        });



        cuttetinter.datat(albu);






    }

    @Override
    public int getItemCount() {
        return albu.size();
    }

    @Override
    public void onRowMoved(int fromPosition, int toPosition) {
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(albu, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(albu, i, i - 1);
            }
        }
        notifyItemMoved(fromPosition, toPosition);

        cuttetinter.datat(albu);
    }

    @Override
    public void onRowSelected(holder myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.WHITE);
    }

    @Override
    public void onRowClear(holder myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.WHITE);
    }


}
