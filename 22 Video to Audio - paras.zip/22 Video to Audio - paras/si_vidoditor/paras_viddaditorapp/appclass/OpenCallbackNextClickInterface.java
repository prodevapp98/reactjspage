package com.si_vidoditor.paras_viddaditorapp.appclass;

public interface OpenCallbackNextClickInterface {
    void stonCallDismissInterstiAd(String msg);
}