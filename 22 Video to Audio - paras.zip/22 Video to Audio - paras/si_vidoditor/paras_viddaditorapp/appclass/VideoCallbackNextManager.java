package com.si_vidoditor.paras_viddaditorapp.appclass;

import android.app.Activity;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;

public class VideoCallbackNextManager {
    public static VideoCallbackNextManager callbackNextManager;

    public InterstitialAd interstitiAdm;


    public static VideoCallbackNextManager getVideoCallbackNext() {
        if (callbackNextManager == null) {
            callbackNextManager = new VideoCallbackNextManager();
        }
        return callbackNextManager;

    }


    public static int numberSets = 0;


    public void findintercallback(Activity activity) {
        try {
            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();

            if (editorAppDetailModel != null) {

                if (interstitiAdm == null) {
                    if (editorAppDetailModel.getAdmobinter() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmobinter())
                            && editorAppDetailModel.getAdstatus() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdstatus())
                            && editorAppDetailModel.getAdstatus().equalsIgnoreCase("1")) {

                        AdRequest adRequest = new AdRequest.Builder().build();
                        InterstitialAd.load(activity, editorAppDetailModel.getAdmobinter(), adRequest, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                                VideoCallbackNextManager.this.interstitiAdm = interstitialAd;
                                errorFailedTracker = 0;
                                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {

                                        VideoCallbackNextManager.this.interstitiAdm = null;
                                        isLargeRunningNow = false;

                                        if (nextClickInterface != null) {
                                            nextClickInterface.stonCallDismissInterstiAd("");
                                            nextClickInterface = null;
                                        }

                                        findintercallback(activity);
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {

                                        VideoCallbackNextManager.this.interstitiAdm = null;
                                        isLargeRunningNow = false;

                                        if (nextClickInterface != null) {
                                            nextClickInterface.stonCallDismissInterstiAd("");
                                            nextClickInterface = null;
                                        }
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                        isLargeRunningNow = true;
                                    }

                                });

                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                                interstitiAdm = null;
                                if (!anotherClickLoading) {
                                    loadReturn(activity);
                                }
                                anotherClickLoading = false;
                            }
                        });

                    } else {
                        interstitiAdm = null;
                    }
                }

                try {
                    if (editorAppDetailModel.getCounter() != null && !TextUtils.isEmpty(editorAppDetailModel.getCounter())) {
                        clickToOpenNumbers = Integer.valueOf(editorAppDetailModel.getCounter());
                    }
                } catch (Exception e) {
                    clickToOpenNumbers = 3;
                }


            }
        } catch (Exception e) {
        }
    }

    public void openCallbackNextVideo(Activity activity, OpenCallbackNextClickInterface callInterstitalAdClosed) {
        long now = System.currentTimeMillis();
        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
            return;
        }
        mLastClickTime = now;

        nextClickInterface = callInterstitalAdClosed;

        if (VideotoaudoApplication.getVideotoaudoApplication().modelInterCheckEmpty()) {
            recreateHandlerInside();
            nextClickInterface.stonCallDismissInterstiAd("");
            return;
        }
        recreateHandlerInside();

        if (interstitiAdm != null) {
            interstitiAdm.show(activity);
            errorFailedTracker = 0;


        } else if (interstitialRewardAd != null) {
            interstitialRewardAd.show(activity);
            bgOpenErrorReturn = 0;

            if (interstitiAdm == null) {
                errorFailedTracker += 1;
                if (errorFailedTracker >= 5) {
                    errorFailedTracker = 0;
                    anotherClickLoading = true;
                    findintercallback(activity);
                }
                if (errorFailedTracker >= 3) {
                    anotherClickLoading = false;
                }
            }

        } else {
            if (nextClickInterface != null) {
                nextClickInterface.stonCallDismissInterstiAd("");
                nextClickInterface = null;
            }

            if (interstitialRewardAd == null) {

                bgOpenErrorReturn += 1;
                if (bgOpenErrorReturn >= 5) {
                    bgOpenErrorReturn = 0;
                    anotherClickLoading = true;
                    loadReturn(activity);
                }
                if (bgOpenErrorReturn >= 3) {
                    anotherClickLoading = false;
                }
            }

            if (interstitiAdm == null) {
                if (flagFromWithoutSplashBig) {
                    flagFromWithoutSplashBig = false;
                    findintercallback(activity);
                } else {
                    errorFailedTracker += 1;
                    if (errorFailedTracker >= 5) {
                        errorFailedTracker = 0;
                        anotherClickLoading = true;
                        findintercallback(activity);
                    }
                    if (errorFailedTracker >= 3) {
                        anotherClickLoading = false;
                    }
                }

            }


        }
    }


    public void loadReturn(Activity activity) {
        try {
            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
            anotherClickLoading = true;

            if (interstitialRewardAd == null) {
                if (editorAppDetailModel != null && editorAppDetailModel.getAdmob2interstitial() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmob2interstitial())
                        && editorAppDetailModel.getAdstatus() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdstatus()) && editorAppDetailModel.getAdstatus().equalsIgnoreCase("1")
                ) {

                    AdRequest adRequest = new AdRequest.Builder().build();
                    InterstitialAd.load(activity, editorAppDetailModel.getAdmob2interstitial(), adRequest, new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                            VideoCallbackNextManager.this.interstitialRewardAd = interstitialAd;
                            bgOpenErrorReturn = 0;
                            anotherClickLoading = true;
                            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {

                                @Override
                                public void onAdDismissedFullScreenContent() {

                                    VideoCallbackNextManager.this.interstitialRewardAd = null;
                                    isLargeRunningNow = false;

                                    if (nextClickInterface != null) {
                                        nextClickInterface.stonCallDismissInterstiAd("");
                                        nextClickInterface = null;
                                    }
                                    anotherClickLoading = true;
                                    loadReturn(activity);
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {

                                    VideoCallbackNextManager.this.interstitialRewardAd = null;
                                    isLargeRunningNow = false;

                                    if (nextClickInterface != null) {
                                        nextClickInterface.stonCallDismissInterstiAd("");
                                        nextClickInterface = null;
                                    }
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                    anotherClickLoading = true;

                                    isLargeRunningNow = true;
                                }

                            });
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                            interstitialRewardAd = null;


                        }
                    });


                } else {
                    interstitialRewardAd = null;

                }

            }

        } catch (Exception e) {

        }
    }

    private long mLastClickTime = System.currentTimeMillis();

    private long CLICK_TIME_INTERVAL = 700;
    OpenCallbackNextClickInterface nextClickInterface;

    public static int errorFailedTracker = 0;
    public static int bgOpenErrorReturn = 0;

    public static boolean isLargeRunningNow = false;
    public static boolean isInsidestatusActive = true;


    public InterstitialAd interstitialRewardAd;


    public static int clickToOpenNumbers = 3;


    public static boolean flagFromWithoutSplashBig = true;
    public static boolean anotherClickLoading = false;


    void recreateHandlerInside() {
        numberSets++;

        if (numberSets >= clickToOpenNumbers) {
            numberSets = 0;
            isInsidestatusActive = true;
        } else {
            isInsidestatusActive = false;
        }

    }


}
