package com.si_vidoditor.paras_viddaditorapp.appclass;

import android.app.Activity;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.si_vidoditor.paras_viddaditorapp.activity.SplashActivty;

import org.jetbrains.annotations.NotNull;

import java.util.Date;


public class AppopnEditManager {
    private static AppOpenAd openAppAdManager;

    public static VideotoaudoApplication videotoaudoApplication;

    public static boolean checkOpenIsShowing = false;
    private static long loadNEwTime = 0;

    public static boolean isAdAvailable() {
        return openAppAdManager != null && wasLoadTimeLessThanNHoursAgo(4);
    }

    private static boolean wasLoadTimeLessThanNHoursAgoReward(long numHours) {
        long dateDifference = (new Date()).getTime() - loadTimeReward;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));

    }

    public static boolean isAdAvailableReward() {
        return openAppAdManagerReward != null && wasLoadTimeLessThanNHoursAgoReward(4);
    }

    static int flagOpenNewCount = 0;
    private static AppOpenAd.AppOpenAdLoadCallback appLoadOpendCallback;

    private static long loadTimeReward = 0;
    public static boolean editorOpenFlag = true;

    public AppopnEditManager(VideotoaudoApplication myMainApplication) {
        this.videotoaudoApplication = myMainApplication;

    }

    public static Activity runningActivity;
    static int appCheckErrors = 0;

    public static void appopenRefetch() {

        if (videotoaudoApplication == null) {
            videotoaudoApplication = VideotoaudoApplication.getVideotoaudoApplication();
        }

        if (isAdAvailable()) {
            if (!VideotoaudoApplication.isVidoSplashNot) {

                try {
                    SplashActivty.getSplashActivty().pauseRunRunnable();
                } catch (Exception e) {

                }
                openDontShow = false;
                showIfOpenAvailable(new VideotoaudoApplication.OpenCallbackAppClosed() {
                    @Override
                    public void setDissmissOpenListener() {
                        try {
                            SplashActivty.getSplashActivty().showActivityGo();
                        } catch (Exception e) {

                        }
                    }
                });
            }
            return;
        }


        appLoadOpendCallback = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull @NotNull AppOpenAd ad) {

                openAppAdManager = ad;
                loadNEwTime = new Date().getTime();
                appCheckErrors = 0;

                if (!VideotoaudoApplication.isVidoSplashNot && VideotoaudoApplication.flag_Resme) {

                    try {
                        SplashActivty.getSplashActivty().pauseRunRunnable();
                        SplashActivty.getSplashActivty().apiDemResponse();
                    } catch (Exception e) {

                    }

                    openDontShow = false;
                    showIfOpenAvailable(new VideotoaudoApplication.OpenCallbackAppClosed() {
                        @Override
                        public void setDissmissOpenListener() {
                            try {
                                SplashActivty.getSplashActivty().showActivityGo();
                            } catch (Exception d) {

                            }
                        }
                    });
                }
            }

            @Override
            public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {
                if (appCheckErrors == 0) {
                    appCheckErrors += 1;
                }
                fetchOptionAppopen();
            }
        };

        try {
            AdRequest build = new AdRequest.Builder().build();
            AppOpenAd.load(VideotoaudoApplication.getVideotoaudoApplication(),
                    VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getAdmobnew().toString(), build, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, appLoadOpendCallback);
        } catch (Exception e) {

        }

    }

    public static void showIfOpenAvailable(VideotoaudoApplication.OpenCallbackAppClosed openCallbackAppClosed) {
        try {
            if (!openDontShow) {
                if (!VideotoaudoApplication.getVideotoaudoApplication().hereOpenModelNull()) {

                    if (checkOpenIsShowing) {
                        return;
                    }
                    if (isAdAvailable()) {
                        checkOpenIsShowing = true;

                        openAppAdManager.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                openAppAdManager = null;
                                checkOpenIsShowing = false;

                                openCallbackAppClosed.setDissmissOpenListener();

                                appopenRefetch();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                checkOpenIsShowing = false;
                                openCallbackAppClosed.setDissmissOpenListener();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {

                                checkOpenIsShowing = true;

                                try {
                                    SplashActivty.getSplashActivty().pauseRunRunnable();
                                } catch (Exception e) {

                                }

                            }
                        });
                        openAppAdManager.show(runningActivity);
                        appCheckErrors = 0;
                    } else {

                        if (editorOpenFlag) {
                            VideoCallbackNextManager.getVideoCallbackNext();
                            editorOpenFlag = false;
                            appopenRefetch();
                            openCallbackAppClosed.setDissmissOpenListener();
                        } else {
                            if (VideotoaudoApplication.isVidoSplashNot) {
                                appCheckErrors += 1;

                                if (appCheckErrors >= 3) {
                                    appCheckErrors = 0;
                                    appopenRefetch();
                                }
                            }

                            showOpenNextOption(openCallbackAppClosed);
                        }
                    }
                } else {
                    showOpenNextOption(openCallbackAppClosed);
                }
            } else {
                openDontShow = false;
                openCallbackAppClosed.setDissmissOpenListener();
            }

        } catch (Exception e) {

        }

    }


    public static void fetchOptionAppopen() {
        if (videotoaudoApplication == null) {
            videotoaudoApplication = VideotoaudoApplication.getVideotoaudoApplication();
        }

        if (!VideotoaudoApplication.getVideotoaudoApplication().flagNextOpenModelNull()) {
            if (isAdAvailableReward()) {
                if (!VideotoaudoApplication.isVidoSplashNot) {

                    try {
                        SplashActivty.getSplashActivty().pauseRunRunnable();
                    } catch (Exception e) {

                    }

                    showIfOpenAvailable(new VideotoaudoApplication.OpenCallbackAppClosed() {
                        @Override
                        public void setDissmissOpenListener() {
                            try {
                                SplashActivty.getSplashActivty().showActivityGo();
                            } catch (Exception e) {

                            }
                        }
                    });
                }
                return;
            }


            appOpenAdLoadCallbackReward = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull @NotNull AppOpenAd ad) {

                    openAppAdManagerReward = ad;
                    loadTimeReward = new Date().getTime();
                    flagOpenNewCount = 0;

                    if (!VideotoaudoApplication.isVidoSplashNot && VideotoaudoApplication.flag_Resme) {

                        try {
                            SplashActivty.getSplashActivty().pauseRunRunnable();
                            SplashActivty.getSplashActivty().apiDemResponse();
                        } catch (Exception e) {

                        }

                        showIfOpenAvailable(new VideotoaudoApplication.OpenCallbackAppClosed() {
                            @Override
                            public void setDissmissOpenListener() {
                                try {
                                    SplashActivty.getSplashActivty().showActivityGo();
                                } catch (Exception d) {

                                }
                            }
                        });
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                }
            };

            try {
                AdRequest build = new AdRequest.Builder().build();
                AppOpenAd.load(VideotoaudoApplication.getVideotoaudoApplication(),
                        VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel().getAdmob2appopen().toString(), build,
                        AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, appOpenAdLoadCallbackReward);
            } catch (Exception e) {

            }
        }

    }

    private static boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - loadNEwTime;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));

    }

    private static AppOpenAd openAppAdManagerReward;
    private static AppOpenAd.AppOpenAdLoadCallback appOpenAdLoadCallbackReward;

    public static boolean openDontShow = false;

    public static void showOpenNextOption(VideotoaudoApplication.OpenCallbackAppClosed openCallbackAppClosed) {
        try {
            if (!openDontShow) {
                if (!VideotoaudoApplication.getVideotoaudoApplication().flagNextOpenModelNull()) {
                    if (checkOpenIsShowing) {
                        return;
                    }
                    if (isAdAvailableReward()) {
                        checkOpenIsShowing = true;

                        openAppAdManagerReward.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                openAppAdManagerReward = null;
                                checkOpenIsShowing = false;

                                openCallbackAppClosed.setDissmissOpenListener();

                                if (VideotoaudoApplication.getVideotoaudoApplication().hereOpenModelNull()) {
                                    fetchOptionAppopen();
                                } else {
                                    if (appCheckErrors != 0) {
                                        appopenRefetch();
                                    }
                                }
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                checkOpenIsShowing = false;
                                openCallbackAppClosed.setDissmissOpenListener();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {

                                checkOpenIsShowing = true;
                                try {
                                    SplashActivty.getSplashActivty().pauseRunRunnable();
                                } catch (Exception e) {

                                }
                            }
                        });
                        openAppAdManagerReward.show(runningActivity);
                        flagOpenNewCount = 0;
                    } else {

                        if (editorOpenFlag) {
                            VideoCallbackNextManager.getVideoCallbackNext();
                            editorOpenFlag = false;

                            fetchOptionAppopen();

                        } else {

                            if (VideotoaudoApplication.isVidoSplashNot) {
                                flagOpenNewCount += 1;

                                if (flagOpenNewCount >= 2) {
                                    flagOpenNewCount = 0;

                                    if (VideotoaudoApplication.getVideotoaudoApplication().hereOpenModelNull() && !VideotoaudoApplication.getVideotoaudoApplication().flagNextOpenModelNull()) {
                                        fetchOptionAppopen();
                                    }
                                }
                            }

                        }

                        openCallbackAppClosed.setDissmissOpenListener();
                    }

                } else {
                    openCallbackAppClosed.setDissmissOpenListener();
                }
            } else {
                openDontShow = false;
                openCallbackAppClosed.setDissmissOpenListener();
            }

        } catch (Exception e) {

        }
    }

}
