package com.si_vidoditor.paras_viddaditorapp.appclass;


import com.si_vidoditor.paras_viddaditorapp.Models.ResponseEditorModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceEditorsApi {


    @FormUrlEncoded
    @POST("api.php")
    Call<ResponseEditorModel> getAll(@Field("package") String deviceId);


}
