package com.si_vidoditor.paras_viddaditorapp.appclass;

import android.app.Activity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;
import com.si_vidoditor.paras_viddaditorapp.R;

public class MagerBanners {

    private EditorAppDetailModel detailApp;
    private static MagerBanners ourInstance;

    private LinearLayout linearLayoutLoader;


    public static MagerBanners getInstance() {
        if (ourInstance == null) {
            ourInstance = new MagerBanners();
        }
        return ourInstance;
    }

    private AdSize getAdSize(Activity activity) {

        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;


        int adWidth = (int) (widthPixels / density);


        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public void loadBanneAds(Activity activity, FrameLayout frameLayout, RelativeLayout cardBAnner) {
        detailApp = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
        if (detailApp != null && detailApp.getAdstatus() != null && !TextUtils.isEmpty(detailApp.getAdstatus()) && detailApp.getAdstatus().equalsIgnoreCase("1")) {
            LayoutInflater inflater = LayoutInflater.from(activity);
            linearLayoutLoader = (LinearLayout) inflater.inflate(R.layout.item_loader_banner, frameLayout, false);
            frameLayout.addView(linearLayoutLoader);
            cardBAnner.setVisibility(View.VISIBLE);
            loadABanner(activity, frameLayout,cardBAnner);

        } else {
            frameLayout.setVisibility(View.INVISIBLE);
            cardBAnner.setVisibility(View.INVISIBLE);
        }
    }

    private void loadABanner(Activity activity, FrameLayout frameLayout,RelativeLayout cardBAnner) {
        frameLayout.setBackgroundResource(R.drawable.adbgbanner);

        try {
            if (detailApp.getAdmobbanner() != null && !TextUtils.isEmpty(detailApp.getAdmobbanner())) {
                AdView adView = new AdView(activity);
                adView.setAdSize(getAdSize(activity));
                adView.setAdUnitId(detailApp.getAdmobbanner());
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        frameLayout.setVisibility(View.VISIBLE);
                        cardBAnner.setVisibility(View.VISIBLE);
                        linearLayoutLoader.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        if (detailApp.getAdmob2banner() != null && !TextUtils.isEmpty(detailApp.getAdmob2banner())) {
                            AdView adView = new AdView(activity);
                            adView.setAdSize(getAdSize(activity));
                            adView.setAdUnitId(detailApp.getAdmob2banner());
                            AdRequest adRequest = new AdRequest.Builder().build();
                            adView.loadAd(adRequest);
                            adView.setAdListener(new AdListener() {
                                @Override
                                public void onAdLoaded() {
                                    frameLayout.setVisibility(View.VISIBLE);
                                    cardBAnner.setVisibility(View.VISIBLE);
                                    linearLayoutLoader.setVisibility(View.GONE);
                                }

                                @Override
                                public void onAdFailedToLoad(LoadAdError loadAdError) {
                                    frameLayout.setVisibility(View.INVISIBLE);
                                    cardBAnner.setVisibility(View.INVISIBLE);
                                    linearLayoutLoader.setVisibility(View.GONE);

                                }
                            });

                            frameLayout.addView(adView);
                        } else {
                            frameLayout.setVisibility(View.INVISIBLE);
                            cardBAnner.setVisibility(View.INVISIBLE);
                            linearLayoutLoader.setVisibility(View.GONE);

                        }
                    }
                });

                frameLayout.addView(adView);
            } else if (detailApp.getAdmob2banner() != null && !TextUtils.isEmpty(detailApp.getAdmob2banner())) {
                AdView adView = new AdView(activity);
                adView.setAdSize(getAdSize(activity));
                adView.setAdUnitId(detailApp.getAdmob2banner());
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        frameLayout.setVisibility(View.VISIBLE);
                        cardBAnner.setVisibility(View.VISIBLE);
                        linearLayoutLoader.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        frameLayout.setVisibility(View.INVISIBLE);
                        cardBAnner.setVisibility(View.INVISIBLE);
                        linearLayoutLoader.setVisibility(View.GONE);

                    }
                });

                frameLayout.addView(adView);
            } else {
                frameLayout.setVisibility(View.INVISIBLE);
                cardBAnner.setVisibility(View.INVISIBLE);
                linearLayoutLoader.setVisibility(View.GONE);

            }
        } catch (Exception e) {
            try {
                frameLayout.setVisibility(View.INVISIBLE);
                cardBAnner.setVisibility(View.INVISIBLE);
                linearLayoutLoader.setVisibility(View.GONE);
            }catch (Exception e2){

            }


        }

    }


}
