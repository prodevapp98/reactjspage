package com.si_vidoditor.paras_viddaditorapp.appclass;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.multidex.MultiDex;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAdsDetail;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;
import com.si_vidoditor.paras_viddaditorapp.view.PreferenceUtil;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;


public class VideotoaudoApplication extends Application implements LifecycleObserver, Application.ActivityLifecycleCallbacks {


    public static boolean isVidoSplashNot = true;

    public static String splashCheckScreen = "SplashActivty";
    public static VideotoaudoApplication videotoaudoApplication;
    public static SharedPreferences sharedPreferences;
    private static final String app_DETAILS = "app_details", PREF_ad_DETAILS = "ads_details";

    @Override
    public void onCreate() {
        super.onCreate();

        videotoaudoApplication = this;
        MultiDex.install(this);

        sharedPreferences = getApplicationContext().getSharedPreferences("MyAdsPrefs", MODE_PRIVATE);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(@NonNull @NotNull InitializationStatus initializationStatus) {

            }
        });

        registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().build());

    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }

    public static AppopnEditManager appopnEditManager;

    public static VideotoaudoApplication getVideotoaudoApplication() {
        return videotoaudoApplication;
    }

    public static boolean flag_Resme = true;

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (activity.toString().contains(splashCheckScreen)) {
            AppopnEditManager.runningActivity = activity;
        } else {
            AppopnEditManager.checkOpenIsShowing = false;
        }
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
        flag_Resme = false;
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {

    }

    public static Context getAppContext() {
        return videotoaudoApplication;
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onStart() {


        if (isVidoSplashNot) {
            if (!VideoCallbackNextManager.isLargeRunningNow) {

                AppopnEditManager.showIfOpenAvailable(new OpenCallbackAppClosed() {
                    @Override
                    public void setDissmissOpenListener() {

                    }
                });
            }
        }
    }

    public PreferenceUtil getPreferencesUtility() {
        return PreferenceUtil.getInstance(VideotoaudoApplication.this);
    }


    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        AppopnEditManager.runningActivity = activity;
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        flag_Resme = true;
        AppopnEditManager.runningActivity = activity;
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        AppopnEditManager.runningActivity = null;
    }

    public void openInitApp() {
        appopnEditManager = new AppopnEditManager(this);
    }


    public interface OpenCallbackAppClosed {
        void setDissmissOpenListener();
    }


    public EditorAppDetailModel getEditorAppDetailModel() {
        try {
            return new Gson().fromJson(sharedPreferences.getString(app_DETAILS, ""), EditorAppDetailModel.class);
        } catch (Exception e) {
            return null;
        }

    }

    public boolean hereOpenModelNull() {
        if (getEditorAppDetailModel() == null) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdstatus())) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus().equals("")) {
            return true;
        } else if (!getEditorAppDetailModel().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else if (getEditorAppDetailModel().getAdmobnew() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdmobnew())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean flagNextOpenModelNull() {
        if (getEditorAppDetailModel() == null) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdstatus())) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus().equals("")) {
            return true;
        } else if (!getEditorAppDetailModel().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else if (getEditorAppDetailModel().getAdmob2appopen() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdmob2appopen())) {
            return true;
        } else {
            return false;
        }
    }

    public void setEditorAppDetailModel(EditorAppDetailModel appDetail) {
        sharedPreferences.edit().putString(app_DETAILS, new Gson().toJson(appDetail)).apply();
    }

    public ArrayList<EditorAdsDetail> getEditorAdsDetail() {
        try {
            return new Gson().fromJson(sharedPreferences.getString(PREF_ad_DETAILS, ""), new TypeToken<ArrayList<EditorAdsDetail>>() {
            }.getType());
        } catch (Exception e) {

        }
        return null;
    }

    public void setEditorAdsDetail(ArrayList<EditorAdsDetail> adsDetails) {

        sharedPreferences.edit().putString(PREF_ad_DETAILS, new Gson().toJson(adsDetails)).apply();
    }

    public boolean modelInterCheckEmpty() {
        if (getEditorAppDetailModel() == null) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdstatus())) {
            return true;
        } else if (!getEditorAppDetailModel().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            if (!VideoCallbackNextManager.isInsidestatusActive) {
                return true;
            } else {
                return false;
            }

        }
    }

    public boolean modelApiCheck() {
        if (getEditorAppDetailModel() == null) {
            return true;
        } else if (getEditorAppDetailModel().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getEditorAppDetailModel().getAdstatus())) {
            return true;
        } else if (!getEditorAppDetailModel().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            return false;
        }
    }


}