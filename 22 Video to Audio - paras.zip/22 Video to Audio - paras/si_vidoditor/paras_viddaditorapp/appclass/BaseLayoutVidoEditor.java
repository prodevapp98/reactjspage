package com.si_vidoditor.paras_viddaditorapp.appclass;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;
import com.si_vidoditor.paras_viddaditorapp.R;

import org.jetbrains.annotations.NotNull;

public class BaseLayoutVidoEditor {


    public static int countNList1 = 0;

    public static void loadN1(Activity activity) {
        try {

            if (VideotoaudoApplication.getVideotoaudoApplication().modelApiCheck()) {
                return;
            }
            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
            if (editorAppDetailModel != null && editorAppDetailModel.getAdmobnative() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmobnative())) {

                AdLoader.Builder builder = new AdLoader.Builder(activity, editorAppDetailModel.getAdmobnative()).forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {

                        adNativeListFirst = null;
                        adNativeListFirst = unifiedNativeAd;
                        countNList1 = 0;
                    }
                });
                AdLoader adLoader = builder.withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                    }
                }).build();

                adLoader.loadAd(new AdRequest.Builder().build());
            }
        } catch (Exception e) {

        }

    }


    public static void loadN2(Activity activity) {
        try {

            if (VideotoaudoApplication.getVideotoaudoApplication().modelApiCheck()) {
                return;
            }
            EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
            if (editorAppDetailModel != null && editorAppDetailModel.getAdmob2native() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmob2native())) {
                AdLoader.Builder builder = new AdLoader.Builder(activity, editorAppDetailModel.getAdmob2native())
                        .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                            @Override
                            public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {

                                adNativeListSecond = null;
                                adNativeListSecond = unifiedNativeAd;
                                countNList2 = 0;
                            }
                        });
                AdLoader adLoader = builder.withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                    }
                }).build();

                adLoader.loadAd(new AdRequest.Builder().build());
            }
        } catch (Exception e) {

        }

    }

    public static int countNList2 = 0;

    public static NativeAd adNativeListSecond;
    public static boolean flagFromWithoutSplashNative = true;

    public static void showNativeOnce(Activity activity, FrameLayout frameNative, RelativeLayout relativeNative ) {

        try {

            relativeNative.setVisibility(View.INVISIBLE);
            if (adNativeListFirst != null) {
                countNList1 = 0;

                frameNative.setVisibility(View.VISIBLE);


                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.layout_native1, null);

                frameNative.removeAllViews();
                frameNative.addView(nativeAdView);
                relativeNative.setVisibility(View.VISIBLE);
                populateNativeAdView(adNativeListFirst, nativeAdView);

                adNativeListFirst = null;
                loadN1(activity);

            } else if (adNativeListSecond != null) {
                countNList2 = 0;

                frameNative.setVisibility(View.VISIBLE);

                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.layout_native1, null);
                frameNative.removeAllViews();
                frameNative.addView(nativeAdView);
                relativeNative.setVisibility(View.VISIBLE);
                populateNativeAdView(adNativeListSecond, nativeAdView);

                adNativeListSecond = null;
                loadN2(activity);

                if (adNativeListFirst == null) {

                    countNList1 += 1;
                    if (countNList1 >= 6) {
                        countNList1 = 0;
                        if (adNativeListFirst == null) {
                            loadN1(activity);
                        }
                    }
                }

            } else {

                if (VideotoaudoApplication.getVideotoaudoApplication().modelApiCheck()) {
                    relativeNative.setVisibility(View.INVISIBLE);
                    return;
                }

                frameNative.setVisibility(View.VISIBLE);

                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.layout_native1, null);
                frameNative.removeAllViews();
                frameNative.addView(nativeAdView);

                EditorAppDetailModel editorAppDetailModel = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
                if (editorAppDetailModel != null && editorAppDetailModel.getAdmobnative() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmobnative())) {
                    AdLoader.Builder builder = new AdLoader.Builder(activity, editorAppDetailModel.getAdmobnative())
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {

                                    relativeNative.setVisibility(View.VISIBLE);
                                    populateNativeAdView(unifiedNativeAd, nativeAdView);
                                }
                            });

                    AdLoader adLoader = builder.withAdListener(new AdListener() {
                        @Override
                        public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {
                            if (editorAppDetailModel != null && editorAppDetailModel.getAdmob2native() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmob2native())) {
                                AdLoader.Builder builder = new AdLoader.Builder(activity, editorAppDetailModel.getAdmob2native())
                                        .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                            @Override
                                            public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {
                                                relativeNative.setVisibility(View.VISIBLE);
                                                populateNativeAdView(unifiedNativeAd, nativeAdView);
                                            }
                                        });

                                AdLoader adLoader = builder.withAdListener(new AdListener() {
                                    @Override
                                    public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {
                                        relativeNative.setVisibility(View.INVISIBLE);
                                    }
                                }).build();
                                adLoader.loadAd(new AdRequest.Builder().build());
                            } else {
                                relativeNative.setVisibility(View.INVISIBLE);
                            }
                        }
                    }).build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                } else if (editorAppDetailModel != null && editorAppDetailModel.getAdmob2native() != null && !TextUtils.isEmpty(editorAppDetailModel.getAdmob2native())) {
                    AdLoader.Builder builder = new AdLoader.Builder(activity, editorAppDetailModel.getAdmob2native())
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {

                                    relativeNative.setVisibility(View.VISIBLE);
                                    populateNativeAdView(unifiedNativeAd, nativeAdView);
                                }
                            });

                    AdLoader adLoader = builder.withAdListener(new AdListener() {
                        @Override
                        public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                            relativeNative.setVisibility(View.INVISIBLE);
                        }
                    }).build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                } else {

                    relativeNative.setVisibility(View.INVISIBLE);

                }

                if (adNativeListFirst == null) {
                    if (flagFromWithoutSplashNative) {
                        VideoCallbackNextManager.getVideoCallbackNext();
                        flagFromWithoutSplashNative = false;
                        loadN1(activity);
                    } else {
                        countNList1 += 1;
                        if (countNList1 >= 6) {
                            countNList1 = 0;
                            if (adNativeListFirst == null) {
                                loadN1(activity);
                            }
                        }
                    }

                }

                if (adNativeListSecond == null) {

                    countNList2 += 1;
                    if (countNList2 >= 6) {
                        countNList2 = 0;
                        if (adNativeListSecond == null) {
                            loadN2(activity);
                        }
                    }
                }

            }
        } catch (Exception e) {

        }

    }

    public static NativeAd adNativeListFirst;

    public static void showBannerOnce(Activity activity, FrameLayout frameLayoutBanner, RelativeLayout relativeBAnner) {

        try {
            relativeBAnner.setVisibility(View.INVISIBLE);
            if (adNativeListFirst != null) {
                countNList1 = 0;

                frameLayoutBanner.setVisibility(View.VISIBLE);
                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                frameLayoutBanner.removeAllViews();
                frameLayoutBanner.addView(nativeAdView);
                relativeBAnner.setVisibility(View.VISIBLE);
                populateBannerAdView(adNativeListFirst, nativeAdView);


                adNativeListFirst = null;
                loadN1(activity);


            } else if (adNativeListSecond != null) {
                countNList2 = 0;

                frameLayoutBanner.setVisibility(View.VISIBLE);
                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                frameLayoutBanner.removeAllViews();
                frameLayoutBanner.addView(nativeAdView);
                relativeBAnner.setVisibility(View.VISIBLE);
                populateBannerAdView(adNativeListSecond, nativeAdView);


                adNativeListSecond = null;
                loadN2(activity);

                if (adNativeListFirst == null) {

                    countNList1 += 1;
                    if (countNList1 >= 6) {
                        countNList1 = 0;
                        if (adNativeListFirst == null) {
                            loadN1(activity);
                        }
                    }

                }

            } else {


                if (VideotoaudoApplication.getVideotoaudoApplication().modelApiCheck()) {

                    relativeBAnner.setVisibility(View.INVISIBLE);

                    return;
                }

                frameLayoutBanner.setVisibility(View.VISIBLE);
                NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                frameLayoutBanner.removeAllViews();
                frameLayoutBanner.addView(nativeAdView);

                EditorAppDetailModel appDetail = VideotoaudoApplication.getVideotoaudoApplication().getEditorAppDetailModel();
                if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative())) {
                    AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative())
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {
                                    relativeBAnner.setVisibility(View.VISIBLE);
                                    populateBannerAdView(unifiedNativeAd, nativeAdView);

                                }
                            });

                    AdLoader adLoader = builder.withAdListener(
                            new AdListener() {
                                @Override
                                public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {
                                    if (appDetail != null && appDetail.getAdmob2native() != null && !TextUtils.isEmpty(appDetail.getAdmob2native())) {
                                        AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native())
                                                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                                    @Override
                                                    public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {
                                                        relativeBAnner.setVisibility(View.VISIBLE);
                                                        populateBannerAdView(unifiedNativeAd, nativeAdView);

                                                    }
                                                });

                                        AdLoader adLoader = builder.withAdListener(
                                                new AdListener() {
                                                    @Override
                                                    public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                                                        relativeBAnner.setVisibility(View.INVISIBLE);

                                                    }
                                                }).build();
                                        adLoader.loadAd(new AdRequest.Builder().build());
                                    } else {

                                        relativeBAnner.setVisibility(View.INVISIBLE);

                                    }

                                }
                            }).build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                } else if (appDetail != null && appDetail.getAdmob2native() != null && !TextUtils.isEmpty(appDetail.getAdmob2native())) {
                    AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native())
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(@NonNull @NotNull NativeAd unifiedNativeAd) {
                                    relativeBAnner.setVisibility(View.VISIBLE);
                                    populateBannerAdView(unifiedNativeAd, nativeAdView);

                                }
                            });

                    AdLoader adLoader = builder.withAdListener(
                            new AdListener() {
                                @Override
                                public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {

                                    relativeBAnner.setVisibility(View.INVISIBLE);

                                }
                            }).build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                } else {

                    relativeBAnner.setVisibility(View.INVISIBLE);

                }


                if (adNativeListFirst == null) {
                    if (flagFromWithoutSplashNative) {
                        VideoCallbackNextManager.getVideoCallbackNext();
                        flagFromWithoutSplashNative = false;
                        loadN1(activity);
                    } else {
                        countNList1 += 1;
                        if (countNList1 >= 6) {
                            countNList1 = 0;
                            if (adNativeListFirst == null) {
                                loadN1(activity);
                            }
                        }

                    }

                }
                if (adNativeListSecond == null) {

                    countNList2 += 1;
                    if (countNList2 >= 6) {
                        countNList2 = 0;
                        if (adNativeListSecond == null) {
                            loadN2(activity);
                        }
                    }

                }


            }
        } catch (Exception e) {

        }
    }


    public static void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);


        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));


        if (((TextView) adView.getHeadlineView()) != null) {
            ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        }
        if (adView.getMediaView() != null) {
            if (nativeAd.getMediaContent() != null) {
                adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
            }
        }
        if (nativeAd.getBody() == null) {
            if (adView.getBodyView() != null) {
                adView.getBodyView().setVisibility(View.INVISIBLE);
            }
        } else {
            if (adView.getBodyView() != null) {
                adView.getBodyView().setVisibility(View.VISIBLE);
                ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
            }

        }
        if (nativeAd.getCallToAction() == null) {
            if (adView.getCallToActionView() != null) {
                adView.getCallToActionView().setVisibility(View.INVISIBLE);
            }
        } else {
            if (adView.getCallToActionView() != null) {
                adView.getCallToActionView().setVisibility(View.VISIBLE);
                ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
            }


        }
        if (nativeAd.getIcon() == null) {
            if (adView.getIconView() != null) {
                adView.getIconView().setVisibility(View.GONE);
            }
        } else {
            if (((ImageView) adView.getIconView()) != null) {
                ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
            }

        }


        adView.setNativeAd(nativeAd);

    }

    public static void populateBannerAdView(NativeAd nativeAd, NativeAdView adView) {

        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());


        if (nativeAd.getBody() == null) {
            if (adView.getBodyView() != null) {
                adView.getBodyView().setVisibility(View.INVISIBLE);
            }

        } else {
            if (adView.getBodyView() != null) {
                adView.getBodyView().setVisibility(View.VISIBLE);
                ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
            }

        }
        if (nativeAd.getCallToAction() == null) {
            if (adView.getCallToActionView() != null) {
                adView.getCallToActionView().setVisibility(View.INVISIBLE);
            }
        } else {
            if (adView.getCallToActionView() != null) {
                adView.getCallToActionView().setVisibility(View.VISIBLE);
                ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
            }


        }
        if (nativeAd.getIcon() == null) {
            if (adView.getIconView() != null) {
                adView.getIconView().setVisibility(View.GONE);
            }
        } else {
            if (((ImageView) adView.getIconView()) != null) {
                ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
            }

        }

        adView.setNativeAd(nativeAd);
    }

}
