package com.si_vidoditor.paras_viddaditorapp.Models;

import com.si_vidoditor.paras_viddaditorapp.Models.EditorAdsDetail;
import com.si_vidoditor.paras_viddaditorapp.Models.EditorAppDetailModel;

import java.util.ArrayList;

public class ResponseEditorModel {
    private ArrayList<EditorAdsDetail> adsdetail = new ArrayList<>();
    private EditorAppDetailModel appdetail;

    public ArrayList<EditorAdsDetail> getAdsdetail() {
        return adsdetail;
    }

    public void setAdsdetail(ArrayList<EditorAdsDetail> adsdetail) {
        this.adsdetail = adsdetail;
    }

    public EditorAppDetailModel getAppdetail() {
        return appdetail;
    }

    public void setAppdetail(EditorAppDetailModel appdetail) {
        this.appdetail = appdetail;
    }
}
