package com.si_vidoditor.paras_viddaditorapp.ringtone;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.utils.DataProccessor;

public class SetRingtoneActivty extends AppCompatActivity {

    private ImageView imageView;
    private ConstraintLayout bv_setrin, bv_noti, bv_alarm;
    private DataProccessor dataProccessor;
    private ConstraintLayout cl_alarm, cl_ring, cl_noti;
    private TextView tv_sring, tv_noti, tv_alarm;

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_ringtone_activty);


        cl_alarm = findViewById(R.id.cl_alarm);
        cl_ring = findViewById(R.id.cl_ring);
        cl_noti = findViewById(R.id.cl_noti);


        tv_sring = findViewById(R.id.tv_sring);
        tv_noti = findViewById(R.id.tv_noti);
        tv_alarm = findViewById(R.id.tv_alarm);


        dataProccessor = new DataProccessor(SetRingtoneActivty.this);





        BaseLayoutVidoEditor.showNativeOnce(this, findViewById(R.id.framLarge), findViewById(R.id.rlNative)  );

        imageView = findViewById(R.id.imageView);

        bv_setrin = findViewById(R.id.bv_setrin);
        bv_noti = findViewById(R.id.bv_noti);
        bv_alarm = findViewById(R.id.bv_alarm);


        bv_setrin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(SetRingtoneActivty.this, msg -> {
                    startActivity(new Intent(SetRingtoneActivty.this, RingtoneActivty.class)
                            .putExtra("type", "ringtone"));
                });


            }
        });
        bv_noti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(SetRingtoneActivty.this, msg -> {
                    startActivity(new Intent(SetRingtoneActivty.this, RingtoneActivty.class)
                            .putExtra("type", "notification"));
                });


            }
        });
        bv_alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(SetRingtoneActivty.this, msg -> {
                    startActivity(new Intent(SetRingtoneActivty.this, RingtoneActivty.class)
                            .putExtra("type", "alarm"));
                });

            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });


        changeColor(R.color.home_top6s);


    }

    @Override
    protected void onResume() {
        super.onResume();


        if (dataProccessor.getStr("ringtone") == null) {
            cl_ring.setVisibility(View.GONE);


        } else {
            cl_ring.setVisibility(View.VISIBLE);
            tv_sring.setText("" + dataProccessor.getStr("ringtone"));

        }


        if (dataProccessor.getStr("notification") == null) {
            cl_noti.setVisibility(View.GONE);


        } else {
            cl_noti.setVisibility(View.VISIBLE);
            tv_noti.setText("" + dataProccessor.getStr("notification"));

        }


        if (dataProccessor.getStr("alarm") == null) {
            cl_alarm.setVisibility(View.GONE);


        } else {

            cl_alarm.setVisibility(View.VISIBLE);
            tv_alarm.setText("" + dataProccessor.getStr("alarm"));

        }

    }
}