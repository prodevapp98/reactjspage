package com.si_vidoditor.paras_viddaditorapp.ringtone;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.si_vidoditor.paras_viddaditorapp.Adapters.RingtoneAdapter;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.MagerBanners;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.BlacklistStore;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.FilePAthdata2ex;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.albumInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RingtoneActivty extends AppCompatActivity {


    private ArrayList<albumInfo> albumSongList = new ArrayList<>();
    private TextView noVideoLayout;
    private ImageView imageView;
    private RecyclerView recyclerView;
    private ArrayList<File> pathDAta2 = new ArrayList<>();
    private Dialog dialog;
    private ArrayList<File> fileData = new ArrayList<>();
    private ConstraintLayout cl_all;
    RingtoneAdapter adapter;

    private SearchView iv_serch;
    private ImageView iv_serach;
    private ConstraintLayout cl_all_show, rv_layoutt;
    int sort = 0;

    MediaPlayer mediaPlayer;
    ImageView img2;
    private TextView textView12;


    @Override
    protected void onPause() {
        super.onPause();

        if (mediaPlayer != null) {

            if (mediaPlayer.isPlaying()) {

                if(img2!=null) {
                    img2.setImageResource(R.drawable.play_yellow);
                }
                mediaPlayer.pause();


            }
        }



    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ringtone);

        iniviews();


        changeColor(R.color.home_top6s);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });

        FrameLayout admobBanner = findViewById(R.id.admobBanner);
        RelativeLayout cardBAnner = findViewById(R.id.cardBAnner);
        MagerBanners.getInstance().loadBanneAds(RingtoneActivty.this, admobBanner,cardBAnner);

        inttFind();

        if (getIntent().getStringExtra("type").equals("ringtone")) {


        } else if (getIntent().getStringExtra("type").equals("notification")) {

            textView12.setText("Select Notification");

        } else {
            textView12.setText("Select Alarm");

        }


    }

    private void iniviews() {
        textView12 = findViewById(R.id.textView12);

        imageView = findViewById(R.id.imageView);
        recyclerView = findViewById(R.id.rec);
        cl_all = findViewById(R.id.cl_all);
        noVideoLayout = findViewById(R.id.noVideoLayout);


    }


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }


    private void inttFind() {


        recyclerView = findViewById(R.id.rec);
        iv_serch = findViewById(R.id.searchView);
        iv_serach = findViewById(R.id.iv_serach);
        cl_all_show = findViewById(R.id.cl_all_show);
        rv_layoutt = findViewById(R.id.rv_layoutt);


        iv_serach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_serch.performClick();
            }
        });


        iv_serch.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            iv_serch.setIconified(false);

                                        }
                                    }
        );


        iv_serch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String str) {
                return false;
            }

            public boolean onQueryTextChange(String str) {

                if (mediaPlayer != null) {

                    if (mediaPlayer.isPlaying()) {

                        if(img2!=null) {
                            img2.setImageResource(R.drawable.play_yellow);
                        }
                        mediaPlayer.pause();


                    }
                }
                if (albumSongList != null) {

                    if (adapter != null) {
                        adapter.getFilter().filter(str);
                    }


                }

                return false;
            }
        });

        iv_serch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cl_all_show.setVisibility(View.INVISIBLE);
                rv_layoutt.setVisibility(View.VISIBLE);


            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                adapter.getFilter().filter("");
                return false;

            }
        });


        iv_serch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {

                cl_all_show.setVisibility(View.VISIBLE);
                rv_layoutt.setVisibility(View.GONE);

                return false;
            }
        });


        recyclerView.setLayoutManager(new LinearLayoutManager(RingtoneActivty.this));
        noVideoLayout = findViewById(R.id.noVideoLayout);
        songs();


    }


    @SuppressLint("Range")
    public void songs() {
        Uri uri = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
        Cursor cursor;

        String[] column = {MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.MIME_TYPE,};


        String orderBy = MediaStore.Audio.Media.TITLE;

        String selection = null;

        String[] selectionValues = null;


        final String BASE_SELECTION = MediaStore.Audio.AudioColumns.IS_MUSIC + "=1" + " AND "
                + MediaStore.Audio.AudioColumns.TITLE + " != ''";
        final String[] BASE_PROJECTION = new String[]{
                BaseColumns._ID,// 0
                MediaStore.Audio.AudioColumns.TITLE,// 1
                MediaStore.Audio.AudioColumns.TRACK,// 2
                MediaStore.Audio.AudioColumns.YEAR,// 3
                MediaStore.Audio.AudioColumns.DURATION,// 4
                MediaStore.Audio.AudioColumns.DATA,// 5
                MediaStore.Audio.AudioColumns.DATE_MODIFIED,// 6
                MediaStore.Audio.AudioColumns.ALBUM_ID,// 7
                MediaStore.Audio.AudioColumns.ALBUM,// 8
                MediaStore.Audio.AudioColumns.ARTIST_ID,// 9
                MediaStore.Audio.AudioColumns.ARTIST,// 10
        };


        if (selection != null && !selection.trim().equals("")) {
            selection = addMinDurationFilter(BASE_SELECTION) + " AND " + selection;
        } else {
            selection = addMinDurationFilter(BASE_SELECTION);
        }


        ArrayList<String> paths = BlacklistStore.getInstance(RingtoneActivty.this).getPaths();
        if (!paths.isEmpty()) {
            selection = generateBlacklistSelection(selection, paths.size());
            selectionValues = addBlacklistSelectionValues(selectionValues, paths);


            StringBuilder values = new StringBuilder();
            for (String value :
                    selectionValues) {
                values.append("[").append(value).append("], ");
            }

        }


        String sortOrder2 = MediaStore.MediaColumns.DISPLAY_NAME + "";
        cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                BASE_PROJECTION, selection, selectionValues, sortOrder2);


        if (cursor != null && cursor.moveToFirst()) {
            do {


                final int id = cursor.getInt(0);
                final String name = cursor.getString(1);
                final int trackNumber = cursor.getInt(2);
                final int year = cursor.getInt(3);
                final long duration = cursor.getLong(4);
                final String path = cursor.getString(5);
                final long dateModified = cursor.getLong(6);
                final int albumId = cursor.getInt(7);
                final String albumName = cursor.getString(8);
                final int artistId = cursor.getInt(9);
                final String art2 = cursor.getString(10);


                albumInfo s = new albumInfo(name, duration, path, id);


                albumSongList.add(s);

            } while (cursor.moveToNext());
        }

        sort = 0;
        setdataRecy();


    }

    private void setdataRecy() {
        if (albumSongList.size() > 0) {


            Collections.sort(albumSongList, new Comparator<albumInfo>() {
                @Override
                public int compare(albumInfo lhs, albumInfo rhs) {

                    File file1 = new File(lhs.getPath());
                    File file2 = new File(rhs.getPath());

                    return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                }
            });


            adapter = new RingtoneAdapter(RingtoneActivty.this, albumSongList, new FilePAthdata2ex() {
                @Override
                public void fitdat(ArrayList<File> pathDAta, MediaPlayer mediaPlayer2 , ImageView img) {
                    pathDAta2 = pathDAta;



                }

                @Override
                public void fitdat2(ArrayList<File> pathDAta, MediaPlayer mediaPlayer2 , ImageView img) {
                    mediaPlayer= mediaPlayer2;
                    img2=img;

                }
            }, getIntent().getStringExtra("type"),noVideoLayout);

            recyclerView.setAdapter(adapter);


        } else {

            noVideoLayout.setVisibility(View.VISIBLE);
        }

    }


    private static String generateBlacklistSelection(String selection, int pathCount) {
        StringBuilder newSelection = new StringBuilder(selection != null && !selection.trim().equals("") ? selection + " AND " : "");
        newSelection.append(MediaStore.Audio.AudioColumns.DATA + " NOT LIKE ?");
        for (int i = 0; i < pathCount - 1; i++) {
            newSelection.append(" AND " + MediaStore.Audio.AudioColumns.DATA + " NOT LIKE ?");
        }
        return newSelection.toString();
    }


    private static String addMinDurationFilter(String selection) {
        return selection + " AND " + MediaStore.Audio.AudioColumns.DURATION + " > "
                + VideotoaudoApplication.getVideotoaudoApplication().getPreferencesUtility().getMinDuration();
    }

    private static String[] addBlacklistSelectionValues(String[] selectionValues, ArrayList<String> paths) {
        if (selectionValues == null) selectionValues = new String[0];
        String[] newSelectionValues = new String[selectionValues.length + paths.size()];
        System.arraycopy(selectionValues, 0, newSelectionValues, 0, selectionValues.length);
        for (int i = selectionValues.length; i < newSelectionValues.length; i++) {
            newSelectionValues[i] = paths.get(i - selectionValues.length) + "%";
        }
        return newSelectionValues;
    }
}