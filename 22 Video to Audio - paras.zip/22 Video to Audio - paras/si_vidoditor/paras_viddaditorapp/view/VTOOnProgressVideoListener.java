package com.si_vidoditor.paras_viddaditorapp.view;

public interface VTOOnProgressVideoListener {
    void updateProgress(int i, int i2, float f);
}
