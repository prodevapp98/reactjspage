package com.si_vidoditor.paras_viddaditorapp.view;


public interface VTOOnRangeSeekBarListener {
    void onCreate(VTORangeSeekBarView rangeSeekBarView, int i, float f);

    void onSeek(VTORangeSeekBarView rangeSeekBarView, int i, float f);

    void onSeekStart(VTORangeSeekBarView rangeSeekBarView, int i, float f);

    void onSeekStop(VTORangeSeekBarView rangeSeekBarView, int i, float f);
}
