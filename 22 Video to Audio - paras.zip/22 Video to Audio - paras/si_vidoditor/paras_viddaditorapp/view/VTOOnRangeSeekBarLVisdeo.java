package com.si_vidoditor.paras_viddaditorapp.view;


public interface VTOOnRangeSeekBarLVisdeo {
    void onCreate(VTORangeSeekViseo rangeSeekBarView, int i, float f);

    void onSeek(VTORangeSeekViseo rangeSeekBarView, int i, float f);

    void onSeekStart(VTORangeSeekViseo rangeSeekBarView, int i, float f);

    void onSeekStop(VTORangeSeekViseo rangeSeekBarView, int i, float f);
}
