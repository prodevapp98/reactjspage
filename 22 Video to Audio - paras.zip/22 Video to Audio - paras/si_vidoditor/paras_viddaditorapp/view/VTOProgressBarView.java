package com.si_vidoditor.paras_viddaditorapp.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.videocutter.OnDataProVideoListner;


public class VTOProgressBarView extends View implements
        VTOOnRangeSeekBarListener, VTOOnProgressVideoListener,
        OnDataProVideoListner {
    private final Paint mBackgroundColor;
    private Rect mBackgroundRect;
    private final Paint mProgressColor;
    private int mProgressHeight;
    private Rect mProgressRect;
    private int mViewWidth;

    public VTOProgressBarView(@NonNull Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VTOProgressBarView(@NonNull Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mBackgroundColor = new Paint();
        this.mProgressColor = new Paint();
        init();
    }

    private void init() {
        int color = ContextCompat.getColor(getContext(), R.color.line_color);
        int color2 = ContextCompat.getColor(getContext(), R.color.line_color);
        this.mProgressHeight = getContext().getResources().getDimensionPixelOffset(R.dimen.progress_video_line_height);
        this.mBackgroundColor.setAntiAlias(true);
        this.mBackgroundColor.setColor(color2);
        this.mProgressColor.setAntiAlias(true);
        this.mProgressColor.setColor(color);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int paddingLeft = getPaddingLeft() + getPaddingRight() + getSuggestedMinimumWidth();
        if (Build.VERSION.SDK_INT >= 11) {
            this.mViewWidth = resolveSizeAndState(paddingLeft, i, 1);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop() + this.mProgressHeight;
        int i3 = 0;
        if (Build.VERSION.SDK_INT >= 11) {
            i3 = resolveSizeAndState(paddingBottom, i2, 1);
        }
        setMeasuredDimension(this.mViewWidth, i3);
    }

    public void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        drawLineBackground(canvas);
        drawLineProgress(canvas);
    }

    private void drawLineBackground(@NonNull Canvas canvas) {
        if (this.mBackgroundRect != null) {
            canvas.drawRect(this.mBackgroundRect, this.mBackgroundColor);
        }
    }

    private void drawLineProgress(@NonNull Canvas canvas) {
        if (this.mProgressRect != null) {
            canvas.drawRect(this.mProgressRect, this.mProgressColor);
        }
    }

    @Override
    public void onCreate(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        updateBackgroundRect(i, f);
    }

    @Override
    public void onSeek(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        updateBackgroundRect(i, f);
    }

    @Override
    public void onSeekStart(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        updateBackgroundRect(i, f);
    }

    @Override
    public void onSeekStop(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        updateBackgroundRect(i, f);
    }

    private void updateBackgroundRect(int i, float f) {
        if (this.mBackgroundRect == null) {
            this.mBackgroundRect = new Rect(0, 0, this.mViewWidth, this.mProgressHeight);
        }
        int i2 = (int) ((((float) this.mViewWidth) * f) / 100.0f);
        if (i == 0) {
            this.mBackgroundRect = new Rect(i2, this.mBackgroundRect.top, this.mBackgroundRect.right, this.mBackgroundRect.bottom);
        } else {
            this.mBackgroundRect = new Rect(this.mBackgroundRect.left, this.mBackgroundRect.top, i2, this.mBackgroundRect.bottom);
        }
        updateProgress(0, 0, 0.0f);
    }

    @Override
    public void updateProgress(int i, int i2, float f) {
        if (f == 0.0f) {
            this.mProgressRect = new Rect(0, this.mBackgroundRect.top, 0, this.mBackgroundRect.bottom);
        } else {
            this.mProgressRect = new Rect(this.mBackgroundRect.left, this.mBackgroundRect.top, (int) ((((float) this.mViewWidth) * f) / 100.0f), this.mBackgroundRect.bottom);
        }
        invalidate();
    }
}
