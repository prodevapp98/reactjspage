package com.si_vidoditor.paras_viddaditorapp.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.si_vidoditor.paras_viddaditorapp.R;

import java.util.ArrayList;
import java.util.List;

public class VTORangeSeekBarView extends View {
    private static final String TAG = "TAG";
    private int currentThumb;
    private boolean mFirstRun;
    private int mHeightTimeLine;
    private final Paint mLine;
    private List<VTOOnRangeSeekBarListener> mListeners;
    private float mMaxWidth;
    private float mPixelRangeMax;
    private float mPixelRangeMin;
    private float mScaleRangeMax;
    private final Paint mShadow;
    private float mThumbHeight;
    private float mThumbWidth;
    private List<VTOThumb> mThumbs;
    private int mViewWidth;

    public void plussk1() {


        currentThumb=0;
        VTOThumb thumb2 = this.mThumbs.get(this.currentThumb);
        VTOThumb thumb3 = this.mThumbs.get(this.currentThumb == 0 ? 1 : 0);

        float lastTouchX = 2.0F;
        float pos = thumb2.getPos() + lastTouchX;

        if (((float) thumb2.getWidthBitmap()) + pos >= thumb3.getPos()) {

            thumb2.setPos(thumb3.getPos() - ((float) thumb2.getWidthBitmap()));


        } else if (pos <= this.mPixelRangeMin) {

            thumb2.setPos(this.mPixelRangeMin);

        } else {

            checkPositionThumb(thumb2, thumb3, lastTouchX, true);
            thumb2.setPos(thumb2.getPos() + lastTouchX);
            setThumbPos(this.currentThumb, thumb2.getPos());
            invalidate();

        }


    }

    public void minussk1() {


        currentThumb=0;
        VTOThumb thumb2 = this.mThumbs.get(this.currentThumb);
        VTOThumb thumb3 = this.mThumbs.get(this.currentThumb == 0 ? 1 : 0);

        float lastTouchX = -2.0F;
        float pos = thumb2.getPos() + lastTouchX;

        if (((float) thumb2.getWidthBitmap()) + pos >= thumb3.getPos()) {

            thumb2.setPos(thumb3.getPos() - ((float) thumb2.getWidthBitmap()));


        } else if (pos <= this.mPixelRangeMin) {

            thumb2.setPos(this.mPixelRangeMin);

        } else {

            checkPositionThumb(thumb2, thumb3, lastTouchX, true);
            thumb2.setPos(thumb2.getPos() + lastTouchX);
            setThumbPos(this.currentThumb, thumb2.getPos());
            invalidate();

        }


    }




   public void minussk2() {


        currentThumb=1;
        VTOThumb thumb2 = this.mThumbs.get(this.currentThumb);
        VTOThumb thumb3 = this.mThumbs.get(this.currentThumb == 0 ? 1 : 0);

        float lastTouchX = -2.0F;
        float pos = thumb2.getPos() + lastTouchX;




       checkPositionThumb(thumb3, thumb2, lastTouchX, false);
       thumb2.setPos(thumb2.getPos() + lastTouchX);
       setThumbPos(this.currentThumb, thumb2.getPos());
       invalidate();

    }



     public void plussk2() {


        currentThumb=1;
        VTOThumb thumb2 = this.mThumbs.get(this.currentThumb);
        VTOThumb thumb3 = this.mThumbs.get(this.currentThumb == 0 ? 1 : 0);

        float lastTouchX = 2.0F;
        float pos = thumb2.getPos() + lastTouchX;




       checkPositionThumb(thumb3, thumb2, lastTouchX, false);
       thumb2.setPos(thumb2.getPos() + lastTouchX);
       setThumbPos(this.currentThumb, thumb2.getPos());
       invalidate();

    }






    public VTORangeSeekBarView(@NonNull Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VTORangeSeekBarView(@NonNull Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        mShadow = new Paint();
        mLine = new Paint();
        currentThumb = 0;
        init();
    }

    private void init() {
        mThumbs = VTOThumb.initThumbs(getResources());
        mThumbWidth = (float) VTOThumb.getWidthBitmap(this.mThumbs);
        mThumbHeight = (float) VTOThumb.getHeightBitmap(this.mThumbs);
        mScaleRangeMax = 100.0f;
        mHeightTimeLine = getContext().getResources().getDimensionPixelOffset(R.dimen.frames_video_height);
        setFocusable(true);
        setFocusableInTouchMode(true);
        this.mFirstRun = true;
        int color = ContextCompat.getColor(getContext(), R.color.cl_1t);
        mShadow.setAntiAlias(true);
        mShadow.setColor(color);
        ;
        int color2 = ContextCompat.getColor(getContext(), R.color.red);
        mLine.setAntiAlias(true);
        mLine.setColor(color2);
    }

    public void initMaxWidth() {
        this.mMaxWidth = this.mThumbs.get(1).getPos() - this.mThumbs.get(0).getPos();
        onSeekStop(this, 0, this.mThumbs.get(0).getVal());
        onSeekStop(this, 1, this.mThumbs.get(1).getVal());
    }


    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.mViewWidth = resolveSizeAndState(getPaddingLeft() + getPaddingRight() + getSuggestedMinimumWidth(), i, 1);
        setMeasuredDimension(this.mViewWidth, resolveSizeAndState(getPaddingBottom() + getPaddingTop() + ((int) this.mThumbHeight) + this.mHeightTimeLine, i2, 1));
        this.mPixelRangeMin = 0.0f;
        this.mPixelRangeMax = ((float) this.mViewWidth) - this.mThumbWidth;
        if (this.mFirstRun) {
            for (int i3 = 0; i3 < this.mThumbs.size(); i3++) {
                VTOThumb thumb = this.mThumbs.get(i3);
                float f = (float) i3;
                thumb.setVal(this.mScaleRangeMax * f);
                thumb.setPos(this.mPixelRangeMax * f);
            }
            onCreate(this, this.currentThumb, getThumbValue(this.currentThumb));
            this.mFirstRun = false;
        }
    }

    public void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        drawShadow(canvas);
        drawThumbs(canvas);
    }

    public boolean onTouchEvent(@NonNull MotionEvent motionEvent) {

        float x = motionEvent.getX();
        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                this.currentThumb = getClosestThumb(x);
                if (this.currentThumb == -1) {
                    return false;
                }
                VTOThumb thumb = this.mThumbs.get(this.currentThumb);
                thumb.setLastTouchX(x);
                onSeekStart(this, this.currentThumb, thumb.getVal());
                return true;
            case MotionEvent.ACTION_UP:
                if (this.currentThumb == -1) {
                    return false;
                }
                onSeekStop(this, this.currentThumb, this.mThumbs.get(this.currentThumb).getVal());
                return true;
            case MotionEvent.ACTION_MOVE:


                VTOThumb thumb2 = this.mThumbs.get(this.currentThumb);
                VTOThumb thumb3 = this.mThumbs.get(this.currentThumb == 0 ? 1 : 0);


                float lastTouchX = x - thumb2.getLastTouchX();
                float pos = thumb2.getPos() + lastTouchX;





                if (this.currentThumb == 0) {


                    if (((float) thumb2.getWidthBitmap()) + pos >= thumb3.getPos()) {

                        thumb2.setPos(thumb3.getPos() - ((float) thumb2.getWidthBitmap()));


                    } else if (pos <= this.mPixelRangeMin) {

                        thumb2.setPos(this.mPixelRangeMin);

                    } else {

                        checkPositionThumb(thumb2, thumb3, lastTouchX, true);
                        thumb2.setPos(thumb2.getPos() + lastTouchX);
                        thumb2.setLastTouchX(x);

                    }


                } else if (pos <= thumb3.getPos() + ((float) thumb3.getWidthBitmap())) {




                    thumb2.setPos(thumb3.getPos() + ((float) thumb2.getWidthBitmap()));
                } else if (pos >= this.mPixelRangeMax) {



                    thumb2.setPos(this.mPixelRangeMax);
                } else {




                    checkPositionThumb(thumb3, thumb2, lastTouchX, false);
                    thumb2.setPos(thumb2.getPos() + lastTouchX);
                    thumb2.setLastTouchX(x);


                }
                setThumbPos(this.currentThumb, thumb2.getPos());
                invalidate();
                return true;
            default:
                return false;
        }
    }

    private void checkPositionThumb(@NonNull VTOThumb thumb, @NonNull VTOThumb thumb2, float f, boolean z) {
        if (!z || f >= 0.0f) {
            if (!z && f > 0.0f && (thumb2.getPos() + f) - thumb.getPos() > this.mMaxWidth) {
                thumb.setPos((thumb2.getPos() + f) - this.mMaxWidth);
                setThumbPos(0, thumb.getPos());
            }
        } else if (thumb2.getPos() - (thumb.getPos() + f) > this.mMaxWidth) {
            thumb2.setPos(thumb.getPos() + f + this.mMaxWidth);
            setThumbPos(1, thumb2.getPos());
        }
    }

    private int getUnstuckFrom(int i) {
        float val = this.mThumbs.get(i).getVal();
        for (int i2 = i - 1; i2 >= 0; i2--) {
            if (this.mThumbs.get(i2).getVal() != val) {
                return i2 + 1;
            }
        }
        return 0;
    }

    private float pixelToScale(int i, float f) {
        float f2 = (f * 100.0f) / this.mPixelRangeMax;
        if (i == 0) {
            return f2 + ((((this.mThumbWidth * f2) / 100.0f) * 100.0f) / this.mPixelRangeMax);
        }
        return f2 - (((((100.0f - f2) * this.mThumbWidth) / 100.0f) * 100.0f) / this.mPixelRangeMax);
    }

    private float scaleToPixel(int i, float f) {
        float f2 = (this.mPixelRangeMax * f) / 100.0f;
        if (i == 0) {
            return f2 - ((f * this.mThumbWidth) / 100.0f);
        }
        return f2 + (((100.0f - f) * this.mThumbWidth) / 100.0f);
    }

    private void calculateThumbValue(int i) {
        if (i < this.mThumbs.size() && !this.mThumbs.isEmpty()) {
            VTOThumb thumb = this.mThumbs.get(i);
            thumb.setVal(pixelToScale(i, thumb.getPos()));
            onSeek(this, i, thumb.getVal());
        }
    }

    private void calculateThumbPos(int i) {
        if (i < this.mThumbs.size() && !this.mThumbs.isEmpty()) {
            VTOThumb thumb = this.mThumbs.get(i);
            thumb.setPos(scaleToPixel(i, thumb.getVal()));
        }
    }

    private float getThumbValue(int i) {
        return this.mThumbs.get(i).getVal();
    }

    public void setThumbValue(int i, float f) {
        this.mThumbs.get(i).setVal(f);
        calculateThumbPos(i);
        invalidate();
    }

    private void setThumbPos(int i, float f) {
        this.mThumbs.get(i).setPos(f);
        calculateThumbValue(i);
        invalidate();
    }

    private int getClosestThumb(float f) {
        int i = -1;
        if (!this.mThumbs.isEmpty()) {
            for (int i2 = 0; i2 < this.mThumbs.size(); i2++) {
                float pos = this.mThumbs.get(i2).getPos() + this.mThumbWidth;
                if (f >= this.mThumbs.get(i2).getPos() && f <= pos) {
                    i = this.mThumbs.get(i2).getIndex();
                }
            }
        }
        return i;
    }

    private void drawShadow(@NonNull Canvas canvas) {
        if (!this.mThumbs.isEmpty()) {
            for (VTOThumb thumb : this.mThumbs) {
                if (thumb.getIndex() == 0) {
                    float pos = thumb.getPos() + ((float) getPaddingLeft());
                    if (pos > this.mPixelRangeMin) {
                        canvas.drawRect(new Rect((int) this.mThumbWidth, 0, (int) (pos + this.mThumbWidth), this.mHeightTimeLine), this.mShadow);
                    }
                } else {
                    float pos2 = thumb.getPos() - ((float) getPaddingRight());
                    if (pos2 < this.mPixelRangeMax) {
                        canvas.drawRect(new Rect((int) pos2, 0, (int) (((float) this.mViewWidth) - this.mThumbWidth), this.mHeightTimeLine), this.mShadow);
                    }
                }
            }
        }
    }

    private void drawThumbs(@NonNull Canvas canvas) {
        if (!this.mThumbs.isEmpty()) {
            for (VTOThumb thumb : this.mThumbs) {
                if (thumb.getIndex() == 0) {
                    canvas.drawBitmap(thumb.getBitmap(),
                            thumb.getPos() + ((float) getPaddingLeft()),
                            (float) (getPaddingTop()), (Paint) null);
                } else {
                    canvas.drawBitmap(thumb.getBitmap(),
                            thumb.getPos() - ((float) getPaddingRight()),
                            (float) (getPaddingTop()), (Paint) null);
                }
            }
        }
    }

    public void addOnRangeSeekBarListener(VTOOnRangeSeekBarListener onRangeSeekBarListener) {
        if (this.mListeners == null) {
            this.mListeners = new ArrayList();
        }
        this.mListeners.add(onRangeSeekBarListener);
    }

    private void onCreate(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        if (this.mListeners != null) {
            for (VTOOnRangeSeekBarListener onRangeSeekBarListener : this.mListeners) {
                onRangeSeekBarListener.onCreate(rangeSeekBarView, i, f);
            }
        }
    }

    private void onSeek(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        if (this.mListeners != null) {
            for (VTOOnRangeSeekBarListener onRangeSeekBarListener : this.mListeners) {
                onRangeSeekBarListener.onSeek(rangeSeekBarView, i, f);
            }
        }
    }

    private void onSeekStart(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        if (this.mListeners != null) {
            for (VTOOnRangeSeekBarListener onRangeSeekBarListener : this.mListeners) {
                onRangeSeekBarListener.onSeekStart(rangeSeekBarView, i, f);
            }
        }
    }

    private void onSeekStop(VTORangeSeekBarView rangeSeekBarView, int i, float f) {
        if (this.mListeners != null) {
            for (VTOOnRangeSeekBarListener onRangeSeekBarListener : this.mListeners) {
                onRangeSeekBarListener.onSeekStop(rangeSeekBarView, i, f);
            }
        }
    }

    public List<VTOThumb> getThumbs() {
        return this.mThumbs;
    }


}
