package com.si_vidoditor.paras_viddaditorapp.outputfolder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.BaseLayoutVidoEditor;

public class UotPutAllActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private MyAdapter adapter;
    private ImageView iv_sort;
    int sort = -1;

    public void changeColor(int resourseColor) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uot_put_all);


        ImageView imageView = findViewById(R.id.imageView);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.iv_vipage);
        iv_sort = findViewById(R.id.iv_sort);


        changeColor(R.color.home_top7s);

        BaseLayoutVidoEditor.showBannerOnce(this, findViewById(R.id.framSmall), findViewById(R.id.rlBanner));

        adapter = new MyAdapter(UotPutAllActivity.this, getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(7);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager));


        iv_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupWindow pwindow = new PopupWindow(UotPutAllActivity.this);
                pwindow.setBackgroundDrawable(new BitmapDrawable());
                View inflate = getLayoutInflater().inflate(R.layout.sortpopup7, (ViewGroup) null);


                pwindow.setContentView(inflate);
                pwindow.setFocusable(true);
                pwindow.setWindowLayoutMode(-2, -2);
                pwindow.setOutsideTouchable(true);
                pwindow.showAsDropDown(iv_sort, 0, 20);


                TextView tv_asending = inflate.findViewById(R.id.tv_list);
                TextView tv_dessendin = inflate.findViewById(R.id.tv_grid);
                TextView tv_date = inflate.findViewById(R.id.tv_date);


                TextView tv_filco = inflate.findViewById(R.id.tv_filco);


                ImageView circleImageView = inflate.findViewById(R.id.circleImageView);
                ImageView circleImageView2 = inflate.findViewById(R.id.circleImageView2);
                ImageView circleImageView3 = inflate.findViewById(R.id.circleImageView3);
                ImageView circleImageView4 = inflate.findViewById(R.id.circleImageView4);


                if (sort == 0) {
                    circleImageView.setVisibility(View.VISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 1) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.VISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 2) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.VISIBLE);
                    circleImageView4.setVisibility(View.INVISIBLE);

                } else if (sort == 3) {

                    circleImageView.setVisibility(View.INVISIBLE);
                    circleImageView2.setVisibility(View.INVISIBLE);
                    circleImageView3.setVisibility(View.INVISIBLE);
                    circleImageView4.setVisibility(View.VISIBLE);

                }

                tv_asending.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        sort = 0;
                        pwindow.dismiss();


                        Intent intent = new Intent();
                        intent.setAction("main_service_api");
                        intent.putExtra("CONTROL_SERVICE", "Ascending");
                        sendBroadcast(intent);


                    }
                });


                tv_dessendin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        pwindow.dismiss();
                        sort = 1;

                        Intent intent = new Intent();
                        intent.setAction("main_service_api");
                        intent.putExtra("CONTROL_SERVICE", "Descending");
                        sendBroadcast(intent);

                    }
                });

                tv_date.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        pwindow.dismiss();
                        sort = 2;

                        Intent intent = new Intent();
                        intent.setAction("main_service_api");
                        intent.putExtra("CONTROL_SERVICE", "Date");
                        sendBroadcast(intent);


                    }
                });

                tv_filco.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        pwindow.dismiss();
                        sort = 3;

                        Intent intent = new Intent();
                        intent.setAction("main_service_api");
                        intent.putExtra("CONTROL_SERVICE", "Duration");
                        sendBroadcast(intent);


                    }
                });


            }
        });


    }
}