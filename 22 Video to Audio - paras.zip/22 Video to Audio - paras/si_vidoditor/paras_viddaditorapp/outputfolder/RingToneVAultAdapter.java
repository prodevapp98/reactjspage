package com.si_vidoditor.paras_viddaditorapp.outputfolder;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;

import android.net.Uri;
import android.os.Build;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;
import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideoCallbackNextManager;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import com.si_vidoditor.paras_viddaditorapp.audiocutter.AudioTrimmerActivity;
import com.si_vidoditor.paras_viddaditorapp.formateconverter.AudioMustiplaActivity;
import com.si_vidoditor.paras_viddaditorapp.formateconverter.VideoMultiPleActivity;

import com.si_vidoditor.paras_viddaditorapp.videocutter.CutterActivity;
import com.si_vidoditor.paras_viddaditorapp.videocutter.CutterVideo2;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.filedatarecy;

import java.io.File;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class RingToneVAultAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Activity fragment;

    private static final String PRIMARY_VOLUME_NAME = "primary";
    public List<File> filtered_videoList = new ArrayList();
    private com.si_vidoditor.paras_viddaditorapp.videotoaudio.filedatarecy filedatarecy;
    public List<File> dup_items;

    private String type;
    private String cachedMimeType = null;
    private TinyDB tinyDB;




    public class OriginalViewHolder extends RecyclerView.ViewHolder {

        public ImageView image, image2;
        public TextView name;
        public TextView duration;

        public ConstraintLayout mainViewclick;

        private CardView cl_vide;

        private ImageView iv_menu;


        public OriginalViewHolder(View view) {
            super(view);

            image = (ImageView) view.findViewById(R.id.thmImg);
            image2 = (ImageView) view.findViewById(R.id.thmImg2);

            name = (TextView) view.findViewById(R.id.name);
            duration = (TextView) view.findViewById(R.id.duration);
            mainViewclick = (ConstraintLayout) view.findViewById(R.id.card);
            cl_vide = view.findViewById(R.id.cl_vide);
            iv_menu = view.findViewById(R.id.iv_menu);


        }
    }


    public RingToneVAultAdapter(Activity fragment2, List<File> list, filedatarecy filedatarecy, String type1, TinyDB tinyDB) {
        filtered_videoList = list;
        fragment = fragment2;
        this.dup_items = list;
        this.filedatarecy = filedatarecy;
        this.type = type1;
        this.tinyDB = tinyDB;


    }

    private String mimeTypeV1(File file) {
        try {
            return URLConnection.guessContentTypeFromName(file.getAbsolutePath());
        } catch (Exception e) {
            return null;
        }
    }

    private String mimeTypeV2(File file) {
        try {
            String extension = MimeTypeMap.getFileExtensionFromUrl(file.getAbsolutePath());

            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        } catch (Exception e) {
            return null;
        }
    }

    public String mimeType(File file) {
        if (cachedMimeType == null) {
            cachedMimeType = mimeTypeV1(file);

            if (cachedMimeType == null) {
                cachedMimeType = mimeTypeV2(file);

                if (cachedMimeType == null) {
                    cachedMimeType = "*/*";
                }
            }
        }

        return cachedMimeType;
    }


    public static Long getImageContentUri(Context context, File imageFile) {
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Files.getContentUri("external");
        }


        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = VideotoaudoApplication.getAppContext().getContentResolver().query(
                collection,
                new String[]{MediaStore.Files.FileColumns.DURATION},
                MediaStore.Files.FileColumns.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") Long id = cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.DURATION));
            cursor.close();
            return id;
        } else {


            return null;

        }


    }

    public static Uri getImageContentUri2(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = VideotoaudoApplication.getAppContext().getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID},
                MediaStore.Audio.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));


            cursor.close();
            return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {


            return null;

        }


    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new OriginalViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.tt_item_folder2, viewGroup, false));
    }

    @SuppressLint({"StaticFieldLeak", "ClickableViewAccessibility"})
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        if (viewHolder instanceof OriginalViewHolder) {
            final OriginalViewHolder originalViewHolder = (OriginalViewHolder) viewHolder;
            final File file = this.filtered_videoList.get(i);


            MediaScannerConnection.scanFile(fragment,
                    new String[]{file.getAbsolutePath()}, null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {

                        }
                    });


            originalViewHolder.name.setText(file.getName());

            SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yyyy  hh:mm:ss a");
            Date lastModDate = new Date(file.lastModified());
            String ThiedTime = currentDate.format(lastModDate);
            originalViewHolder.duration.setText(ThiedTime);





            if (type.equals("video")) {
                originalViewHolder.cl_vide.setVisibility(View.VISIBLE);
                Glide.with(fragment).load(file.getAbsoluteFile()).into(originalViewHolder.image2);

            } else if (type.equals("all")) {


                if (file.getName().endsWith(".mp4")
                        || file.getName().endsWith(".3gp")
                        || file.getName().endsWith(".mov")
                        || file.getName().endsWith(".flv")
                        || file.getName().endsWith(".mkv")
                        || file.getName().endsWith(".avi")
                        || file.getName().endsWith(".m4u")


                ) {


                    originalViewHolder.cl_vide.setVisibility(View.VISIBLE);
                    Glide.with(fragment).load(file.getAbsoluteFile()).
                            placeholder(R.drawable.output_folder).into(originalViewHolder.image2);


                } else {
                    originalViewHolder.cl_vide.setVisibility(View.GONE);
                    Glide.with(fragment).load(file.getAbsoluteFile()).
                            placeholder(R.drawable.output_folder).into(originalViewHolder.image);


                }


            } else {
                originalViewHolder.cl_vide.setVisibility(View.GONE);


                final Uri uri = getImageContentUri2(fragment, file);
                Glide.with(fragment).load(uri).placeholder(R.drawable.output_folder).into(originalViewHolder.image);


            }


            originalViewHolder.iv_menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    final Dialog pwindow = new Dialog(fragment);
                    pwindow.setContentView(R.layout.menu_option);
                    Window window2 = pwindow.getWindow();
                    WindowManager.LayoutParams wlp1 = window2.getAttributes();
                    window2.setAttributes(wlp1);
                    pwindow.setCancelable(true);
                    window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    pwindow.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    pwindow.show();

                    Long duration = getImageContentUri(fragment, file);
                    if (duration != null) {
                        String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(duration)),
                                        Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1)),
                                        Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1))});


                        if (str.equals("00:00:00")) {
                            Toast.makeText(fragment, "File not converted properly!", Toast.LENGTH_SHORT).show();
                          return;


                        }
                    }

                    filedatarecy.recycle(i);








                    TextView tv_vtu = pwindow.findViewById(R.id.tv_vtu);
                    TextView tv_fmt = pwindow.findViewById(R.id.tv_fmt);
                    TextView tv_cut = pwindow.findViewById(R.id.tv_cut);
                    TextView tv_opn = pwindow.findViewById(R.id.tv_opn);
                    TextView tv_share = pwindow.findViewById(R.id.tv_share);
                    TextView tv_rnm = pwindow.findViewById(R.id.tv_rnm);
                    TextView tv_info = pwindow.findViewById(R.id.tv_info);
                    TextView tv_delete = pwindow.findViewById(R.id.tv_delete);


                    if (file.getName().endsWith(".mp4")
                            || file.getName().endsWith(".3gp")
                            || file.getName().endsWith(".mov")
                            || file.getName().endsWith(".flv")
                            || file.getName().endsWith(".mkv")
                            || file.getName().endsWith(".avi")
                            || file.getName().endsWith(".m4u")


                    ) {
                        tv_vtu.setVisibility(View.VISIBLE);

                    } else {
                        tv_vtu.setVisibility(View.GONE);

                    }


                    tv_vtu.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            pwindow.dismiss();

                            VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(fragment, msg -> {
                                Intent intent = new Intent(fragment, CutterActivity.class);
                                intent.putExtra("EXTRA_VIDEO_PATH", file.getAbsolutePath());
                                intent.putExtra("savb", 1);
                                intent.putExtra("avint", 1);
                                fragment.startActivity(intent);
                            });



                        }
                    });

                    tv_fmt.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            pwindow.dismiss();

                            if (file.getName().endsWith(".mp4")
                                    || file.getName().endsWith(".3gp")
                                    || file.getName().endsWith(".mov")
                                    || file.getName().endsWith(".flv")
                                    || file.getName().endsWith(".mkv")
                                    || file.getName().endsWith(".avi")
                                    || file.getName().endsWith(".m4u")


                            ) {
                                ArrayList<File> pathDAta = new ArrayList();
                                pathDAta.add(file);
                                tinyDB.putListObject("videoalldata", pathDAta);

                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(fragment, msg -> {
                                    fragment.startActivity(new Intent(fragment, VideoMultiPleActivity.class));
                                });



                            } else {

                                ArrayList<File> pathDAta2 = new ArrayList();
                                pathDAta2.add(file);
                                tinyDB.putListObject("audioalldata", pathDAta2);

                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(fragment, msg -> {
                                    fragment.startActivity(new Intent(fragment, AudioMustiplaActivity.class));
                                });



                            }


                        }
                    });
                    tv_cut.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            pwindow.dismiss();

                            if (file.getName().endsWith(".mp4")
                                    || file.getName().endsWith(".3gp")
                                    || file.getName().endsWith(".mov")
                                    || file.getName().endsWith(".flv")
                                    || file.getName().endsWith(".mkv")
                                    || file.getName().endsWith(".avi")
                                    || file.getName().endsWith(".m4u")


                            ) {


                                if (file.getName().endsWith(".mkv")
                                        || file.getName().endsWith(".flv"))
                                {

                                    Toast.makeText(fragment, "This file not convert properly", Toast.LENGTH_SHORT).show();


                                }
                                else {


                                    VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(fragment, msg -> {
                                        Intent intent = new Intent(fragment, CutterVideo2.class);
                                        intent.putExtra("EXTRA_VIDEO_PATH", file.getAbsolutePath());
                                        intent.putExtra("savb", 0);
                                        intent.putExtra("avint", 2);
                                        fragment.startActivity(intent);
                                    });

                                }



                            } else {


                                VideoCallbackNextManager.getVideoCallbackNext().openCallbackNextVideo(fragment, msg -> {
                                    fragment.startActivity(new Intent(fragment, AudioTrimmerActivity.class)
                                            .putExtra("path", file.getAbsolutePath()));
                                });



                            }


                        }
                    });


                    tv_opn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            pwindow.dismiss();

                            if (file.getName().endsWith(".mp4")
                                    || file.getName().endsWith(".3gp")
                                    || file.getName().endsWith(".mov")
                                    || file.getName().endsWith(".flv")
                                    || file.getName().endsWith(".mkv")
                                    || file.getName().endsWith(".avi")
                                    || file.getName().endsWith(".m4u")


                            ) {

                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setFlags(335544320);
                                if (Build.VERSION.SDK_INT >= 22) {
                                    intent.setDataAndType(FileProvider.getUriForFile(fragment, fragment.getPackageName()
                                            + ".provider", file), "video/*");
                                } else {
                                    intent.setDataAndType(Uri.fromFile(file), "video/*");
                                }
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                fragment.startActivityForResult(intent, 100);


                            } else {


                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setFlags(335544320);
                                if (Build.VERSION.SDK_INT >= 22) {
                                    intent.setDataAndType(FileProvider.getUriForFile(fragment, fragment.getPackageName()
                                            + ".provider", file), "audio/*");
                                } else {
                                    intent.setDataAndType(Uri.fromFile(file), "audio/*");
                                }
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                fragment.startActivityForResult(intent, 100);

                            }


                        }
                    });


                    tv_share.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {


                            if (file.getName().endsWith(".mp4")
                                    || file.getName().endsWith(".3gp")
                                    || file.getName().endsWith(".mov")
                                    || file.getName().endsWith(".flv")
                                    || file.getName().endsWith(".mkv")
                                    || file.getName().endsWith(".avi")
                                    || file.getName().endsWith(".m4u")


                            ) {

                                shareSingle(file, fragment, "video");
                            } else {
                                shareSingle(file, fragment, "audio");
                            }


                        }
                    });


                    tv_rnm.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            pwindow.dismiss();


                            final Dialog dialog = new Dialog(fragment);

                            dialog.setContentView(R.layout.movie_init_seeting_layout);
                            Window window2 = dialog.getWindow();
                            WindowManager.LayoutParams wlp1 = window2.getAttributes();
                            window2.setAttributes(wlp1);
                            dialog.setCancelable(true);


                            EditText editText = (EditText) dialog.findViewById(R.id.editText2);
                            TextView tvshow = (TextView) dialog.findViewById(R.id.tvshow);


                            dialog.findViewById(R.id.createMovie).setOnClickListener(new View.OnClickListener() {
                                public void onClick(View view) {
                                    if (editText.getText().toString().trim().length() > 0) {


                                        File oldfile = new File(file.getAbsolutePath());



                                        String extension = file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("."));


                                        File newfile = new File(oldfile.getParentFile().getAbsolutePath() + "/"
                                                + editText.getText().toString() + extension);



                                        oldfile.renameTo(newfile);


                                        filtered_videoList.set(i, newfile);
                                        notifyDataSetChanged();
                                        dialog.dismiss();


                                        Intent intent = new Intent();
                                        intent.setAction("main_service_api");
                                        intent.putExtra("CONTROL_SERVICE", "Rename");
                                        fragment.sendBroadcast(intent);



                                    } else {
                                        Toast.makeText(fragment, "Enter name", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                            dialog.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {

                                public final void onClick(View view) {
                                    dialog.dismiss();
                                }
                            });


                            window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialog.show();


                        }
                    });


                    tv_info.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            pwindow.dismiss();


                            final Dialog dialog = new Dialog(fragment);

                            dialog.setContentView(R.layout.tt_dialog_properties);
                            Window window2 = dialog.getWindow();
                            WindowManager.LayoutParams wlp1 = window2.getAttributes();
                            window2.setAttributes(wlp1);
                            dialog.setCancelable(true);

                            TextView name = dialog.findViewById(R.id.name);
                            TextView tv_locatio = dialog.findViewById(R.id.tv_locatio);
                            TextView fsize = dialog.findViewById(R.id.fsize);
                            TextView tv_date = dialog.findViewById(R.id.tv_date);
                            TextView tv_formate = dialog.findViewById(R.id.tv_formate);
                            TextView length = dialog.findViewById(R.id.length);
                            TextView resolution = dialog.findViewById(R.id.resolution);
                            TextView tv_resolution = dialog.findViewById(R.id.tv_resolution);


                            name.setText(file.getName().toString());

                            tv_locatio.setText("" + file.getAbsolutePath());


                            SpaceFormatter spaceFormatter = new SpaceFormatter();
                            String cachedSize = spaceFormatter.format(file.length());


                            fsize.setText("" + cachedSize);


                            SimpleDateFormat currentDate = new SimpleDateFormat("dd/MM/yyyy");
                            Date lastModDate = new Date(file.lastModified());
                            String ThiedTime = currentDate.format(lastModDate);
                            tv_date.setText(ThiedTime);

                            String extension = file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("."));


                            tv_formate.setText("" + extension);

                            MediaMetadataRetriever retriever = new MediaMetadataRetriever();

                            Uri uriOfFile = FileProvider.getUriForFile(fragment,
                                    fragment.getPackageName() + ".provider", file);

                            try {


                                retriever.setDataSource(fragment, uriOfFile);
                                long duration = Long.parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                                String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                        new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(duration)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1)),
                                                Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1))});






                                if (file.getName().endsWith(".mp4")
                                        || file.getName().endsWith(".3gp")
                                        || file.getName().endsWith(".mov")
                                        || file.getName().endsWith(".flv")
                                        || file.getName().endsWith(".mkv")
                                        || file.getName().endsWith(".avi")
                                        || file.getName().endsWith(".m4u")


                                ) {

                                    int width = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                                    int height = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));

                                    resolution.setText("" + width + "x" + height);

                                } else {
                                    resolution.setVisibility(View.GONE);
                                    tv_resolution.setVisibility(View.GONE);

                                }


                                retriever.release();


                                length.setText("" + str);
                            } catch (Exception e) {
                            }


                            TextView textok = dialog.findViewById(R.id.textok);


                            textok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    dialog.dismiss();


                                }
                            });


                            window2.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialog.show();


                        }
                    });

                    tv_delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            pwindow.dismiss();


                            final Dialog dialog = new Dialog(fragment);

                            dialog.setContentView(R.layout.delete_dialog);
                            Window window = dialog.getWindow();
                            WindowManager.LayoutParams wlp = window.getAttributes();
                            window.setAttributes(wlp);
                            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


                            ImageView btnOk = dialog.findViewById(R.id.btnOk);
                            ImageView btnCancel = dialog.findViewById(R.id.btnCancel);

                            btnOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    dialog.dismiss();



                                        if (file.exists()) {

                                            file.delete();
                                        }

                                        filtered_videoList.remove(i);
                                        notifyDataSetChanged();









                                    Intent intent = new Intent();
                                    intent.setAction("main_service_api");
                                    intent.putExtra("CONTROL_SERVICE", "Delete");
                                    fragment.sendBroadcast(intent);





                                }
                            });
                            btnCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    dialog.dismiss();


                                }
                            });

                            dialog.show();


                        }
                    });


                }
            });


            originalViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Long duration = getImageContentUri(fragment, file);
                    if (duration != null) {
                        String str = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                                new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(duration)),
                                        Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1)),
                                        Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1))});


                        if (str.equals("00:00:00")) {
                            Toast.makeText(fragment, "File not converted properly!", Toast.LENGTH_SHORT).show();
                            return;


                        }
                    }


                    if (file.getName().endsWith(".mp4")
                            || file.getName().endsWith(".3gp")
                            || file.getName().endsWith(".mov")
                            || file.getName().endsWith(".flv")
                            || file.getName().endsWith(".mkv")
                            || file.getName().endsWith(".avi")
                            || file.getName().endsWith(".m4u")


                    ) {




                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setFlags(335544320);
                        if (Build.VERSION.SDK_INT >= 22) {
                            intent.setDataAndType(FileProvider.getUriForFile(fragment, fragment.getPackageName()
                                    + ".provider", file), "video/*");
                        } else {
                            intent.setDataAndType(Uri.fromFile(file), "video/*");
                        }
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        fragment.startActivityForResult(intent, 100);


                    } else {


                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setFlags(335544320);
                        if (Build.VERSION.SDK_INT >= 22) {
                            intent.setDataAndType(FileProvider.getUriForFile(fragment, fragment.getPackageName()
                                    + ".provider", file), "audio/*");
                        } else {
                            intent.setDataAndType(Uri.fromFile(file), "audio/*");
                        }
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        fragment.startActivityForResult(intent, 100);

                    }
                }
            });

        }


    }

    private void startActivity(Intent intent, @StringRes int resid, Activity activity) {
        try {
            activity.startActivity(intent);
        } catch (Exception e) {

        }
    }

    private Intent shareSingleIntent(Uri uri, String type) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        return intent;
    }

    private boolean isResolvable(Intent intent, Activity activity) {
        PackageManager manager = activity.getPackageManager();
        List<ResolveInfo> resolveInfo = manager.queryIntentActivities(intent, 0);

        return !resolveInfo.isEmpty();
    }


    public Uri uri(Context context, File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                return FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", file);
            } catch (Exception e) {
                return Uri.fromFile(file);
            }
        } else {
            return Uri.fromFile(file);
        }
    }


    private void shareSingle(File fileInfo, Activity activity, String audio) {
        try {
            String type = audio + "/*";
            Intent intent = shareSingleIntent(uri(activity, fileInfo), type);

            if (isResolvable(intent, activity)) {
                startActivity(intent, R.string.shareFile_unable, activity);
            } else {
                Toast.makeText(activity, R.string.shareFile_unable, Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {

        }
    }


    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    public int getRealPathFromURI(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Audio.AudioColumns._ID};
            cursor = VideotoaudoApplication.getAppContext().getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns._ID);
            cursor.moveToFirst();
            return cursor.getInt(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }


    public Filter getFilter() {
        return new Filter() {
            public FilterResults performFiltering(CharSequence charSequence) {
                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    RingToneVAultAdapter videoAdapter = RingToneVAultAdapter.this;
                    List unused = videoAdapter.filtered_videoList = videoAdapter.dup_items;
                } else {
                    ArrayList arrayList = new ArrayList();
                    for (File videoItem : RingToneVAultAdapter.this.dup_items) {


                        File file = new File(videoItem.getName());
                        if (file.getName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(videoItem);
                        }
                    }
                    List unused2 = RingToneVAultAdapter.this.filtered_videoList = arrayList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = RingToneVAultAdapter.this.filtered_videoList;
                return filterResults;
            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                List unused = RingToneVAultAdapter.this.filtered_videoList = (List) filterResults.values;


                RingToneVAultAdapter.this.notifyDataSetChanged();
            }
        };
    }

    private static String getVolumePath(final String volumeId, Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP)
            return null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            return getVolumePathForAndroid11AndAbove(volumeId, context);
        else
            return getVolumePathBeforeAndroid11(volumeId, context);
    }
    private static String getVolumePathBeforeAndroid11(final String volumeId, Context context) {
        try {
            StorageManager mStorageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
            Class<?> storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
            Method getVolumeList = mStorageManager.getClass().getMethod("getVolumeList");
            Method getUuid = storageVolumeClazz.getMethod("getUuid");
            Method getPath = storageVolumeClazz.getMethod("getPath");
            Method isPrimary = storageVolumeClazz.getMethod("isPrimary");
            Object result = getVolumeList.invoke(mStorageManager);

            final int length = Array.getLength(result);
            for (int i = 0; i < length; i++) {
                Object storageVolumeElement = Array.get(result, i);
                String uuid = (String) getUuid.invoke(storageVolumeElement);
                Boolean primary = (Boolean) isPrimary.invoke(storageVolumeElement);

                if (primary && PRIMARY_VOLUME_NAME.equals(volumeId))    // primary volume?
                    return (String) getPath.invoke(storageVolumeElement);

                if (uuid != null && uuid.equals(volumeId))    // other volumes?
                    return (String) getPath.invoke(storageVolumeElement);
            }
            // not found.
            return null;
        } catch (Exception ex) {
            return null;
        }
    }
    @TargetApi(Build.VERSION_CODES.R)
    private static String getVolumePathForAndroid11AndAbove(final String volumeId, Context context) {
        try {
            StorageManager mStorageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
            List<StorageVolume> storageVolumes = mStorageManager.getStorageVolumes();
            for (StorageVolume storageVolume : storageVolumes) {
                // primary volume?
                if (storageVolume.isPrimary() && PRIMARY_VOLUME_NAME.equals(volumeId))
                    return storageVolume.getDirectory().getPath();

                // other volumes?
                String uuid = storageVolume.getUuid();
                if (uuid != null && uuid.equals(volumeId))
                    return storageVolume.getDirectory().getPath();

            }
            // not found.
            return null;
        } catch (Exception ex) {
            return null;
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private static String getVolumeIdFromTreeUri(final Uri treeUri) {
        final String docId = DocumentsContract.getTreeDocumentId(treeUri);
        final String[] split = docId.split(":");
        if (split.length > 0) return split[0];
        else return null;
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private static String getDocumentPathFromTreeUri(final Uri treeUri) {
        final String docId = DocumentsContract.getTreeDocumentId(treeUri);
        final String[] split = docId.split(":");
        if ((split.length >= 2) && (split[1] != null)) return split[1];
        else return File.separator;
    }


    @Nullable
    public static String getFullPathFromTreeUri(@Nullable final Uri treeUri, Context con) {

        if (treeUri == null) return null;
        String volumePath = getVolumePath(getVolumeIdFromTreeUri(treeUri), con);
        if (volumePath == null) return File.separator;
        if (volumePath.endsWith(File.separator))
            volumePath = volumePath.substring(0, volumePath.length() - 1);

        String documentPath = getDocumentPathFromTreeUri(treeUri);
        if (documentPath.endsWith(File.separator))
            documentPath = documentPath.substring(0, documentPath.length() - 1);

        if (documentPath.length() > 0) {
            if (documentPath.startsWith(File.separator))
                return volumePath + documentPath;
            else
                return volumePath + File.separator + documentPath;
        } else return volumePath;


    }

    @Override
    public int getItemCount() {
        return filtered_videoList.size();
    }
}
