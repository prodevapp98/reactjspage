package com.si_vidoditor.paras_viddaditorapp.outputfolder;

import android.annotation.SuppressLint;
import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;


public class MyAdapter extends FragmentPagerAdapter {
    private Context mContext;

    public ArrayList<Fragment> getData() {
        return mData;
    }

    private ArrayList<Fragment> mData = new ArrayList<>();

    private void initData() {

        mData.add(new AllFragmnet());
        mData.add(new VideoToaudio());
        mData.add(new VideoCutter());
        mData.add(new AudioCutter());
        mData.add(new AudioMerge());
        mData.add(new AudioFormatee());
        mData.add(new VideoFormate());


    }

    @SuppressLint("WrongConstant")
    public MyAdapter(Context context, FragmentManager fragmentManager) {
        super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mContext = context;
        initData();
    }


    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Fragment getItem(int position) {
        return mData.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "All Files";
            case 1:
                return "Video to Audio";
            case 2:
                return "Video Cutter";
            case 3:
                return "Audio Cutter";

            case 4:
                return "Audio Merger";

            case 5:
                return "Audio Format";

            case 6:
                return "Video Format";


            default:
                return null;
        }

    }
}

