package com.si_vidoditor.paras_viddaditorapp.outputfolder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.si_vidoditor.paras_viddaditorapp.R;
import com.si_vidoditor.paras_viddaditorapp.appclass.VideotoaudoApplication;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.TinyDB;
import com.si_vidoditor.paras_viddaditorapp.videotoaudio.filedatarecy;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class AudioFormatee extends androidx.fragment.app.Fragment {

    View view;
    public List<File> items = new ArrayList();

    private RecyclerView rv_conveter;

    private TextView noData;

private TinyDB tinyDB;
    private RingToneVAultAdapter mAdapter;

    private final ActivityResultLauncher<IntentSenderRequest> launcher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {


                    CreateDataSource();


                } else {


                }


            });
    public static Uri getImageContentUri2(Context context, File imageFile) {
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Files.getContentUri("external");
        }


        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                collection,
                new String[]{MediaStore.Files.FileColumns._ID},
                MediaStore.Files.FileColumns.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(collection, "" + id);
        } else {
//            if (imageFile.exists()) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                    ContentResolver resolver = context.getContentResolver();
//                    Uri picCollection = MediaStore.Images.Media
//                            .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
//                    ContentValues picDetail = new ContentValues();
//                    picDetail.put(MediaStore.Images.Media.DISPLAY_NAME, imageFile.getName());
//                    picDetail.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg");
//                    picDetail.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/" + UUID.randomUUID().toString());
//                    picDetail.put(MediaStore.Images.Media.IS_PENDING, 1);
//                    Uri finaluri = resolver.insert(picCollection, picDetail);
//                    picDetail.clear();
//                    picDetail.put(MediaStore.Images.Media.IS_PENDING, 0);
//                    resolver.update(picCollection, picDetail, null, null);
//                    return finaluri;
//                } else {
//                    ContentValues values = new ContentValues();
//                    values.put(MediaStore.Images.Media.DATA, filePath);
//                    return context.getContentResolver().insert(
//                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
//                }
//
//            } else {
            return null;
//            }
        }


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.input_data, container, false);
        rv_conveter = view.findViewById(R.id.rv_conveter);
        noData = view.findViewById(R.id.noData);

        CreateDataSource();
        tinyDB= new TinyDB(getContext());





     BradCatRecver bradCatRecver = new BradCatRecver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("main_service_api");
        VideotoaudoApplication.getAppContext().registerReceiver(bradCatRecver, intentFilter);



        return view;

    }


    public void CreateDataSource() {
        if (this.rv_conveter != null) {
            File file;
            this.items = new ArrayList();


            File file3 = new File(
                    VideotoaudoApplication.getAppContext().getExternalFilesDir("").getAbsolutePath()

                            + "/" + VideotoaudoApplication.getAppContext().getString(R.string.app_name),
                    "ChangeFormat");


            if (!file3.exists()) {
                file3.mkdir();

            }

            File[] listFiles = new File[0];

            listFiles = file3.listFiles();


            if (listFiles!= null) {

                for (File file2 : listFiles) {


                    this.items.add(file2);


                }
            }


            Collections.sort(items, new Comparator<File>() {
                public int compare(File file, File file2) {
                    long lastModified = file2.lastModified() - file.lastModified();
                    if (lastModified > 0) {
                        return 1;
                    }
                    return lastModified == 0 ? 0 : -1;
                }
            });

            stardat();


        }
    }

    public class BradCatRecver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            switch (action) {
                case "main_service_api":
                    String mess = intent.getStringExtra("CONTROL_SERVICE");
                    if (mess.equals("Ascending")) {


                        Collections.sort(items, new Comparator<File>() {
                            @Override
                            public int compare(File lhs, File rhs) {

                                File file1 = lhs;
                                File file2 = rhs;

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });
                        stardat();


                    } else if (mess.equals("Descending")) {


                        Collections.sort(items, new Comparator<File>() {
                            @Override
                            public int compare(File lhs, File rhs) {

                                File file1 = lhs;
                                File file2 = rhs;

                                return file1.getName().toUpperCase().compareTo(file2.getName().toUpperCase());


                            }
                        });


                        Collections.reverse(items);
                        stardat();


                    } else if (mess.equals("Date")) {


                        Collections.sort(items, new Comparator<File>() {
                            DateFormat f = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");

                            @Override
                            public int compare(File lhs, File rhs) {
                                try {

                                    SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yyyy  hh:mm:ss a");
                                    Date lastModDate = new Date(lhs.lastModified());
                                    String ThiedTime = currentDate.format(lastModDate);

                                    Date lastModDate2 = new Date(rhs.lastModified());
                                    String ThiedTime2 = currentDate.format(lastModDate2);

                                    return f.parse(ThiedTime).compareTo(f.parse(ThiedTime2));
                                } catch (ParseException e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });

                        stardat();


                    } else if (mess.equals("Duration")) {
                        Collections.sort(items, new Comparator<File>() {


                            @Override
                            public int compare(File lhs, File rhs) {
                                try {
                                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                                    MediaMetadataRetriever retriever2 = new MediaMetadataRetriever();

                                    Uri uriOfFile = FileProvider.getUriForFile(getContext(),
                                            VideotoaudoApplication.getAppContext().getPackageName() + ".provider", lhs);


                                    Uri uriOfFile2 = FileProvider.getUriForFile(getContext(),
                                            VideotoaudoApplication.getAppContext().getPackageName() + ".provider", rhs);


                                    Long duration1 = null;
                                    Long duration2= null;

                                    try {
                                        retriever.setDataSource(getContext(), uriOfFile);
                                        duration1 = Long.parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                                        if (duration1 == null) {
                                            duration1 = Long.valueOf(0);
                                        }
                                    } catch (Exception e) {

                                    }


                                    try {
                                        retriever2.setDataSource(getContext(), uriOfFile2);

                                        duration2 =
                                                Long.parseLong(retriever2.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));

                                        if (duration2 == null) {
                                            duration2 = Long.valueOf(0);
                                        }


                                    } catch (Exception e) {

                                    }


                                    try {
                                        return duration1.compareTo(duration2);
                                    }
                                    catch (Exception e)
                                    {
                                        return 0;
                                    }








                                } catch (Exception e) {
                                    throw new IllegalArgumentException(e);
                                }
                            }
                        });


                        stardat();
                    }

                    else if (mess.equals("Delete")) {


                        CreateDataSource();
                        stardat();


                    } else if (mess.equals("Rename")) {


                        CreateDataSource();
                        stardat();


                    }



                    break;
            }


        }
    }

    public static Long getImageContentUri(Context context, File imageFile) {
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Files.getContentUri("external");
        }


        String filePath = imageFile.getAbsolutePath();
        Cursor cursor =  VideotoaudoApplication.getAppContext().getContentResolver().query(
                collection,
                new String[]{MediaStore.Files.FileColumns.DURATION},
                MediaStore.Files.FileColumns.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") Long id = cursor.getLong(cursor.getColumnIndex(MediaStore.MediaColumns.DURATION));
            cursor.close();
            return id;
        } else {


            return null;

        }


    }


    private void stardat() {
        mAdapter = new RingToneVAultAdapter(getActivity(), this.items, new filedatarecy() {
            @Override
            public void recycle(int allfile) {


            }


            @Override
            public void recycle2(File allfile) {

                ArrayList<Uri> uris = new ArrayList<Uri>();

                Uri uriOfCurrentFile = getImageContentUri2(
                        getActivity(),
                        allfile);


                if (uriOfCurrentFile != null) {
                    uris.add(uriOfCurrentFile);



                }


                PendingIntent pendingIntent = null;
                ContentResolver contentResolver = getActivity().getContentResolver();




                if (uris != null && uris.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        pendingIntent = MediaStore.createDeleteRequest(contentResolver, uris);
                    }
                }


                if (pendingIntent != null) {
                    IntentSender sender = pendingIntent.getIntentSender();
                    IntentSenderRequest request = new IntentSenderRequest.Builder(sender).build();
                    launcher.launch(request);
                }


            }

        }, "audio", tinyDB);
        if (items.size() > 0) {
            rv_conveter.setLayoutManager(new LinearLayoutManager(getActivity()));
            rv_conveter.setAdapter(this.mAdapter);
            rv_conveter.setVisibility(View.VISIBLE);
            noData.setVisibility(View.GONE);

        } else {
            rv_conveter.setVisibility(View.GONE);
            noData.setVisibility(View.VISIBLE);
        }

    }


}
