package com.si_avmixer.bhautik_avmixer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity;
import com.si_avmixer.bhautik_avmixer.Adapter.Images_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.Videos_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Images_Model;
import com.si_avmixer.bhautik_avmixer.Model.Videos_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

import static android.os.Build.VERSION.SDK_INT;

public class VideoFragment extends Fragment {


    TextView tv_noteSave;
    SharedPreferences sharedPreferences;
    int adapterValue = 0;
    View imageView;
    RecyclerView rv_SaveVideo;
    ArrayList<Videos_Model> VideosListArray = new ArrayList<>();
    Videos_Adapter VideoAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        imageView = inflater.inflate(R.layout.fragment_video, container, false);
        rv_SaveVideo = imageView.findViewById(R.id.rv_SaveVideo);
        tv_noteSave = imageView.findViewById(R.id.tv_noteSave);

        loadVideoData();

        return imageView;
    }

    public void loadVideoData() {

        VideosListArray = new ArrayList<>();

        if (SDK_INT >= Build.VERSION_CODES.R) {
            DocumentFile[] allFiles = getFromVideoSdcard();
            if (allFiles != null) {

                for (int i = 0; i < allFiles.length; i++) {
                    if (!allFiles[i].getUri().toString().contains(".nomedia")) {
                        if (allFiles[i].getName().endsWith(".mp4")) {
                            if (VideosListArray != null) {
                                VideosListArray.add(new Videos_Model(allFiles[i].getUri().toString(), allFiles[i].getName()));
                            } else {
                                Toast.makeText(getActivity(), "No Videos", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        } else {

            sharedPreferences =getActivity().getSharedPreferences("OldPermissionSP", Context.MODE_PRIVATE);
            String finalPath = sharedPreferences.getString("OldValuePermission", "");

            File file2 = new File(finalPath);
            if (file2.exists()) {
                File[] listFiles = file2.listFiles();

                if (listFiles != null) {
                    for (int i = 0; i < listFiles.length; i++) {
                        if (listFiles[i].getName().endsWith(".mp4")) {
                            VideosListArray.add(new Videos_Model(listFiles[i].getPath(), listFiles[i].getName()));
                            Intent intent11 = getActivity().getIntent();
                            int Value11 = intent11.getIntExtra("DoubleWBVal", 0);

                            Intent intent12 = getActivity().getIntent();
                            int Value12 = intent12.getIntExtra("DoubleWVal", 0);

                            Intent intent13 = getActivity().getIntent();
                            int Value13 = intent13.getIntExtra("below11WB", 0);

                            Intent intent14 = getActivity().getIntent();
                            int Value14 = intent14.getIntExtra("below11W", 0);

                            if (finalPath.contains("Business")) {
                                if (Value11 == 11) {
                                    adapterValue = Value11;
                                }
                                if (Value13 == 13) {
                                    adapterValue = Value13;
                                }
                            } else {
                                if (Value12 == 12) {
                                    adapterValue = Value12;
                                }
                                if (Value14 == 14) {
                                    adapterValue = Value14;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (VideosListArray.size() == 0) {
            tv_noteSave.setVisibility(View.VISIBLE);
            rv_SaveVideo.setVisibility(View.GONE);
        }

        Intent intent = getActivity().getIntent();
        int Value = intent.getIntExtra("WBVal", 0);

        Intent intent2 = getActivity().getIntent();
        int Value2 = intent2.getIntExtra("WVal", 0);

        Intent intent3 = getActivity().getIntent();
        int Value3 = intent3.getIntExtra("OneVal", 0);

        Intent intent4 = getActivity().getIntent();
        int Value4 = intent4.getIntExtra("OneVal", 0);

        if (Value == 1) {
            adapterValue = Value;
        } else if (Value2 == 2) {
            adapterValue = Value2;
        } else if (Value3 == 3) {
            adapterValue = Value3;
        } else if (Value4 == 4) {
            adapterValue = Value4;
        }

        VideoAdapter = new Videos_Adapter(VideosListArray,getActivity(), adapterValue);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL);
        rv_SaveVideo.setLayoutManager(staggeredGridLayoutManager);
        rv_SaveVideo.setItemAnimator(new DefaultItemAnimator());
        rv_SaveVideo.setAdapter(VideoAdapter);
        VideoAdapter.notifyDataSetChanged();

    }

    public DocumentFile[] getFromVideoSdcard() {

        DocumentFile fromTreeUri = null;

        Intent intent =  getActivity().getIntent();
        int Value = intent.getIntExtra("WBVal", 0);

        Intent intent2 =  getActivity().getIntent();
        int Value2 = intent2.getIntExtra("WVal", 0);

        Intent intent3 =  getActivity().getIntent();
        int Value3 = intent3.getIntExtra("OneVal", 0);

        Intent intent4 =  getActivity().getIntent();
        int Value4 = intent4.getIntExtra("OneVal", 0);

        if (Value == 1) {
            sharedPreferences = getActivity().getSharedPreferences("WBPermissionSP", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("WBValuePermission", "")));
        }

        if (Value2 == 2) {
            sharedPreferences = getActivity().getSharedPreferences("PermissionSP", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("WaValuePermission", "")));
        }

        if (Value3 == 3) {
            sharedPreferences = getActivity().getSharedPreferences("OnePermissionW", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("OnePermissionWValue", "")));
        }

        if (Value4 == 4) {
            sharedPreferences = getActivity().getSharedPreferences("OnePermissionWB", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("OnePermissionWBValue", "")));
        }

        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();

    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            if (VideosListArray.size() != 0) {
                VideoAdapter.notifyDataSetChanged();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}