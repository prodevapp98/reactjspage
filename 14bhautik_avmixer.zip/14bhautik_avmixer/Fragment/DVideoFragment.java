package com.si_avmixer.bhautik_avmixer.Fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Activity.SavedStatus_Activity;
import com.si_avmixer.bhautik_avmixer.Adapter.download_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Download_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;


public class DVideoFragment extends Fragment {

    RecyclerView rv_DownloadVideo;
    TextView tv_note;
    ArrayList<Download_Model> DownloadVideoList = new ArrayList<>();
    download_Adapter adapter;
    View dvideo;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        dvideo = inflater.inflate(R.layout.fragment_d_video, container, false);
        rv_DownloadVideo = dvideo.findViewById(R.id.rv_DownloadVideo);
        tv_note = dvideo.findViewById(R.id.tv_note);

        loadData();

        return dvideo;
    }

    public void loadData(){
        Intent intent = getActivity().getIntent();
        int Value = intent.getIntExtra("WBVal", 0);

        Intent intent2 =  getActivity().getIntent();
        int Value2 = intent2.getIntExtra("WVal", 0);

        Intent intent3 = getActivity().getIntent();
        int Value3 = intent3.getIntExtra("OneVal", 0);

        Intent intent4 = getActivity().getIntent();
        int Value4 = intent4.getIntExtra("OneVal", 0);

        Intent intent11 = getActivity().getIntent();
        int Value11 = intent11.getIntExtra("DoubleWBVal",0);

        Intent intent12 = getActivity().getIntent();
        int Value12 = intent12.getIntExtra("DoubleWVal",0);

        Intent intent13 = getActivity().getIntent();
        int Value13 = intent13.getIntExtra("below11WB",0);

        Intent intent14 = getActivity().getIntent();
        int Value14 = intent14.getIntExtra("below11W",0);

        if (Value14 == 14){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUp/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList.add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value13 == 13){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUpWB/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList.add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value11 == 11){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUpWB/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value12 == 12){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUp/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value == 1){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUpWB/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value2 == 2){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUp/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value4 == 4){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUpWB/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }
        if (Value3 == 3){
            File filePathVideo = new File(getActivity().getFilesDir(), "GBWhatzUp/Videos");
            String filePath2 = String.valueOf(filePathVideo);
            File file2 = new File(filePath2);
            File[] files2 = file2.listFiles();
            if (files2 != null) {
                for (File file1 : files2) {
                    if (file1.getPath().endsWith(".mp4")) {
                        DownloadVideoList .add(new Download_Model(file1.getPath()));
                    }
                }
            }
        }

        Collections.reverse(DownloadVideoList);

        if (DownloadVideoList.size() == 0){
            tv_note.setVisibility(View.VISIBLE);
            rv_DownloadVideo.setVisibility(View.GONE);
        } else {
            tv_note.setVisibility(View.GONE);
            rv_DownloadVideo.setVisibility(View.VISIBLE);
        }

        adapter = new download_Adapter(DownloadVideoList, getActivity());
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL);
        rv_DownloadVideo.setLayoutManager(staggeredGridLayoutManager);
        rv_DownloadVideo.setItemAnimator(new DefaultItemAnimator());
        rv_DownloadVideo.setAdapter(adapter);

        adapter.setOnButtonClickListener(new download_Adapter.onButtonClickListener() {
            @Override
            public void onButtonDeleteClickListener(int position, String imageUrl) {
                String imgpath = imageUrl;
                if (imgpath.contains(".jpg") || imgpath.contains(".png")) {
                    File fdelete = new File(imgpath);
                    if (fdelete.exists()) {
                        if (fdelete.delete()) {
                            Toast.makeText(getActivity(), "file Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getActivity(), "file not Deleted", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    File fdelete = new File(imgpath);
                    if (fdelete.exists()) {
                        if (fdelete.delete()) {
                            DownloadVideoList.remove(position);
                            adapter.setnewData(DownloadVideoList);
                            Toast.makeText(getActivity(), "file Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getActivity(), "file not Deleted", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }

            @Override
            public void onButtonShareClickListener(int position, String imageUrl) {
                File file = new File(imageUrl);
                Uri fileUri = FileProvider.getUriForFile(getActivity(), getActivity().getPackageName() + ".fileProvider", file);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("*/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            if (DownloadVideoList.size() != 0) {
                DownloadVideoList.clear();
                loadData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}