package com.si_avmixer.bhautik_avmixer.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.OrientationHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity;
import com.si_avmixer.bhautik_avmixer.Adapter.Images_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Images_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

import static android.os.Build.VERSION.SDK_INT;


public class ImageFragment extends Fragment {

    ArrayList<Images_Model> ImagesListArray = new ArrayList<>();
    Images_Adapter adapter;
    TextView tv_noteSave;
    View imageView;
    SharedPreferences sharedPreferences;
    int adapterValue = 0;
    RecyclerView rv_SaveImage;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        imageView = inflater.inflate(R.layout.fragment_image, container, false);
        rv_SaveImage = imageView.findViewById(R.id.rv_SaveImage);
        tv_noteSave = imageView.findViewById(R.id.tv_noteSave);

        loadImageData();

        return imageView;
    }

    public void loadImageData() {

        if (SDK_INT >= Build.VERSION_CODES.R) {

            DocumentFile[] allFiles = getFromImageSdcard();

            if (allFiles != null) {

                for (int i = 0; i < allFiles.length; i++) {
                    if (!allFiles[i].getUri().toString().contains(".nomedia")) {

                        if (allFiles[i].getName().endsWith(".jpg")) {
                            if (ImagesListArray != null) {
                                ImagesListArray.add(new Images_Model(allFiles[i].getUri().toString(), allFiles[i].getName()));
                            } else {
                                Toast.makeText(getActivity(), "No Images", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }

            }

        } else {

            sharedPreferences = getActivity().getSharedPreferences("OldPermissionSP", Context.MODE_PRIVATE);
            String finalPath = sharedPreferences.getString("OldValuePermission", "");

            File file2 = new File(finalPath);
            if (file2.exists()) {
                File[] listFiles = file2.listFiles();
                if (listFiles != null) {
                    for (int i = 0; i < listFiles.length; i++) {
                        if (listFiles[i].getName().endsWith(".png") || listFiles[i].getName().endsWith(".jpg")) {
                            ImagesListArray.add(new Images_Model(listFiles[i].getPath(), listFiles[i].getName()));

                            Intent intent11 = getActivity().getIntent();
                            int Value11 = intent11.getIntExtra("DoubleWBVal", 0);

                            Intent intent12 = getActivity().getIntent();
                            int Value12 = intent12.getIntExtra("DoubleWVal", 0);

                            Intent intent13 = getActivity().getIntent();
                            int Value13 = intent13.getIntExtra("below11WB", 0);

                            Intent intent14 = getActivity().getIntent();
                            int Value14 = intent14.getIntExtra("below11W", 0);

                            if (finalPath.contains("Business")) {
                                if (Value11 == 11) {
                                    adapterValue = Value11;
                                }
                                if (Value13 == 13) {
                                    adapterValue = Value13;
                                }
                            } else {
                                if (Value12 == 12) {
                                    adapterValue = Value12;
                                }
                                if (Value14 == 14) {
                                    adapterValue = Value14;
                                }
                            }
                        }
                    }
                }
            }

        }

        if (ImagesListArray.size() == 0) {
            tv_noteSave.setVisibility(View.VISIBLE);
            rv_SaveImage.setVisibility(View.GONE);
        }

        Intent intent = getActivity().getIntent();
        int Value = intent.getIntExtra("WBVal", 0);

        Intent intent2 = getActivity().getIntent();
        int Value2 = intent2.getIntExtra("WVal", 0);

        Intent intent3 = getActivity().getIntent();
        int Value3 = intent3.getIntExtra("OneVal", 0);

        Intent intent4 = getActivity().getIntent();
        int Value4 = intent4.getIntExtra("OneVal", 0);

        if (Value == 1) {
            adapterValue = Value;
        } else if (Value2 == 2) {
            adapterValue = Value2;
        } else if (Value3 == 3) {
            adapterValue = Value3;
        } else if (Value4 == 4) {
            adapterValue = Value4;
        }

        adapter = new Images_Adapter(ImagesListArray, getActivity(), adapterValue);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, OrientationHelper.VERTICAL);
        layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        rv_SaveImage.setLayoutManager(layoutManager);
        rv_SaveImage.setItemAnimator(new DefaultItemAnimator());
        rv_SaveImage.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    public DocumentFile[] getFromImageSdcard() {

        DocumentFile fromTreeUri = null;

        Intent intent =getActivity().getIntent();
        int Value = intent.getIntExtra("WBVal", 0);

        Intent intent2 = getActivity().getIntent();
        int Value2 = intent2.getIntExtra("WVal", 0);

        Intent intent3 = getActivity().getIntent();
        int Value3 = intent3.getIntExtra("OneVal", 0);

        Intent intent4 = getActivity().getIntent();
        int Value4 = intent4.getIntExtra("OneVal", 0);

        if (Value == 1) {
            sharedPreferences = getActivity().getSharedPreferences("WBPermissionSP", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("WBValuePermission", "")));
        }

        if (Value2 == 2) {
            sharedPreferences = getActivity().getSharedPreferences("PermissionSP", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("WaValuePermission", "")));
        }

        if (Value3 == 3) {
            sharedPreferences = getActivity().getSharedPreferences("OnePermissionW", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("OnePermissionWValue", "")));
        }

        if (Value4 == 4) {
            sharedPreferences = getActivity().getSharedPreferences("OnePermissionWB", Context.MODE_PRIVATE);
            fromTreeUri = DocumentFile.fromTreeUri(getActivity(), Uri.parse(sharedPreferences.getString("OnePermissionWBValue", "")));
        }

        if (fromTreeUri == null || !fromTreeUri.exists() || !fromTreeUri.isDirectory() || !fromTreeUri.canRead() || !fromTreeUri.canWrite()) {
            return null;
        }
        return fromTreeUri.listFiles();
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            if (ImagesListArray.size() != 0) {
                adapter.notifyDataSetChanged();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}