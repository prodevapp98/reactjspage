package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.myCreation_audio;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.myCreationAudioCutter_Model;
import com.si_avmixer.bhautik_avmixer.Model.myCreationVideo_Model;
import com.si_avmixer.bhautik_avmixer.R;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import static com.si_avmixer.bhautik_avmixer.Activity.myCreation_Activity.fromCreation;
import static com.si_avmixer.bhautik_avmixer.Adapter.myCreation_audio.mediaPlayerAudioCreation;

public class myCreation_Audio_Activity extends AppCompatActivity implements myCreation_audio.Pos {

    RecyclerView rv_mycreationAudioCutter;
    String downlaods;
    public static ArrayList<myCreationAudioCutter_Model> AudioCutterList;
    myCreation_audio adapter;
    TextView tv_V2A, tv_AudioCutter, tv_note;
    ImageView iv_back_myfiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation_audio_cutter);

        rv_mycreationAudioCutter = findViewById(R.id.rv_mycreationAudioCutter);
        tv_AudioCutter = findViewById(R.id.tv_AudioCutter);
        tv_V2A = findViewById(R.id.tv_V2A);
        iv_back_myfiles = findViewById(R.id.iv_back_myfiles);
        tv_note = findViewById(R.id.tv_note);

        AudioCutterList = new ArrayList<>();


        Intent intent = getIntent();
        int Val = intent.getIntExtra("Value", 0);

        if (Val == 0) {
            downlaods = (getExternalFilesDir("").toString() + "/AVMixer/AudioCutter/");
            tv_V2A.setVisibility(View.GONE);
            tv_AudioCutter.setVisibility(View.VISIBLE);
        } else {
            downlaods = (getExternalFilesDir("").toString() + "/AVMixer/V2A/");
            tv_V2A.setVisibility(View.VISIBLE);
            tv_AudioCutter.setVisibility(View.GONE);
        }

        iv_back_myfiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        loadData();
    }

    @Override
    public void onBackPressed() {

        if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()){
            mediaPlayerAudioCreation.stop();
        }

//        if (fromCreation) {
//            Intent intent1 = new Intent(myCreation_Audio_Activity.this, myCreation_Activity.class);
//            startActivity(intent1);
//            finish();
//            fromCreation = false;
//        } else {
            finish();
//            Intent intent1 = new Intent(myCreation_Audio_Activity.this, myFiles_Activity.class);
//            startActivity(intent1);
//        }


    }

    public void loadData() {
        String filePath = String.valueOf(downlaods);
        File file = new File(filePath);
        File[] files = file.listFiles();
        if (files != null) {
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            for (File file1 : files) {
                if (file1.getPath().endsWith(".m4a") || file1.getPath().endsWith(".mp3")) {

                    long sizeInBytes = file1.length();
                    long sizeInMb = sizeInBytes / (1024 * 1024);

                    if (Math.toIntExact(sizeInMb) == 0) {
                        sizeInMb = 1;
                    }

                    String duration = Utils.Companion.getDuration(file1.getAbsolutePath());

                    AudioCutterList.add(new myCreationAudioCutter_Model(file1.getPath(), file1.getName(), Math.toIntExact(sizeInMb), duration));

                }
            }
        }

        if (AudioCutterList.size() == 0){
            tv_note.setVisibility(View.VISIBLE);
            rv_mycreationAudioCutter.setVisibility(View.GONE);
        } else {
            tv_note.setVisibility(View.GONE);
            rv_mycreationAudioCutter.setVisibility(View.VISIBLE);
        }

        Collections.sort(AudioCutterList, new Comparator<myCreationAudioCutter_Model>() {
            @Override
            public int compare(myCreationAudioCutter_Model lhs, myCreationAudioCutter_Model rhs) {
                return lhs.getSongName().compareTo(rhs.getSongName());
            }
        });

        adapter = new myCreation_audio(AudioCutterList, getApplicationContext(), this::onClick);
        rv_mycreationAudioCutter.setLayoutManager(new LinearLayoutManager(this));
        rv_mycreationAudioCutter.setItemAnimator(new DefaultItemAnimator());
        rv_mycreationAudioCutter.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

boolean isPasue = false;
    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()){
            mediaPlayerAudioCreation.pause();
            isPasue = true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isPasue){
            isPasue = false;
            mediaPlayerAudioCreation.start();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public static Rect locateView(View v) {
        int[] loc_int = new int[2];
        if (v == null) return null;
        try {
            v.getLocationOnScreen(loc_int);
        } catch (NullPointerException npe) {
            return null;
        }
        Rect location = new Rect();
        location.left = loc_int[0];
        location.top = loc_int[1];
        location.right = location.left + v.getWidth();
        location.bottom = location.top + v.getHeight();
        return location;
    }

    public static PopupWindow mpopup;

    @Override
    public void onClick(int positions, View v, String url) {
        View popUpView = getLayoutInflater().inflate(R.layout.menu_popup,
                null);

        mpopup = new PopupWindow(popUpView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        mpopup.setAnimationStyle(android.R.style.Animation_Dialog);

        Rect location = locateView(v);
        mpopup.showAtLocation(v, Gravity.TOP | Gravity.RIGHT, 50, location.bottom);

        LinearLayout linearLayoutDelete = popUpView.findViewById(R.id.iv_delete);
        LinearLayout linearLayoutShare = popUpView.findViewById(R.id.iv_share);

        linearLayoutDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(myCreation_Audio_Activity.this);
                dialog.setContentView(R.layout.delete_confirmation);
                dialog.setTitle("Title");

                ImageView delete = dialog.findViewById(R.id.iv_deleteCreation);
                ImageView close = dialog.findViewById(R.id.iv_closeDialog);

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        File fdelete = new File(url);
                        if (fdelete.exists()) {
                            if (fdelete.delete()) {
                                Toast.makeText(getApplicationContext(), "file Deleted", Toast.LENGTH_SHORT).show();
                                AudioCutterList.clear();
                                if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()){
                                    mediaPlayerAudioCreation.stop();
                                }
                                loadData();
                                mpopup.dismiss();
                                dialog.dismiss();
                            } else {
                                Toast.makeText(getApplicationContext(), "file not Deleted", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                });

                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

            }
        });

        linearLayoutShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(url);
                Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".fileProvider", file);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

    }

}