package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.si_avmixer.bhautik_avmixer.AudioExtractor.AudioExtractor;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import life.knowledge4.videotrimmer.K4LVideoTrimmer;
import life.knowledge4.videotrimmer.interfaces.OnK4LVideoListener;
import life.knowledge4.videotrimmer.interfaces.OnTrimVideoListener;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static life.knowledge4.videotrimmer.K4LVideoTrimmer.currentSpeed;
import static life.knowledge4.videotrimmer.K4LVideoTrimmer.slowMotion;
import static life.knowledge4.videotrimmer.K4LVideoTrimmer.videoName;

public class videoTrimmer_Activity extends AppCompatActivity implements OnTrimVideoListener, OnK4LVideoListener {

    private K4LVideoTrimmer mVideoTrimmer;
    String sourcePathV2A, destPathV2A, destDirectoryV2A, fileNameV2A;

    File dest;
    String original_path;
    String videoFilePath;
    String myVideoPath;
    String destPathMotion;
    String[] command;
    private String filePath;
    int Value;

    ImageView btn_back_videoCutMos;
    TextView tv_convert, tv_cutter;
    TextView tv_Motion;

    boolean processstarted = false;
    boolean closeproce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_trimmer);

        btn_back_videoCutMos = findViewById(R.id.btn_back_videoCutMos);
        tv_cutter = findViewById(R.id.tv_cutter);
        tv_convert = findViewById(R.id.tv_convert);
        tv_Motion = findViewById(R.id.tv_Motion);

        Intent intent = getIntent();
        videoFilePath = intent.getStringExtra("VideoTrimmer");
        Value = intent.getIntExtra("ValueV2A", 0);

        mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));


        if (Value == 1) {
            tv_cutter.setVisibility(GONE);
            tv_convert.setVisibility(VISIBLE);

            mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));
            if (mVideoTrimmer != null) {
                mVideoTrimmer.setMaxDuration(600);
                mVideoTrimmer.setOnTrimVideoListener(this);
                mVideoTrimmer.setOnK4LVideoListener(this);
                mVideoTrimmer.setDestinationPath("/storage/emulated/0/DCIM/AVMixerV2A/");
                mVideoTrimmer.setVideoURI(Uri.parse(videoFilePath), Value);
                mVideoTrimmer.setVideoInformationVisibility(true);
            }
        } else if (Value == 0) {
            mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));
            if (mVideoTrimmer != null) {
                mVideoTrimmer.setMaxDuration(600);
                mVideoTrimmer.setOnTrimVideoListener(this);
                mVideoTrimmer.setOnK4LVideoListener(this);
                mVideoTrimmer.setDestinationPath("/storage/emulated/0/DCIM/AVMixerVideoCutter/");
                mVideoTrimmer.setVideoURI(Uri.parse(videoFilePath), Value);
                mVideoTrimmer.setVideoInformationVisibility(true);
            }
        } else if (Value == 2) {

            tv_Motion.setVisibility(VISIBLE);
            tv_cutter.setVisibility(GONE);
            tv_convert.setVisibility(GONE);

            mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));
            if (mVideoTrimmer != null) {
                mVideoTrimmer.setMaxDuration(600);
                mVideoTrimmer.setOnTrimVideoListener(this);
                mVideoTrimmer.setOnK4LVideoListener(this);
                mVideoTrimmer.setDestinationPath("/storage/emulated/0/DCIM/AVMixerVideoCutterMotion/");
                mVideoTrimmer.setVideoURI(Uri.parse(videoFilePath), Value);
                mVideoTrimmer.setVideoInformationVisibility(true);
            }
        }

        btn_back_videoCutMos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {

        if (processstarted) {
            closeproce = true;
            mVideoTrimmer.destroy();
        }

        finish();
        super.onBackPressed();
    }

    @Override
    public void onTrimStarted() {
        processstarted = true;

    }

    @Override
    public void getResult(final Uri uri, int val) {

        if (val == 0) {

            if (closeproce) {
                processstarted = false;
                closeproce = false;
            } else {
                Intent intent = new Intent(videoTrimmer_Activity.this, Exported_Activity.class);
                intent.putExtra("VideoTrimmerVideoPath", uri.getPath());
                startActivity(intent);
                finish();
            }

        } else if (val == 1) {

            String externalRootDir = getExternalFilesDir("/").toString();
            if (!externalRootDir.endsWith("/")) {
                externalRootDir += "/";
            }

            String subdir = "AVMixer/V2A/";
            String parentdir = externalRootDir + subdir;

            File parentDirFile = new File(parentdir);
            parentDirFile.mkdirs();
            destDirectoryV2A = parentdir;
            if (isVideoHaveAudioTrack(uri)) {
                sourcePathV2A = uri.getPath();
                String[] array = sourcePathV2A.split("/", 0);
                fileNameV2A = array[array.length - 1].replace("mp4", "mp3");
                destPathV2A = destDirectoryV2A + fileNameV2A;

                AudioExtractor audioExtractor = new AudioExtractor();
                try {
                    audioExtractor.VideotoAudio(sourcePathV2A, destPathV2A, true, false);

                    if (closeproce) {
                        processstarted = false;
                        closeproce = false;
                        deleteV2A_videoFiles();
                    } else {

                        Intent intent = new Intent(videoTrimmer_Activity.this, Exported_Activity.class);
                        intent.putExtra("VideoTrimmerVideoPath", destPathV2A);
                        intent.putExtra("value", val);
                        startActivity(intent);
                        finish();

                        clearSharedPreference();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    finish();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(videoTrimmer_Activity.this, "Try Another Video", Toast.LENGTH_SHORT).show();
                        }
                    });

                }


            } else {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(videoTrimmer_Activity.this, "Video Has No Sound", Toast.LENGTH_SHORT).show();
                    }
                });

                finish();
            }

        } else if (val == 2) {

            String externalRootDir = getExternalFilesDir("/").toString();
            if (!externalRootDir.endsWith("/")) {
                externalRootDir += "/";
            }
            String subdir = "AVMixer/VideoMotion/";
            String parentdir = externalRootDir + subdir;

            File parentDirFile = new File(parentdir);
            parentDirFile.mkdirs();

            File file = new File(uri.getPath());
            destPathMotion = parentdir + file.getName();

            myVideoPath = uri.getPath();

            if (slowMotion) {
                slowSpeed();
            } else {
                fastSpeed();
            }

        }

    }

    private boolean isVideoHaveAudioTrack(Uri path) {
        boolean audioTrack = false;

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(this, path);
        String hasAudioStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO);
        if (hasAudioStr != null && hasAudioStr.equals("yes")) {
            audioTrack = true;
        } else {
            audioTrack = false;
        }

        return audioTrack;
    }

    public void slowSpeed() {
        float f2 = 2.0f;

        if (currentSpeed != 2) {
            if (currentSpeed == 3) {
                f2 = 3.0f;
            } else if (currentSpeed == 4) {
                f2 = 4.0f;
            } else if (currentSpeed == 5) {
                f2 = 5.0f;
            } else if (currentSpeed == 6) {
                f2 = 6.0f;
            } else if (currentSpeed == 7) {
                f2 = 7.0f;
            } else if (currentSpeed == 8) {
                f2 = 8.0f;
            }
        }

        File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/avmixerslowvideo");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        String fileExt = ".mp4";

        dest = new File(folder, videoName + fileExt);
        original_path = myVideoPath;

        StringBuilder sb = new StringBuilder();
        sb.append("setpts=");
        sb.append(f2);
        sb.append("PTS");

        filePath = dest.getAbsolutePath();

        command = new String[]{"-y", "-i", original_path, "-filter_complex", "[0:v]setpts=2.0*PTS[v];[0:a]atempo=0.5[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", filePath};
        execFFmpegBinary(command);
    }

    public void fastSpeed() {

        float f2 = 2.0f;

        if (currentSpeed != 2) {
            if (currentSpeed == 3) {
                f2 = 3.0f;
            } else if (currentSpeed == 4) {
                f2 = 4.0f;
            } else if (currentSpeed == 5) {
                f2 = 5.0f;
            } else if (currentSpeed == 6) {
                f2 = 6.0f;
            } else if (currentSpeed == 7) {
                f2 = 7.0f;
            } else if (currentSpeed == 8) {
                f2 = 8.0f;
            }
        }

        File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/avmixerslowvideo");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        String fileExt = ".mp4";

        dest = new File(folder, videoName + fileExt);
        original_path = myVideoPath;

        StringBuilder sb = new StringBuilder();
        sb.append("setpts=");
        sb.append(f2);
        sb.append("PTS");

        filePath = dest.getAbsolutePath();

        command = new String[]{"-y", "-i", original_path, "-filter_complex", "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", filePath};
        execFFmpegBinary(command);

    }

    private void execFFmpegBinary(final String[] command) {

        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage message) {
            }
        });

        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics statistics) {
            }
        });

        Long executionID = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                if (returnCode == RETURN_CODE_SUCCESS) {
                    if (closeproce) {
                        processstarted = false;
                        closeproce = false;
                        deleteVM_videoFiles();
                    } else {
                        Intent intent = new Intent(videoTrimmer_Activity.this, Exported_Activity.class);
                        intent.putExtra("value", Value);
                        intent.putExtra("VideoTrimmerVideoPath", filePath);
                        startActivity(intent);
                        finish();
                    }
                } else if (returnCode == RETURN_CODE_CANCEL) {
                } else {
                    finish();
                    Toast.makeText(videoTrimmer_Activity.this, "Video Not Supported Select Another Video", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void cancelAction() {
        mVideoTrimmer.destroy();
        finish();
    }

    @Override
    public void onError(final String message) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(videoTrimmer_Activity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onVideoPrepared() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    public void clearSharedPreference() {
        SharedPreferences preferences = getSharedPreferences("QualitySelection", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
    }

    private Locale getLocale() {
        Configuration config = getResources().getConfiguration();
        Locale sysLocale = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            sysLocale = getSystemLocale(config);
        } else {
            sysLocale = getSystemLocaleLegacy(config);
        }

        return sysLocale;
    }

    public static Locale getSystemLocaleLegacy(Configuration config) {
        return config.locale;
    }

    @TargetApi(Build.VERSION_CODES.N)
    public static Locale getSystemLocale(Configuration config) {
        return config.getLocales().get(0);
    }

    public void deleteV2A_videoFiles() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/AVMixerV2A/");
            if (dir.exists()) {
                if (dir.isDirectory()) {
                    String[] children = dir.list();
                    for (int i = 0; i < children.length; i++) {
                        new File(dir, children[i]).delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteVM_videoFiles() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/AVMixerVideoCutterMotion/");
            if (dir.exists()) {
                if (dir.isDirectory()) {
                    String[] children = dir.list();
                    for (int i = 0; i < children.length; i++) {
                        new File(dir, children[i]).delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}