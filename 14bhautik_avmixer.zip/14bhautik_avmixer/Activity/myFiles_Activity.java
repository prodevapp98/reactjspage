package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.si_avmixer.bhautik_avmixer.R;

import static android.os.Build.VERSION.SDK_INT;
import static com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity.showDialog;

public class myFiles_Activity extends AppCompatActivity {

    ImageView iv_statusSaver,iv_myCreation;
    RelativeLayout dialogLayout,mainLayout;
    ImageView unselect_wa,unselect_wb,selected_wa,selected_wb, iv_select,btn_back_myFiles;
    public static boolean WhatszUpFile = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_files);

        iv_myCreation = findViewById(R.id.iv_myCreation);
        iv_statusSaver = findViewById(R.id.iv_statusSaver);
        mainLayout = findViewById(R.id.mainLayout);
        dialogLayout = findViewById(R.id.dialogLayout);

        unselect_wa = findViewById(R.id.unselect_wa);
        unselect_wb = findViewById(R.id.unselect_wb);
        selected_wa = findViewById(R.id.selected_wa);
        selected_wb = findViewById(R.id.selected_wb);
        iv_select = findViewById(R.id.iv_select);
        btn_back_myFiles = findViewById(R.id.btn_back_myFiles);

        btn_back_myFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        iv_myCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(myFiles_Activity.this,myCreation_Activity.class);
                startActivity(intent);
            }
        });

        iv_statusSaver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (appInstalledOrNot("com.whatsapp") && appInstalledOrNot("com.whatsapp.w4b")){

                    mainLayout.setVisibility(View.GONE);
                    dialogLayout.setVisibility(View.VISIBLE);

                    unselect_wa.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            selected_wa.setVisibility(View.VISIBLE);
                            unselect_wa.setVisibility(View.GONE);
                            selected_wb.setVisibility(View.GONE);
                            unselect_wb.setVisibility(View.VISIBLE);
                            WhatszUpFile = true;
                            iv_select.setVisibility(View.VISIBLE);
                        }
                    });
                    unselect_wb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            selected_wb.setVisibility(View.VISIBLE);
                            unselect_wb.setVisibility(View.GONE);
                            selected_wa.setVisibility(View.GONE);
                            unselect_wa.setVisibility(View.VISIBLE);
                            WhatszUpFile = false;
                            iv_select.setVisibility(View.VISIBLE);
                        }
                    });

                    iv_select.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (WhatszUpFile){
                                if (appInstalledOrNot("com.whatsapp")){
                                    if (SDK_INT >= Build.VERSION_CODES.R){
                                        Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                                        intent.putExtra("WVal",2);
                                        startActivity(intent);
                                    } else {
                                        Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                                        intent.putExtra("DoubleWVal",12);
                                        startActivity(intent);
                                    }
                                }
                            } else {
                                if (appInstalledOrNot("com.whatsapp.w4b")){
                                    if (SDK_INT >= Build.VERSION_CODES.R){
                                        Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                                        intent.putExtra("WBVal",1);
                                        startActivity(intent);
                                    } else {
                                        Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                                        intent.putExtra("DoubleWBVal",11);
                                        startActivity(intent);
                                    }
                                }
                            }

                        }
                    });

                } else {

                    if (appInstalledOrNot("com.whatsapp")){

                        if (SDK_INT >= Build.VERSION_CODES.R){
                            Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                            intent.putExtra("OneVal",3);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                            intent.putExtra("below11W",14);
                            startActivity(intent);
                        }

                    }

                    if (appInstalledOrNot("com.whatsapp.w4b")){
                        if (SDK_INT >= Build.VERSION_CODES.R){
                            Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                            intent.putExtra("OneVal",4);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(myFiles_Activity.this, SavedStatus_Activity.class);
                            intent.putExtra("below11WB",13);
                            startActivity(intent);
                        }
                    }

                }

            }
        });



    }

    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        }
        catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainLayout.setVisibility(View.VISIBLE);
        dialogLayout.setVisibility(View.GONE);

        if (showDialog){
            mainLayout.setVisibility(View.GONE);
            dialogLayout.setVisibility(View.VISIBLE);
            showDialog = false;
        }
    }

    @Override
    public void onBackPressed() {

        if (dialogLayout.getVisibility() == View.VISIBLE){
            dialogLayout.setVisibility(View.GONE);
            mainLayout.setVisibility(View.VISIBLE);
        } else {

            finish();

//            Intent in = new Intent(myFiles_Activity.this, MainActivity.class);
//            startActivity(in);
        }

//        if (showDialog){
//            Intent in = new Intent(myFiles_Activity.this, StatusSaver_Activity.class);
//            startActivity(in);
//        }

    }
}