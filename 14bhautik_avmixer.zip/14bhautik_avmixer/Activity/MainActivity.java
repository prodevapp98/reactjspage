package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.si_avmixer.bhautik_avmixer.BuildConfig;
import com.si_avmixer.bhautik_avmixer.R;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.os.Build.VERSION.SDK_INT;
import static com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity.showDialog;

public class MainActivity extends AppCompatActivity {

    ImageView iv_AudioCutter, iv_VideoCutter, iv_V2A, iv_VideoMotion, iv_AVMixer, iv_StatusSaver, iv_myFiles;
    AlertDialog create1;
    public String finalPath;
    RelativeLayout dialogSaver, buttons, lay_more;
    ImageView unselect_wa, unselect_wb, selected_wa, selected_wb, iv_select;
    public static boolean WhatszUp = false;
    public static boolean SingleWhatszUp = false;
    ImageView iv_opnDrawer;
    LinearLayout lin_ShareApp, lin_RateApp, lin_MoreApp, lin_Privacy;
    private long lClickTime = 0;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    boolean alreadySelected = false;
    boolean alreadySelectedB = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_opnDrawer = findViewById(R.id.iv_opnDrawer);
        iv_AudioCutter = findViewById(R.id.iv_AudioCutter);
        iv_VideoCutter = findViewById(R.id.iv_VideoCutter);
        iv_V2A = findViewById(R.id.iv_V2A);
        iv_VideoMotion = findViewById(R.id.iv_VideoMotion);
        iv_AVMixer = findViewById(R.id.iv_AVMixer);
        iv_StatusSaver = findViewById(R.id.iv_StatusSaver);
        iv_myFiles = findViewById(R.id.iv_myFiles);
        buttons = findViewById(R.id.allbtn);
        dialogSaver = findViewById(R.id.dialogSaver);
        unselect_wa = findViewById(R.id.unselect_wa);
        unselect_wb = findViewById(R.id.unselect_wb);
        selected_wa = findViewById(R.id.selected_wa);
        selected_wb = findViewById(R.id.selected_wb);
        iv_select = findViewById(R.id.iv_select);
        lay_more = findViewById(R.id.lay_more);

        drawerLayout = findViewById(R.id.drawer_layout_id);
        navigationView = findViewById(R.id.navigationview_id);
        View header = navigationView.getHeaderView(0);
        toggleDrawer();

        iv_opnDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        header.findViewById(R.id.lin_ShareApp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SystemClock.elapsedRealtime() - lClickTime < 200) {
                    return;
                }
                lClickTime = SystemClock.elapsedRealtime();

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });

        header.findViewById(R.id.lin_RateApp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, " Unable to find AVMixer App", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {

                }
            }
        });

        header.findViewById(R.id.lin_MoreApp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MoreApps_Activity.class);
                startActivity(intent);
            }
        });

        header.findViewById(R.id.lin_Privacy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        iv_myFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, myFiles_Activity.class);
                startActivity(intent);
            }
        });

        iv_AVMixer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndRequestPermissions(111)) {
                    Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                    intent.putExtra("AVMixer", 1); // for pick video use 1 for AVMixer
                    startActivity(intent);
                }
            }
        });

        iv_AudioCutter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndRequestPermissions(222)) {
                    cuttermusuicopen();
                }
            }
        });

        iv_V2A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndRequestPermissions(333)) {
                    Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                    intent.putExtra("V2A", 3);
                    startActivity(intent);
                }
            }
        });

        iv_VideoCutter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndRequestPermissions(444)) {
                    Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                    intent.putExtra("VideoCutter", 4);
                    startActivity(intent);
                }
            }
        });

        iv_VideoMotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkAndRequestPermissions(555)) {
                    Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                    intent.putExtra("VideoMotion", 5);
                    startActivity(intent);
                }
            }
        });

        iv_StatusSaver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkAndRequestPermissions(666)) {
                    opnWa();
                }

            }
        });

    }

    private void showDialogOK(DialogInterface.OnClickListener okListener) {

        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setMessage("You need to allow access to the permissions.")
                .setCancelable(false)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", okListener);
        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void askPermissionNewWhatuup() {
        StorageManager storageManager = (StorageManager) getSystemService(STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        String targetDirectory = newWhatuup(); // add your directory to be selected by the user
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        scheme += "%3A" + targetDirectory;
        uri = Uri.parse(scheme);
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        startActivityForResult(intent, 101);

    }

    private String newWhatuup() {
        String newWhatuupPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses";
        if (new File(newWhatuupPath).exists()) {
            finalPath = "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        }
        return finalPath;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void askPermissionNewWhatuupBusiness() {
        StorageManager storageManager = (StorageManager) getSystemService(STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        String targetDirectory = newWhatuupBusiness(); // add your directory to be selected by the user
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        scheme += "%3A" + targetDirectory;
        uri = Uri.parse(scheme);
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        startActivityForResult(intent, 101);

    }

    private String newWhatuupBusiness() {
        String newBusinessPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses";
        if (new File(newBusinessPath).exists()) {
            finalPath = "Android%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp Business%2FMedia%2F.Statuses";
        }
        return finalPath;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == 101 && resultCode == -1) {
            Uri data = intent.getData();

            try {
                getContentResolver().takePersistableUriPermission(data, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (appInstalledOrNot("com.whatsapp") && appInstalledOrNot("com.whatsapp.w4b")) {
                if (data.toString().contains("20Business")) {

                    if (data.toString().contains("20Business%2FMedia%2F.Statuses")) {
                        SharedPreferences preferences = getApplicationContext().getSharedPreferences("WBPermissionSP", Context.MODE_PRIVATE);
                        String WB_Value = preferences.getString("WBValuePermission", "");
                        if (WB_Value.isEmpty()) {
                            SharedPreferences SP_WB = getApplicationContext().getSharedPreferences("WBPermissionSP", MODE_PRIVATE);
                            SharedPreferences.Editor editor_WB = SP_WB.edit();
                            editor_WB.putString("WBValuePermission", data.toString());
                            editor_WB.apply();

                            Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                            intent_StatusSaver.putExtra("WBVal", 1);
                            startActivity(intent_StatusSaver);

                        }
                    }

                } else {

                    if (data.toString().contains("WhatsApp%2FMedia%2F.Statuses")) {
                        SharedPreferences preferences_W = getApplicationContext().getSharedPreferences("PermissionSP", Context.MODE_PRIVATE);
                        String W_Value = preferences_W.getString("WaValuePermission", "");
                        if (W_Value.isEmpty()) {

                            SharedPreferences sp = getApplicationContext().getSharedPreferences("PermissionSP", MODE_PRIVATE);
                            SharedPreferences.Editor editor2 = sp.edit();
                            editor2.putString("WaValuePermission", data.toString());
                            editor2.apply();

                            Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                            intent_StatusSaver.putExtra("WVal", 2);
                            startActivity(intent_StatusSaver);

                        }
                    }

                }
            } else {
                if (appInstalledOrNot("com.whatsapp.w4b")) {

                    if (data.toString().contains("20Business%2FMedia%2F.Statuses")) {
                        SingleWhatszUp = false;

                        SharedPreferences SP_WB = getApplicationContext().getSharedPreferences("OnePermissionWB", MODE_PRIVATE);
                        SharedPreferences.Editor editor_WB = SP_WB.edit();
                        editor_WB.putString("OnePermissionWBValue", data.toString());
                        editor_WB.apply();

                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("OneVal", 4);

                        startActivity(intent_StatusSaver);
                    }

                }

                if (appInstalledOrNot("com.whatsapp")) {

                    if (data.toString().contains("WhatsApp%2FMedia%2F.Statuses")) {
                        SingleWhatszUp = true;

                        SharedPreferences SP_WB = getApplicationContext().getSharedPreferences("OnePermissionW", MODE_PRIVATE);
                        SharedPreferences.Editor editor_WB = SP_WB.edit();
                        editor_WB.putString("OnePermissionWValue", data.toString());
                        editor_WB.apply();

                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("OneVal", 3);

                        startActivity(intent_StatusSaver);
                    }
                }
            }

        }
    }

    private boolean checkAndRequestPermissions(int val) {

        int writePerm = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int readPerm = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE);

        List<String> listPermissionsNeeded = new ArrayList<>();
        if (writePerm != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (readPerm != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                    val);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        actionINF(permissions, grantResults, requestCode);
    }

    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (showDialog) {
            buttons.setVisibility(View.GONE);
            dialogSaver.setVisibility(View.VISIBLE);
            showDialog = false;
        } else if (dialogSaver.getVisibility() == View.VISIBLE) {
            dialogSaver.setVisibility(View.GONE);
            buttons.setVisibility(View.VISIBLE);
        }

        closeDrawer();

    }

    @Override
    public void onBackPressed() {

        closeDrawer();

        if (dialogSaver.getVisibility() == View.VISIBLE) {
            dialogSaver.setVisibility(View.GONE);
            buttons.setVisibility(View.VISIBLE);
        } else if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            closeDrawer();
        } else {
            finish();
        }

    }

    private void toggleDrawer() {
        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.open, R.string.close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
    }

    private void closeDrawer() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public void opnWa() {
        if (appInstalledOrNot("com.whatsapp") && appInstalledOrNot("com.whatsapp.w4b")) {

            if (!alreadySelected) {
                Log.e("TAG", "opnWa: jhghjghjghjghjghjghjghj");
                buttons.setVisibility(View.GONE);
                dialogSaver.setVisibility(View.VISIBLE);

                unselect_wa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selected_wa.setVisibility(View.VISIBLE);
                        unselect_wa.setVisibility(View.GONE);
                        selected_wb.setVisibility(View.GONE);
                        unselect_wb.setVisibility(View.VISIBLE);
                        WhatszUp = true;
                        iv_select.setVisibility(View.VISIBLE);
                    }
                });

                unselect_wb.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selected_wb.setVisibility(View.VISIBLE);
                        unselect_wb.setVisibility(View.GONE);
                        selected_wa.setVisibility(View.GONE);
                        unselect_wa.setVisibility(View.VISIBLE);
                        WhatszUp = false;
                        iv_select.setVisibility(View.VISIBLE);
                    }
                });

                iv_select.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        alreadySelected = true;

                        if (WhatszUp) {
                            if (appInstalledOrNot("com.whatsapp")) {
                                alreadySelectedB = false;
                                if (SDK_INT >= Build.VERSION_CODES.R) {
                                    SharedPreferences preferences_W = getApplicationContext().getSharedPreferences("PermissionSP", Context.MODE_PRIVATE);
                                    String W_Value = preferences_W.getString("WaValuePermission", "");
                                    if (W_Value.trim().isEmpty()) {
                                        askPermissionNewWhatuup();
                                    } else {
                                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                                        intent_StatusSaver.putExtra("WVal", 2);
                                        startActivity(intent_StatusSaver);
                                    }
                                } else {
                                    finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses";
                                    SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                                    SharedPreferences.Editor editor2 = sp.edit();
                                    editor2.putString("OldValuePermission", finalPath);
                                    editor2.apply();
                                    Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                                    intent_StatusSaver.putExtra("DoubleWVal", 12);
                                    startActivity(intent_StatusSaver);
                                }
                            }
                        } else {
                            if (appInstalledOrNot("com.whatsapp.w4b")) {
                                alreadySelectedB = true;
                                if (SDK_INT >= Build.VERSION_CODES.R) {
                                    SharedPreferences preferences = getApplicationContext().getSharedPreferences("WBPermissionSP", Context.MODE_PRIVATE);
                                    String WB_Value = preferences.getString("WBValuePermission", "");
                                    if (WB_Value.isEmpty()) {
                                        askPermissionNewWhatuupBusiness();
                                    } else {
                                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                                        intent_StatusSaver.putExtra("WBVal", 1);
                                        startActivity(intent_StatusSaver);
                                    }
                                } else {
                                    finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp Business/Media/.Statuses";
                                    SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                                    SharedPreferences.Editor editor2 = sp.edit();
                                    editor2.putString("OldValuePermission", finalPath);
                                    editor2.apply();
                                    Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                                    intent_StatusSaver.putExtra("DoubleWBVal", 11);
                                    startActivity(intent_StatusSaver);
                                }
                            }
                        }

                    }
                });

            } else {

                if (alreadySelectedB) {
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        SharedPreferences preferences = getApplicationContext().getSharedPreferences("WBPermissionSP", Context.MODE_PRIVATE);
                        String WB_Value = preferences.getString("WBValuePermission", "");
                        if (WB_Value.isEmpty()) {
                            askPermissionNewWhatuupBusiness();
                        } else {
                            Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                            intent_StatusSaver.putExtra("WBVal", 1);
                            startActivity(intent_StatusSaver);
                        }
                    } else {
                        finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp Business/Media/.Statuses";
                        SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                        SharedPreferences.Editor editor2 = sp.edit();
                        editor2.putString("OldValuePermission", finalPath);
                        editor2.apply();
                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("DoubleWBVal", 11);
                        startActivity(intent_StatusSaver);
                    }
                } else {
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        SharedPreferences preferences_W = getApplicationContext().getSharedPreferences("PermissionSP", Context.MODE_PRIVATE);
                        String W_Value = preferences_W.getString("WaValuePermission", "");
                        Log.d("crtgf2", "onClick: " + W_Value);
                        if (W_Value.trim().isEmpty()) {
                            Log.d("crtgf2", "onClick: 1");
                            askPermissionNewWhatuup();
                        } else {
                            Log.d("crtgf2", "onClick: 2");
                            Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                            intent_StatusSaver.putExtra("WVal", 2);
                            startActivity(intent_StatusSaver);
                        }
                    } else {
                        finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses";
                        SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                        SharedPreferences.Editor editor2 = sp.edit();
                        editor2.putString("OldValuePermission", finalPath);
                        editor2.apply();
                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("DoubleWVal", 12);
                        startActivity(intent_StatusSaver);
                    }
                }

            }

        } else {
            if (appInstalledOrNot("com.whatsapp")) {

                SingleWhatszUp = true;

                if (SDK_INT >= Build.VERSION_CODES.R) {
                    SharedPreferences preferences = getApplicationContext().getSharedPreferences("OnePermissionW", Context.MODE_PRIVATE);
                    String WB_Value = preferences.getString("OnePermissionWValue", "");
                    if (WB_Value.isEmpty()) {
                        askPermissionNewWhatuup();
                    } else {
                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("OneVal", 3);
                        startActivity(intent_StatusSaver);
                    }
                } else {
                    finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses";
                    SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                    SharedPreferences.Editor editor2 = sp.edit();
                    editor2.putString("OldValuePermission", finalPath);
                    editor2.apply();
                    Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                    intent_StatusSaver.putExtra("below11W", 14);
                    startActivity(intent_StatusSaver);
                }
            } else if (appInstalledOrNot("com.whatsapp.w4b")) {

                SingleWhatszUp = false;

                if (SDK_INT >= Build.VERSION_CODES.R) {
                    SharedPreferences preferences = getApplicationContext().getSharedPreferences("OnePermissionWB", Context.MODE_PRIVATE);
                    String WB_Value = preferences.getString("OnePermissionWBValue", "");
                    if (WB_Value.isEmpty()) {
                        askPermissionNewWhatuupBusiness();
                    } else {
                        Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                        intent_StatusSaver.putExtra("OneVal", 4);
                        startActivity(intent_StatusSaver);
                    }
                } else {
                    finalPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp Business/Media/.Statuses";
                    SharedPreferences sp = getApplicationContext().getSharedPreferences("OldPermissionSP", MODE_PRIVATE);
                    SharedPreferences.Editor editor2 = sp.edit();
                    editor2.putString("OldValuePermission", finalPath);
                    editor2.apply();
                    Intent intent_StatusSaver = new Intent(MainActivity.this, StatusSaver_Activity.class);
                    intent_StatusSaver.putExtra("below11WB", 13);
                    startActivity(intent_StatusSaver);
                }
            } else {
                Toast.makeText(MainActivity.this, "Not Installed WhatszUp", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void actionINF(String[] permissions, int[] grantResults, int code) {
        try {
            Map<String, Integer> permsLogin = new HashMap<>();
            permsLogin.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            permsLogin.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);

            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    permsLogin.put(permissions[i], grantResults[i]);
                if (permsLogin.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                        && permsLogin.get(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                                || shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                            showDialogOK((dialog, which) -> {
                                switch (which) {
                                    case DialogInterface.BUTTON_POSITIVE:
                                        checkAndRequestPermissions(code);
                                        break;
                                    case DialogInterface.BUTTON_NEGATIVE:
                                        break;
                                }
                            });
                        } else {
                            Toast.makeText(getApplicationContext(), "Go to settings and enable permissions.", Toast.LENGTH_LONG).show();

                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setMessage("We need to Access Storage Permission for performing necessary task. Please permit the permission through "
                                    + "Settings screen.\n\nSelect Permissions -> Enable permission");
                            builder.setCancelable(false);
                            builder.setPositiveButton("Permit Manually", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    Intent intent = new Intent();
                                    intent.setAction(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                }
                            });
                            builder.setNegativeButton("Cancel", null);
                            builder.show();

                        }
                    }

                } else {

                    if (code == 111) {
                        Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                        intent.putExtra("AVMixer", 1); // for pick video use 1 for AVMixer
                        startActivity(intent);
                    } else if (code == 222) {
                        cuttermusuicopen();
                    } else if (code == 333) {
                        if (checkAndRequestPermissions(333)) {
                            Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                            intent.putExtra("V2A", 3);
                            startActivity(intent);
                        }
                    } else if (code == 444) {
                        if (checkAndRequestPermissions(444)) {
                            Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                            intent.putExtra("VideoCutter", 4);
                            startActivity(intent);
                        }
                    } else if (code == 555) {
                        if (checkAndRequestPermissions(555)) {
                            Intent intent = new Intent(MainActivity.this, SelectVideoFile_Activity.class);
                            intent.putExtra("VideoMotion", 5);
                            startActivity(intent);
                        }
                    } else if (code == 666) {

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                opnWa();
                            }
                        }, 100);

                    }

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cuttermusuicopen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.System.canWrite(getApplicationContext())) {
                Intent intent = new Intent(MainActivity.this, SelectAudioFile_Activity.class);
                intent.putExtra("AudioCutter", 2); // for pick audio use 2 for AudioCutter
                startActivity(intent);

            } else {

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.alet_layout, null);
                builder.setView(view);

                ImageView no = view.findViewById(R.id.no);
                ImageView yes = view.findViewById(R.id.yes);

                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

                alertDialog.show();

                no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });

                yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS);
                        intent.setData(Uri.parse("package:" + getApplicationContext().getPackageName()));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        alertDialog.dismiss();
                    }
                });

            }
        }
    }

}