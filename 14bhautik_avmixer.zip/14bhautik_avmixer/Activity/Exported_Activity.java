package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;

public class Exported_Activity extends AppCompatActivity {

    ImageView iv_myFiles, iv_home, iv_shareFile, progressCircle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exported);

        iv_myFiles = findViewById(R.id.iv_myFiles);
        iv_home = findViewById(R.id.iv_home);
        iv_shareFile = findViewById(R.id.iv_shareFile);
        progressCircle = findViewById(R.id.progressCircle);

        iv_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Exported_Activity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        Intent intent = getIntent();
        String filePath = intent.getStringExtra("VideoTrimmerVideoPath");
        int val = intent.getIntExtra("value", 0);

        if (val == 1) {
            progressCircle.setBackgroundResource(R.drawable.v2m_progress);
        } else if (val == 0) {
            progressCircle.setBackgroundResource(R.drawable.vc_progress);
        } else if (val == 2) {
            progressCircle.setBackgroundResource(R.drawable.motion_progress);
        } else if (val == 22) {
            progressCircle.setBackgroundResource(R.drawable.vc_progress);
        } else if (val == 33) {
            progressCircle.setBackgroundResource(R.drawable.vc_progress);
        }

        iv_shareFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                File file = new File(filePath);
                Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".fileProvider", file);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));

            }
        });

        iv_myFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val == 33) {
                    Intent intent = new Intent(Exported_Activity.this, myCreation_Videos_Activity.class);
                    intent.putExtra("Value", 4);
                    startActivity(intent);
                } else if (val == 0) {
                    Intent intent = new Intent(Exported_Activity.this, myCreation_Videos_Activity.class);
                    intent.putExtra("Value", 3);
                    startActivity(intent);
                } else if (val == 2) {
                    Intent intent = new Intent(Exported_Activity.this, myCreation_Videos_Activity.class);
                    intent.putExtra("Value", 2);
                    startActivity(intent);
                } else if (val == 1) {
                    Intent intent = new Intent(Exported_Activity.this, myCreation_Audio_Activity.class);
                    intent.putExtra("Value", 1);
                    startActivity(intent);
                } else if (val == 22) {
                    Intent intent = new Intent(Exported_Activity.this, myCreation_Audio_Activity.class);
                    intent.putExtra("Value", 0);
                    startActivity(intent);
                }

                deleteV2A_videoFiles();
                deleteVM_videoFiles();

            }
        });

    }

    public void deleteV2A_videoFiles() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/AVMixerV2A/");
            if (dir.exists()) {
                if (dir.isDirectory()) {
                    String[] children = dir.list();
                    for (int i = 0; i < children.length; i++) {
                        new File(dir, children[i]).delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteVM_videoFiles() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/AVMixerVideoCutterMotion/");
            if (dir.exists()) {
                if (dir.isDirectory()) {
                    String[] children = dir.list();
                    for (int i = 0; i < children.length; i++) {
                        new File(dir, children[i]).delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {


        finish();

    }
}