package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.myCreation_video;
import com.si_avmixer.bhautik_avmixer.Model.myCreationVideo_Model;
import com.si_avmixer.bhautik_avmixer.R;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import static com.si_avmixer.bhautik_avmixer.Activity.myCreation_Activity.fromCreation;

public class myCreation_Videos_Activity extends AppCompatActivity implements myCreation_video.Pos {

    String downlaods;
    ImageView iv_back_myfiles;
    RecyclerView rv_mycreationvideo;
    ArrayList<myCreationVideo_Model> videoList;
    myCreation_video adapter;
    TextView tv_videoCutter, tv_motionEditor, tv_note, tv_avmixer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation_videos);

        rv_mycreationvideo = findViewById(R.id.rv_mycreationvideo);
        tv_videoCutter = findViewById(R.id.tv_videoCutter);
        tv_motionEditor = findViewById(R.id.tv_motionEditor);
        iv_back_myfiles = findViewById(R.id.iv_back_myfiles);
        tv_note = findViewById(R.id.tv_note);
        tv_avmixer = findViewById(R.id.tv_avmixer);

        videoList = new ArrayList<>();

        Intent intent = getIntent();
        int Val = intent.getIntExtra("Value", 0);

        if (Val == 2) {
            downlaods = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/avmixerslowvideo";
            tv_motionEditor.setVisibility(View.VISIBLE);
            tv_videoCutter.setVisibility(View.GONE);
        } else if (Val == 3) {
            downlaods = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/AVMixerVideoCutter";
            tv_motionEditor.setVisibility(View.GONE);
            tv_videoCutter.setVisibility(View.VISIBLE);
        } else if (Val == 4) {
            tv_motionEditor.setVisibility(View.GONE);
            tv_avmixer.setVisibility(View.VISIBLE);
            downlaods = (getExternalFilesDir("").toString() + "/AVMixer/VideoAudioMixer/");
        }

        iv_back_myfiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        loadData();

    }

    public void loadData() {
        try {
            String filePath = String.valueOf(downlaods);
            File file = new File(filePath);
            File[] files = file.listFiles();
            if (files != null) {


                Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                for (File file1 : files) {
                    if (file1.getPath().endsWith(".mp4")) {

                        long sizeInBytes = file1.length();
                        long sizeInMb = sizeInBytes / (1024 * 1024);

                        if (Math.toIntExact(sizeInMb) == 0) {
                            sizeInMb = 1;
                        }

                        try {
                            MediaPlayer mp = MediaPlayer.create(myCreation_Videos_Activity.this, Uri.parse(file1.getAbsolutePath()));
                            long duration = mp.getDuration();
                            videoList.add(new myCreationVideo_Model(file1.getPath(), file1.getName(), Math.toIntExact(sizeInMb), Math.toIntExact(duration)));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            }

            if (videoList.size() == 0) {
                tv_note.setVisibility(View.VISIBLE);
                rv_mycreationvideo.setVisibility(View.GONE);
            } else {
                tv_note.setVisibility(View.GONE);
                rv_mycreationvideo.setVisibility(View.VISIBLE);
            }

            adapter = new myCreation_video(videoList, getApplicationContext(), this::onClick);
            rv_mycreationvideo.setLayoutManager(new LinearLayoutManager(this));
            rv_mycreationvideo.setItemAnimator(new DefaultItemAnimator());
            rv_mycreationvideo.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            videoList.clear();
            loadData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Rect locateView(View v) {
        int[] loc_int = new int[2];
        if (v == null) return null;
        try {
            v.getLocationOnScreen(loc_int);
        } catch (NullPointerException npe) {
            return null;
        }
        Rect location = new Rect();
        location.left = loc_int[0];
        location.top = loc_int[1];
        location.right = location.left + v.getWidth();
        location.bottom = location.top + v.getHeight();
        return location;
    }

    @Override
    public void onClick(int positions, View v, String url) {
        View popUpView = getLayoutInflater().inflate(R.layout.menu_popup,
                null);
        PopupWindow mpopupVideo;

        mpopupVideo = new PopupWindow(popUpView, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        mpopupVideo.setAnimationStyle(android.R.style.Animation_Dialog);

        Rect location = locateView(v);
        mpopupVideo.showAtLocation(v, Gravity.TOP | Gravity.RIGHT, 50, location.bottom);

        LinearLayout linearLayoutDelete = popUpView.findViewById(R.id.iv_delete);
        LinearLayout linearLayoutShare = popUpView.findViewById(R.id.iv_share);

        linearLayoutDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(myCreation_Videos_Activity.this);
                dialog.setContentView(R.layout.delete_confirmation);
                dialog.setTitle("Title");

                ImageView delete = dialog.findViewById(R.id.iv_deleteCreation);
                ImageView close = dialog.findViewById(R.id.iv_closeDialog);

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        File fdelete = new File(url);
                        if (fdelete.exists()) {
                            if (fdelete.delete()) {
                                Toast.makeText(getApplicationContext(), "file Deleted", Toast.LENGTH_SHORT).show();
                                videoList.clear();
                                loadData();
                                mpopupVideo.dismiss();
                                dialog.dismiss();
                            } else {
                                Toast.makeText(getApplicationContext(), "file not Deleted", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                });

                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();


            }
        });

        linearLayoutShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(url);
                Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".fileProvider", file);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

    }

    @Override
    public void onBackPressed() {

//        if (fromCreation) {
//            Intent intent1 = new Intent(myCreation_Videos_Activity.this, myCreation_Activity.class);
//            startActivity(intent1);
//            finish();
//            fromCreation = false;
//        } else {
//            Intent intent1 = new Intent(myCreation_Videos_Activity.this, myFiles_Activity.class);
//            startActivity(intent1);
            finish();
//        }
    }
}