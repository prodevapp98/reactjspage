package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.allAudio_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.selectAudioforAVMixer_adapter;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.R;
import com.si_avmixer.bhautik_avmixer.otherClass.CustDialog;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import static com.si_avmixer.bhautik_avmixer.Adapter.selectAudioforAVMixer_adapter.mPlayer;

public class SelectAudioForAVMixer extends AppCompatActivity {

    CustDialog custDialog;
    RecyclerView rv_selectAudioAvMixer;
    ArrayList<allAudio_Model> allAudioArrayList = new ArrayList();
    selectAudioforAVMixer_adapter adapter;
    TextView tv_selectedbyadapterName;
    ImageView iv_Done, iv_back_selectOverlayAudio;
    public static String selectedUrl = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_audio_for_avmixer);

        custDialog = new CustDialog(this);

        rv_selectAudioAvMixer = findViewById(R.id.rv_selectAudioAvMixer);
        tv_selectedbyadapterName = findViewById(R.id.tv_selectedbyadapterName);
        iv_Done = findViewById(R.id.iv_Done);
        iv_back_selectOverlayAudio = findViewById(R.id.iv_back_selectOverlayAudio);

        iv_back_selectOverlayAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        rv_selectAudioAvMixer.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        rv_selectAudioAvMixer.setItemAnimator(new DefaultItemAnimator());
        allAudioArrayList = new ArrayList<>();

        MyTask myTask = new MyTask();
        myTask.execute("");

        iv_Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedUrl == null){
                    Toast.makeText(SelectAudioForAVMixer.this, "Audio not Selected", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SelectAudioForAVMixer.this, "Audio Selected", Toast.LENGTH_SHORT).show();
                    Intent intent1 = new Intent(Intent.ACTION_EDIT, Uri.parse(selectedUrl));
                    intent1.putExtra("was_get_content_intent", false);
                    intent1.putExtra("AVMixerValue", 101);
                    intent1.setClassName(getApplicationContext(), "com.si_avmixer.bhautik_avmixer.Waveformview.RingdroidEditActivity");
                    intent1.setAction("android.intent.action.EDIT");
                    startActivity(intent1);
                    mPlayer.stop();
                }


            }

        });

    }

    private class MyTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            custDialog.showDialog("Please Wait!");
        }

        @Override
        protected String doInBackground(String... strings) {

            ContentResolver contentResolver = getApplicationContext().getContentResolver();
            Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

            Cursor cursor = contentResolver.query(uri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                    String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                    String size = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.SIZE));
                    String data = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                    allAudio_Model allAudio_model = new allAudio_Model();
                    allAudio_model.setAudioTitle(title);
                    allAudio_model.setAudioUri(Uri.parse(data));
                    allAudio_model.setAudioSize(size);
                    allAudio_model.setDurationNoFormat(duration);
                    allAudio_model.setAudioDuration(Utils.Companion.getDuration(data));

                    if (data.endsWith(".mp3") && !Utils.Companion.getDuration(data).equals("0")) {
                        allAudioArrayList.add(allAudio_model);
                    }

                } while (cursor.moveToNext());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (allAudioArrayList != null) {
                custDialog.hideDialog();
                adapter = new selectAudioforAVMixer_adapter(getApplicationContext(), allAudioArrayList);
                rv_selectAudioAvMixer.setAdapter(adapter);

                adapter.setOnItemClickListener(new selectAudioforAVMixer_adapter.onItemClickListener() {
                    @Override
                    public void onItemClickListener(int position, String url, String name) {
                        tv_selectedbyadapterName.setText(name);
                        selectedUrl = url;
                    }
                });
            } else {
                custDialog.showDialog("Please Wait!");
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (mPlayer != null && mPlayer.isPlaying()){
            mPlayer.stop();
        }
    }
}