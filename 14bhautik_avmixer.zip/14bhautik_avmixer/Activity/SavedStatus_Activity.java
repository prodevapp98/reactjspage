package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.ViewPager_Adapter_forSave;
import com.si_avmixer.bhautik_avmixer.Adapter.ViewPager_Adapter_forSaved;
import com.si_avmixer.bhautik_avmixer.Adapter.download_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Download_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import static com.si_avmixer.bhautik_avmixer.Activity.MainActivity.WhatszUp;
import static com.si_avmixer.bhautik_avmixer.Activity.myFiles_Activity.WhatszUpFile;

public class SavedStatus_Activity extends AppCompatActivity {

    TextView tv_video, tv_image;
    ImageView indicator_image,indicator_video,btn_back_SavedStataus;

    TextView tv_title;
    ViewPager viewPager_downloaded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_status);

        tv_title = findViewById(R.id.tv_title);
        tv_image  = findViewById(R.id.tv_image);
        tv_video = findViewById(R.id.tv_video);

        indicator_image = findViewById(R.id.indicator_image);
        indicator_video = findViewById(R.id.indicator_video);
        btn_back_SavedStataus = findViewById(R.id.btn_back_SavedStataus);

        viewPager_downloaded = findViewById(R.id.viewPager_downloaded);

        tv_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager_downloaded.setCurrentItem(0);
            }
        });

        tv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager_downloaded.setCurrentItem(1);
            }
        });

        ViewPager_Adapter_forSaved adapter = new ViewPager_Adapter_forSaved(getApplicationContext(), getSupportFragmentManager(), 2);
        viewPager_downloaded.setAdapter(adapter);
        viewPager_downloaded.setOffscreenPageLimit(2);
        viewPager_downloaded.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                pageChange(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        btn_back_SavedStataus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if (WhatszUpFile) {
            tv_title.setText("Saved Status WhatszUp");
        } else {
            tv_title.setText("Saved Status WBusiness");
        }
    }

    private void pageChange(int position) {

        if (position == 0) {
            tv_video.setTextColor(Color.parseColor("#003E9B"));
            tv_image.setTextColor(Color.parseColor("#A1C7FF"));
            indicator_image.setVisibility(View.GONE);
            indicator_video.setVisibility(View.VISIBLE);
        } else if (position == 1) {
            tv_video.setTextColor(Color.parseColor("#A1C7FF"));
            tv_image.setTextColor(Color.parseColor("#003E9B"));
            indicator_image.setVisibility(View.VISIBLE);
            indicator_video.setVisibility(View.GONE);
        }
    }

}