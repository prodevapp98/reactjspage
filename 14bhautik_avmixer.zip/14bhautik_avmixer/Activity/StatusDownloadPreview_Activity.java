package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;

public class StatusDownloadPreview_Activity extends AppCompatActivity {

    ConstraintLayout const_const;
    ImageView iv_showDownloadImage;
    VideoView vv_showDownloadVideo;

    ImageView play_Video, pause_Video;
    ImageView btn_back_preview;
    ImageView iv_share_preview, iv_delete_preview;
    boolean whereFrom;
    String filePath;
    String filePath2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_status_download_preview);

        Intent intent = getIntent();
        filePath = intent.getStringExtra("StatusDownloadImagePath");
        filePath2 = intent.getStringExtra("StatusDownloadImagePath");
        whereFrom = intent.getBooleanExtra("fromDownload", false);

        vv_showDownloadVideo = findViewById(R.id.vv_showDownloadVideo);
        iv_showDownloadImage = findViewById(R.id.iv_showDownloadImage);
        play_Video = findViewById(R.id.iv_playDownload);
        pause_Video = findViewById(R.id.iv_pauseDownload);
        btn_back_preview = findViewById(R.id.btn_back_preview);
        const_const = findViewById(R.id.const_const);

        iv_delete_preview = findViewById(R.id.iv_delete_preview);
        iv_share_preview = findViewById(R.id.iv_share_preview);

        if (filePath.contains(".mp4")) {

            vv_showDownloadVideo.setVisibility(View.VISIBLE);
            iv_showDownloadImage.setVisibility(View.VISIBLE);



            if (whereFrom) {
                vv_showDownloadVideo.setVideoURI(Uri.parse(filePath));
                iv_delete_preview.setVisibility(View.VISIBLE);
                iv_share_preview.setVisibility(View.VISIBLE);

            } else {
                if (!filePath2.isEmpty()) {
                    vv_showDownloadVideo.setVideoURI(Uri.parse(filePath2));

                }
            }

            vv_showDownloadVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {

                    AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                    int result = am.requestAudioFocus(focusChangeListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN);
                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        vv_showDownloadVideo.setZOrderOnTop(true);
                        vv_showDownloadVideo.start();
                        play_Video.setVisibility(View.GONE);
                        pause_Video.setVisibility(View.VISIBLE);
                    }
                }
            });

            vv_showDownloadVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    play_Video.setVisibility(View.VISIBLE);
                    pause_Video.setVisibility(View.GONE);
                }
            });

            play_Video.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                    int result = am.requestAudioFocus(focusChangeListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN);
                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        vv_showDownloadVideo.start();
                    }
                    play_Video.setVisibility(View.GONE);
                    pause_Video.setVisibility(View.VISIBLE);
                }
            });

            pause_Video.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vv_showDownloadVideo.pause();
                    play_Video.setVisibility(View.VISIBLE);
                    pause_Video.setVisibility(View.GONE);
                }
            });

        } else {
            pause_Video.setVisibility(View.GONE);
            iv_showDownloadImage.setVisibility(View.VISIBLE);
            vv_showDownloadVideo.setVisibility(View.GONE);
            const_const.setVisibility(View.GONE);
            Glide.with(getApplicationContext()).load(filePath).into(iv_showDownloadImage);
        }

        btn_back_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        iv_share_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(filePath);
                Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".fileProvider", file);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

        iv_delete_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (filePath.contains(".jpg") || filePath.contains(".png")) {
                    File fdelete = new File(filePath);
                    if (fdelete.exists()) {
                        if (fdelete.delete()) {
                            finish();
                            Toast.makeText(getApplicationContext(), "file Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "file not Deleted", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    File fdelete = new File(filePath);
                    if (fdelete.exists()) {
                        if (fdelete.delete()) {
                            finish();
                            Toast.makeText(getApplicationContext(), "file Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "file not Deleted", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });

    }

    AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {
                    AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                    switch (focusChange) {
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            vv_showDownloadVideo.pause();
                            pause_Video.setVisibility(View.GONE);
                            play_Video.setVisibility(View.VISIBLE);
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            vv_showDownloadVideo.pause();
                            pause_Video.setVisibility(View.GONE);
                            play_Video.setVisibility(View.VISIBLE);
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS):
                            vv_showDownloadVideo.pause();
                            pause_Video.setVisibility(View.GONE);
                            play_Video.setVisibility(View.VISIBLE);
                            break;
                        case (AudioManager.AUDIOFOCUS_GAIN):
                            break;
                        default:
                            break;
                    }
                }
            };

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}