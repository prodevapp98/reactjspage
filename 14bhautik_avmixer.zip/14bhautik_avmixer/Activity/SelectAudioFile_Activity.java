package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.service.autofill.VisibilitySetterAction;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.allAudio_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.allVideo_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.audioFolder_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.videoFolder_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.FolderModel;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.Model.allVideo_Model;
import com.si_avmixer.bhautik_avmixer.Model.audioFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;
import com.si_avmixer.bhautik_avmixer.otherClass.CustDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class SelectAudioFile_Activity extends AppCompatActivity {

    RelativeLayout allAudio,Folders;
    LinearLayout linlay_rv_allaudio,linlay_rv_allFolders;
    TextView tv_visibleFolder, tv_visibleAudio;

    RecyclerView rv_allAudios;
    ArrayList<allAudio_Model> allAudioArrayList = new ArrayList();
    allAudio_Adapter adapter;

    ArrayList<FolderModel> audioFolders = new ArrayList<>();
    RecyclerView rv_allFolders;
    ArrayList<audioFolder_Model> allaudioFiles = new ArrayList<>();
    ArrayList<String> allAudioFolder = new ArrayList<>();
    audioFolder_Adapter adapterFolder;

    ImageView btn_back_from_selectaudio,btn_back_from_selectaudio2;
    TextView tv_note_audio,tv_note_audioFolder;

    int adapterValue;
    CustDialog custDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_audio_file);

        Intent intent = getIntent();
        int Value = intent.getIntExtra("AudioCutter",0);
        if (Value == 2){
            adapterValue = Value;
        }

        custDialog = new CustDialog(this);

        allAudio = findViewById(R.id.allAudio);
        Folders = findViewById(R.id.Folders);

        tv_note_audio = findViewById(R.id.tv_note_audio);
        tv_note_audioFolder = findViewById(R.id.tv_note_audioFolder);

        tv_visibleFolder = findViewById(R.id.visibleFolder);
        tv_visibleAudio = findViewById(R.id.tv_visibleAudio);

        linlay_rv_allaudio = findViewById(R.id.linlay_rv_allaudio);
        linlay_rv_allFolders = findViewById(R.id.linlay_rv_allFolders);

        rv_allAudios = findViewById(R.id.rv_allAudios);
        rv_allFolders = findViewById(R.id.rv_allFolders);

        btn_back_from_selectaudio = findViewById(R.id.btn_back_from_selectaudio);
        btn_back_from_selectaudio2 = findViewById(R.id.btn_back_from_selectaudio2);

        btn_back_from_selectaudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_back_from_selectaudio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        tv_visibleFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allAudio.setVisibility(View.GONE);
                linlay_rv_allaudio.setVisibility(View.GONE);
                Folders.setVisibility(View.VISIBLE);
                linlay_rv_allFolders.setVisibility(View.VISIBLE);
            }
        });
        tv_visibleAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allAudio.setVisibility(View.VISIBLE);
                linlay_rv_allaudio.setVisibility(View.VISIBLE);
                Folders.setVisibility(View.GONE);
                linlay_rv_allFolders.setVisibility(View.GONE);
            }
        });

        rv_allAudios.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        rv_allAudios.setItemAnimator(new DefaultItemAnimator());
        allAudioArrayList = new ArrayList<>();

        MyTask myTask = new MyTask();
        myTask.execute("");
        showFolder();

    }


    private class MyTask extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            custDialog.showDialog("Please Wait!");
        }

        @Override
        protected String doInBackground(String... strings) {

            ArrayList<String> audioPaths = new ArrayList<>();

            ContentResolver contentResolver = getApplicationContext().getContentResolver();
            Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

            Cursor cursor = contentResolver.query(uri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                    String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                    String size = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.SIZE));
                    String data = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                    allAudio_Model allAudio_model  = new allAudio_Model();
                    allAudio_model.setAudioTitle(title);

                    allAudio_model.setAudioUri(Uri.parse(data));
                    allAudio_model.setAudioSize(String.valueOf(Utils.Companion.getFolderSize(new File(data))));
                    allAudio_model.setDurationNoFormat(duration);

                    allAudio_model.setAudioDuration(Utils.Companion.getDuration(data));

                    String folder = new File(data).getParentFile().getName();


                    if (data.endsWith(".mp3") && !Utils.Companion.getDuration(data).equals("0")) {

                        if (folder == null || folder.equals("0")) {
                            folder = "Internal Storage";
                        }

                        allAudio_model.setFolderNM(folder);

                        if (!audioPaths.contains(folder)) {
                            audioPaths.add(folder);
                            FolderModel folds = new FolderModel();
                            folds.setPath(new File(data).getParentFile().getAbsolutePath());
                            folds.setFolderName(folder);
                            audioFolders.add(folds);

                        }
                        sortAlpha();
                        allAudioArrayList.add(allAudio_model);
                    }

                } while (cursor.moveToNext());
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (allAudioArrayList.size() == 0){
                tv_note_audioFolder.setVisibility(View.VISIBLE);
                tv_note_audio.setVisibility(View.VISIBLE);
                rv_allAudios.setVisibility(View.GONE);
                rv_allFolders.setVisibility(View.GONE);
            } else {
                tv_note_audioFolder.setVisibility(View.GONE);
                tv_note_audio.setVisibility(View.GONE);
                rv_allAudios.setVisibility(View.VISIBLE);
                rv_allFolders.setVisibility(View.VISIBLE);
            }

            if (allAudioArrayList != null){
                custDialog.hideDialog();
                sortAlpha2();
                adapter = new allAudio_Adapter(getApplicationContext(),allAudioArrayList,adapterValue);
                rv_allAudios.setAdapter(adapter);
            } else {
                custDialog.showDialog("Please Wait!");
            }
        }
    }


    private void showFolder() {
        adapterFolder = new audioFolder_Adapter(audioFolders,getApplicationContext(),adapterValue);
        rv_allFolders.setAdapter(adapterFolder);
        rv_allFolders.setLayoutManager(new GridLayoutManager(this,2));
        adapterFolder.notifyDataSetChanged();
    }

    public void sortAlpha(){
        Collections.sort(audioFolders, new Comparator<FolderModel>() {
            @Override
            public int compare(FolderModel s1, FolderModel s2) {
                return s1.getFolderName().compareToIgnoreCase(s2.getFolderName());
            }
        });
    }

    public void sortAlpha2(){
        Collections.sort(allAudioArrayList, new Comparator<allAudio_Model>() {
            @Override
            public int compare(allAudio_Model o1, allAudio_Model o2) {
                return o1.getAudioTitle().compareToIgnoreCase(o2.getAudioTitle());
            }
        });
    }

}