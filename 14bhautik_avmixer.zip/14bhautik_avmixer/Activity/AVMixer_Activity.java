package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpegExecution;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;

public class AVMixer_Activity extends AppCompatActivity {

    ImageView btn_back_avMixer;
    VideoView vv_avMixer;
    MediaController mediaControls;
    ImageView iv_pause, iv_play, iv_addAudio, iv_Merge, iv_AvExport;
    SeekBar seek_video;
    TextView tv_videoTime, tv_selectedAudioName;
    public static String AudioUri;
    String videoName;
    RelativeLayout SavingAVMixerFile, dialogAV;
    ConstraintLayout avProcess;
    EditText et_nameOfAVMixer;
    String SavingPath;

    boolean processstarted = false;
    boolean closeproce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avmixer);

        Intent intent = getIntent();
        String VideoUri = intent.getExtras().getString("AVMixerVideoUrl");
        videoName = intent.getExtras().getString("AVMixerVideoName");

        iv_play = findViewById(R.id.iv_play);
        iv_pause = findViewById(R.id.iv_pause);
        SavingAVMixerFile = findViewById(R.id.SavingAVMixerFile);
        avProcess = findViewById(R.id.avProcess);
        tv_selectedAudioName = findViewById(R.id.tv_selectedAudioName);

        btn_back_avMixer = findViewById(R.id.btn_back_avMixer);
        vv_avMixer = findViewById(R.id.vv_avMixer);
        seek_video = findViewById(R.id.seek_video);
        tv_videoTime = findViewById(R.id.tv_videoTime);
        iv_addAudio = findViewById(R.id.iv_addAudio);
        iv_Merge = findViewById(R.id.iv_Merge);
        dialogAV = findViewById(R.id.dialogAV);
        et_nameOfAVMixer = findViewById(R.id.et_nameOfAVMixer);
        iv_AvExport = findViewById(R.id.iv_AvExport);

        iv_addAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(AVMixer_Activity.this, SelectAudioForAVMixer.class);
                startActivity(intent1);
            }
        });

        btn_back_avMixer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if (mediaControls == null) {
            mediaControls = new MediaController(AVMixer_Activity.this);
            mediaControls.setAnchorView(vv_avMixer);
        }
        vv_avMixer.setVideoURI(Uri.parse(VideoUri));
        vv_avMixer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                vv_avMixer.start();
                seek_video.setMax(vv_avMixer.getDuration());
                seek_video.postDelayed(onEverySecond, 1000);
            }
        });

        vv_avMixer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                iv_pause.setVisibility(View.GONE);
                iv_play.setVisibility(View.VISIBLE);
                if (!vv_avMixer.isPlaying()) {
                    if (seek_video.getProgress() > 0) {
                        seek_video.setProgress(0);
                    }
                }
            }
        });

        iv_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_play.setVisibility(View.GONE);
                iv_pause.setVisibility(View.VISIBLE);
                vv_avMixer.start();
                seek_video.setMax(vv_avMixer.getDuration());
                seek_video.postDelayed(onEverySecond, 1000);
            }
        });

        iv_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_pause.setVisibility(View.GONE);
                iv_play.setVisibility(View.VISIBLE);
                vv_avMixer.pause();
            }
        });

        seek_video.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser) {
                    vv_avMixer.seekTo(progress);
                }
            }
        });

        iv_Merge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String externalRootDir = getExternalFilesDir("/").toString();
                if (!externalRootDir.endsWith("/")) {
                    externalRootDir += "/";
                }

                String subdir = "AVMixer/VideoAudioMixer/";
                String parentdir = externalRootDir + subdir;

                File parentDirFile = new File(parentdir);
                parentDirFile.mkdirs();

                vv_avMixer.stopPlayback();
                avProcess.setVisibility(View.GONE);
                dialogAV.setVisibility(View.VISIBLE);
                et_nameOfAVMixer.setText(videoName);

                iv_AvExport.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        if (et_nameOfAVMixer.getText().toString().isEmpty()) {
                            et_nameOfAVMixer.setError("Enter Video Name");
                        } else if (et_nameOfAVMixer.getText().toString().trim().length() == 0) {
                            et_nameOfAVMixer.setError("Enter Video Name");
                        } else if ((et_nameOfAVMixer.getText().toString().trim().equals(""))) {
                            et_nameOfAVMixer.setError("Enter Video Name");
                        } else {
                            dialogAV.setVisibility(View.GONE);
                            SavingAVMixerFile.setVisibility(View.VISIBLE);

                            String VideoNewName = et_nameOfAVMixer.getText().toString();
                            SavingPath = parentdir + VideoNewName + ".mp4";
                            Log.d("3489712tgy", "onClick: " + SavingPath);

                            String[] c = {"-i", VideoUri, "-i", AudioUri,
                                    "-c:v", "copy", "-c:a", "aac", "-map", "0:v:0", "-map", "1:a:0", "-shortest",
                                    SavingPath};

                            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                            inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);


                            MergeVideo(c);

                            processstarted = true;

                        }


                    }
                });


            }
        });
    }

    String getVideoTime(long ms) {
        ms /= 1000;
        return (ms / 3600) + ":" + ((ms % 3600) / 60) + ":" + ((ms % 3600) % 60);
    }

    private Runnable onEverySecond = new Runnable() {

        @Override
        public void run() {

            if (seek_video != null) {
                seek_video.setProgress(vv_avMixer.getCurrentPosition());
                tv_videoTime.setText(getVideoTime(vv_avMixer.getCurrentPosition()));
            }

            if (vv_avMixer.isPlaying()) {
                seek_video.postDelayed(onEverySecond, 1000);
                tv_videoTime.setText(getVideoTime(vv_avMixer.getCurrentPosition()));
            }

        }
    };

    @Override
    protected void onDestroy() {
        AudioUri = null;

        SharedPreferences preferences = getSharedPreferences("MySharedPref", 0);
        SharedPreferences.Editor deleteSP = preferences.edit();
        deleteSP.putString("AudioPath", "");
        deleteSP.apply();
        super.onDestroy();


    }

    private void MergeVideo(String[] co) {
        com.arthenica.mobileffmpeg.FFmpeg
                .executeAsync(co, new ExecuteCallback() {
                    @Override
                    public void apply(long executionId, int returnCode) {

                        if (closeproce) {
                            closeproce = false;
                            processstarted = false;
                        } else {
                            SavingAVMixerFile.setVisibility(View.GONE);
                            Intent intent = new Intent(AVMixer_Activity.this, Exported_Activity.class);
                            intent.putExtra("VideoTrimmerVideoPath", SavingPath);
                            intent.putExtra("value", 33);
                            startActivity(intent);
                            finish();
                            AudioUri = null;

                            SharedPreferences preferences = getSharedPreferences("MySharedPref", 0);
                            SharedPreferences.Editor deleteSP = preferences.edit();
                            deleteSP.putString("AudioPath", "");
                            deleteSP.apply();

                            iv_Merge.setVisibility(View.GONE);
                            avProcess.setVisibility(View.VISIBLE);
                        }


                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();

        iv_play.setVisibility(View.GONE);
        iv_pause.setVisibility(View.VISIBLE);

        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        AudioUri = sh.getString("AudioPath", "");
        if (!AudioUri.isEmpty()) {
            Log.d("8923u", "onResume: " + AudioUri);
            Log.d("8923u", "onResume: " + new File(AudioUri).getAbsolutePath());

            iv_Merge.setVisibility(View.VISIBLE);
            tv_selectedAudioName.setText("Selected Song: " + new File(AudioUri).getName());
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (processstarted) {
            closeproce = true;
        }

    }
}