package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.BuildConfig;
import com.si_avmixer.bhautik_avmixer.R;

public class Start_Activity extends AppCompatActivity {

    ImageView iv_moreApps,iv_privacyPolicy,iv_rateus,iv_shareApp,iv_start;

    private long lClickTime = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        iv_start = findViewById(R.id.iv_start);
        iv_shareApp = findViewById(R.id.iv_shareApp);
        iv_rateus = findViewById(R.id.iv_rateus);
        iv_privacyPolicy = findViewById(R.id.iv_privacyPolicy);
        iv_moreApps = findViewById(R.id.iv_moreApps);

        iv_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Start_Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        iv_shareApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (SystemClock.elapsedRealtime() - lClickTime < 200) {
                    return;
                }
                lClickTime = SystemClock.elapsedRealtime();

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });

        iv_rateus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(Start_Activity.this, " Unable to find AVMixer App", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {

                }
            }
        });

        iv_privacyPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        iv_moreApps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Start_Activity.this,MoreApps_Activity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Start_Activity.this, Exit_Activity.class);
        startActivity(intent);
    }
}