package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.si_avmixer.bhautik_avmixer.Adapter.allVideo_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.videoFolder_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.FolderModel;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.Model.allVideo_Model;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;
import com.si_avmixer.bhautik_avmixer.otherClass.CustDialog;

import java.io.File;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.si_avmixer.bhautik_avmixer.Activity.AVMixer_Activity.AudioUri;

public class SelectVideoFile_Activity extends AppCompatActivity {

    RelativeLayout allVideo, VideoFolders;
    LinearLayout linlay_rv_allvideo, linlay_rv_allVideoFolders;
    TextView tv_visibleVideoFolder, tv_visibleVideo;

    RecyclerView rv_allVideos;
    public static ArrayList<allVideo_Model> allVideoArrayList = new ArrayList();
    allVideo_Adapter adapter;

    ArrayList<FolderModel> videoFolders = new ArrayList<>();
    RecyclerView rv_allVideoFolders;
    ArrayList<videoFolder_Model> allvideoFiles = new ArrayList<>();
    ArrayList<String> allVideoFolder = new ArrayList<>();
    videoFolder_Adapter adapterFolder;

    ImageView btn_back_from_selectvideo, btn_back_from_selectvideo2;
    int adapterValue;

    CustDialog custDialog;
    TextView tv_note_video, tv_note_videoFolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_video_file);

        Intent intent = getIntent();
        int Value = intent.getIntExtra("AVMixer", 0);
        int videoCutter = intent.getIntExtra("VideoCutter", 0);
        int videoToaudio = intent.getIntExtra("V2A", 0);
        int videoMotion = intent.getIntExtra("VideoMotion", 0);

        if (Value == 1) {
            adapterValue = Value;
        }

        if (videoCutter == 4) {
            adapterValue = videoCutter;
        }

        if (videoToaudio == 3) {
            adapterValue = videoToaudio;
        }

        if (videoMotion == 5) {
            adapterValue = videoMotion;
        }

        custDialog = new CustDialog(this);

        tv_note_videoFolder = findViewById(R.id.tv_note_videoFolder);
        tv_note_video = findViewById(R.id.tv_note_video);
        btn_back_from_selectvideo = findViewById(R.id.btn_back_from_selectvideo);
        btn_back_from_selectvideo2 = findViewById(R.id.btn_back_from_selectvideo2);

        btn_back_from_selectvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_back_from_selectvideo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        allVideo = findViewById(R.id.allVideo);
        VideoFolders = findViewById(R.id.VideoFolders);

        linlay_rv_allvideo = findViewById(R.id.linlay_rv_allvideo);
        linlay_rv_allVideoFolders = findViewById(R.id.linlay_rv_allVideoFolders);

        tv_visibleVideoFolder = findViewById(R.id.tv_visibleVideoFolder);
        tv_visibleVideo = findViewById(R.id.tv_visibleVideo);

        rv_allVideos = findViewById(R.id.rv_allVideos);
        rv_allVideoFolders = findViewById(R.id.rv_allVideoFolders);

        tv_visibleVideoFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allVideo.setVisibility(View.GONE);
                linlay_rv_allvideo.setVisibility(View.GONE);
                VideoFolders.setVisibility(View.VISIBLE);
                linlay_rv_allVideoFolders.setVisibility(View.VISIBLE);

            }
        });
        tv_visibleVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allVideo.setVisibility(View.VISIBLE);
                linlay_rv_allvideo.setVisibility(View.VISIBLE);
                VideoFolders.setVisibility(View.GONE);
                linlay_rv_allVideoFolders.setVisibility(View.GONE);
            }
        });

        rv_allVideos.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        rv_allVideos.setItemAnimator(new DefaultItemAnimator());
        allVideoArrayList = new ArrayList<>();

        MyTask myTask = new MyTask();
        myTask.execute("");

        showFolder();

    }

    private class MyTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            custDialog.showDialog("Please Wait!");
        }

        @Override
        protected String doInBackground(String... strings) {


            ArrayList<String> videoPaths = new ArrayList<>();

            ContentResolver contentResolver = getApplicationContext().getContentResolver();
            Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

            Cursor cursor = contentResolver.query(uri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String title = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.TITLE));
                    String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DURATION));
                    String size = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.SIZE));
                    String data = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));
                    allVideo_Model videoModel = new allVideo_Model();
                    videoModel.setVideoTitle(title);
                    videoModel.setVideoUri(Uri.parse(data));

                    videoModel.setVideoSize(String.valueOf(Utils.Companion.getFolderSize(new File(data))));
                    videoModel.setVideoDuration(Utils.Companion.getDuration(data));

                    String folder = new File(data).getParentFile().getName();

                    if (data.endsWith(".mp4") && !Utils.Companion.getDuration(data).equals("00:00") && !Utils.Companion.getDuration(data).equals("0") && !data.contains("#")) {

                        if (folder == null || folder.equals("0")) {
                            folder = "Internal Storage";
                        }

                        Log.e("gfhfgd", "doInBackground: " + Utils.Companion.getDuration(data));

                        videoModel.setFolderNM(folder);

                        if (!videoPaths.contains(folder)) {
                            videoPaths.add(folder);
                            FolderModel folds = new FolderModel();
                            folds.setPath(new File(data).getParentFile().getAbsolutePath());
                            folds.setFolderName(folder);
                            videoFolders.add(folds);
                        }

                        allVideoArrayList.add(videoModel);
                        sortAlpha();

                    }

                } while (cursor.moveToNext());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (allVideoArrayList.size() == 0) {
                tv_note_videoFolder.setVisibility(View.VISIBLE);
                tv_note_video.setVisibility(View.VISIBLE);
                rv_allVideos.setVisibility(View.GONE);
                rv_allVideoFolders.setVisibility(View.GONE);
            } else {
                tv_note_videoFolder.setVisibility(View.GONE);
                tv_note_video.setVisibility(View.GONE);
                rv_allVideos.setVisibility(View.VISIBLE);
                rv_allVideoFolders.setVisibility(View.VISIBLE);
            }

            if (allVideoArrayList != null) {
                custDialog.hideDialog();

                sortAlpha2();

                adapter = new allVideo_Adapter(getApplicationContext(), allVideoArrayList, adapterValue);
                rv_allVideos.setAdapter(adapter);
            } else {
                custDialog.showDialog("Please Wait!");
            }
        }
    }

    public void sortAlpha2() {
        Collections.sort(allVideoArrayList, new Comparator<allVideo_Model>() {
            @Override
            public int compare(allVideo_Model o1, allVideo_Model o2) {
                return o1.getVideoTitle().compareToIgnoreCase(o2.getVideoTitle());
            }
        });
    }

    private void showFolder() {
        adapterFolder = new videoFolder_Adapter(videoFolders, getApplicationContext(), adapterValue);
        rv_allVideoFolders.setAdapter(adapterFolder);
        rv_allVideoFolders.setLayoutManager(new GridLayoutManager(this, 2));
        adapterFolder.notifyDataSetChanged();
    }

    public void sortAlpha() {
        Collections.sort(videoFolders, new Comparator<FolderModel>() {
            @Override
            public int compare(FolderModel s1, FolderModel s2) {
                return s1.getFolderName().compareToIgnoreCase(s2.getFolderName());
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        AudioUri = null;

        SharedPreferences preferences = getSharedPreferences("MySharedPref", 0);
        SharedPreferences.Editor deleteSP = preferences.edit();
        deleteSP.putString("AudioPath", "");
        deleteSP.apply();
    }
}