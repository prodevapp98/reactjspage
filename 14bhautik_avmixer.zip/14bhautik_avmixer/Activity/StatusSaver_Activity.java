package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.si_avmixer.bhautik_avmixer.Adapter.ViewPager_Adapter_forSave;
import com.si_avmixer.bhautik_avmixer.R;

import static com.si_avmixer.bhautik_avmixer.Activity.MainActivity.SingleWhatszUp;
import static com.si_avmixer.bhautik_avmixer.Activity.MainActivity.WhatszUp;

public class StatusSaver_Activity extends AppCompatActivity {

    ImageView iv_back_statusSaver, iv_switch;
    public static boolean showDialog = false;
    public static boolean oneTime = false;

    RecyclerView rv_SaveVideo, rv_SaveImage;
    TextView tv_noteSave;
    TextView tv_Savevideo, tv_Saveimage;
    RelativeLayout layout_SaveVideo, layout_SaveImage;

    TextView tv_title;
    ViewPager viewPager_whatzzp;
    ImageView indicator_Savevideo,indicator_Saveimage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_saver);

        iv_back_statusSaver = (ImageView) findViewById(R.id.iv_back_statusSaver);
        iv_switch = (ImageView) findViewById(R.id.iv_switch);

        tv_noteSave = findViewById(R.id.tv_noteSave);
        tv_title = findViewById(R.id.tv_title);
        rv_SaveImage = findViewById(R.id.rv_SaveImage);
        rv_SaveVideo = findViewById(R.id.rv_SaveVideo);
        tv_Saveimage = findViewById(R.id.tv_Saveimage);
        tv_Savevideo = findViewById(R.id.tv_Savevideo);

        layout_SaveVideo = findViewById(R.id.layout_SaveVideo);
        layout_SaveImage = findViewById(R.id.layout_SaveImage);

        viewPager_whatzzp = findViewById(R.id.viewPager_whatzzp);
        indicator_Savevideo = findViewById(R.id.indicator_Savevideo);
        indicator_Saveimage = findViewById(R.id.indicator_Saveimage);

        if (WhatszUp || SingleWhatszUp) {

            tv_title.setText("WhatszUp");
        } else {
            tv_title.setText("WBusiness");
        }

        tv_Saveimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager_whatzzp.setCurrentItem(1);
            }
        });

        tv_Savevideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager_whatzzp.setCurrentItem(0);
            }
        });

        ViewPager_Adapter_forSave adapter = new ViewPager_Adapter_forSave(getApplicationContext(), getSupportFragmentManager(), 2);
        viewPager_whatzzp.setAdapter(adapter);
        viewPager_whatzzp.setOffscreenPageLimit(2);
        viewPager_whatzzp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                pageChange(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        if (appInstalledOrNot("com.whatsapp") && appInstalledOrNot("com.whatsapp.w4b")) {
            iv_switch.setVisibility(View.VISIBLE);
        } else {
            iv_switch.setVisibility(View.GONE);
        }

        iv_back_statusSaver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        iv_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                showDialog = true;
            }
        });

    }
    private void pageChange(int position) {

        if (position == 0) {
            tv_Savevideo.setTextColor(Color.parseColor("#003E9B"));
            tv_Saveimage.setTextColor(Color.parseColor("#A1C7FF"));
            indicator_Saveimage.setVisibility(View.GONE);
            indicator_Savevideo.setVisibility(View.VISIBLE);
        } else if (position == 1) {
            tv_Savevideo.setTextColor(Color.parseColor("#A1C7FF"));
            tv_Saveimage.setTextColor(Color.parseColor("#003E9B"));
            indicator_Saveimage.setVisibility(View.VISIBLE);
            indicator_Savevideo.setVisibility(View.GONE);
        }
    }

    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    @Override
    protected void onResume() {
        super.onResume();


    }

    @Override
    public void onBackPressed() {
        finish();
    }

}