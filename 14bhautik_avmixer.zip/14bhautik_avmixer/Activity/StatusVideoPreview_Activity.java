package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

import static android.os.Build.VERSION.SDK_INT;
import static com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity.oneTime;

public class StatusVideoPreview_Activity extends AppCompatActivity {

    VideoView vv_preview;
    ImageView iv_back_preview;
    TextView tv_downloadNote;
    SeekBar seek_stat_video;
    ConstraintLayout const_const;
    ImageView play_Video, pause_Video, iv_download_Video, iv_share_Video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_video_preview);

        vv_preview = findViewById(R.id.vv_preview);
        iv_back_preview = findViewById(R.id.iv_back_preview);
        play_Video = findViewById(R.id.play_Video);
        pause_Video = findViewById(R.id.pause_Video);
        iv_download_Video = findViewById(R.id.iv_download_Video);
        iv_share_Video = findViewById(R.id.iv_share_Video);
        tv_downloadNote = findViewById(R.id.tv_downloadNote);
        const_const = findViewById(R.id.const_const);
        seek_stat_video = findViewById(R.id.seek_stat_video);

        oneTime = true;

        iv_back_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Intent intent = getIntent();
        String videoPath = intent.getStringExtra("StatusVideoPreview");
        String videoName = intent.getStringExtra("StatusVideoName");
        int value = intent.getIntExtra("Value", 0);

        if (CheckDownload(videoName) || CheckDownloadWB(videoName)) {
            iv_download_Video.setVisibility(View.GONE);
        } else {
            iv_download_Video.setVisibility(View.VISIBLE);
        }

        iv_download_Video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 11) {
                    createDirWB("GBWhatzUpWB", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 12) {
                    createDirW("GBWhatzUp", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 13) {
                    createDirWB("GBWhatzUpWB", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 14) {
                    createDirW("GBWhatzUp", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 2) {
                    createDirW("GBWhatzUp", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 3) {
                    createDirW("GBWhatzUp", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 1) {
                    createDirWB("GBWhatzUpWB", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 4) {
                    createDirWB("GBWhatzUpWB", "Videos");
                    Uri ImageUrl = Uri.parse(videoPath);
                    String ImageName = videoName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Videos").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath, myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                iv_download_Video.setVisibility(View.GONE);
                iv_share_Video.setVisibility(View.VISIBLE);
                tv_downloadNote.setVisibility(View.VISIBLE);

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        tv_downloadNote.setVisibility(View.GONE);
                    }
                }, 3000);

            }
        });

        iv_share_Video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(videoPath);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

        if (videoPath.contains(".mp4")) {

            vv_preview.setVideoURI(Uri.parse(videoPath));

            vv_preview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    vv_preview.setZOrderOnTop(true);
                    vv_preview.start();
                    seek_stat_video.setMax(vv_preview.getDuration());
                    seek_stat_video.postDelayed(onEverySecond, 1000);
                    play_Video.setVisibility(View.GONE);
                    pause_Video.setVisibility(View.VISIBLE);
                }
            });

            vv_preview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    pause_Video.setVisibility(View.GONE);
                    play_Video.setVisibility(View.VISIBLE);
                    if (!vv_preview.isPlaying()) {
                        if (seek_stat_video.getProgress() > 0) {
                            seek_stat_video.setProgress(0);
                        }
                    }
                }
            });

            play_Video.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vv_preview.start();
                    seek_stat_video.setMax(vv_preview.getDuration());
                    seek_stat_video.postDelayed(onEverySecond, 1000);
                    play_Video.setVisibility(View.GONE);
                    pause_Video.setVisibility(View.VISIBLE);
                }
            });
            pause_Video.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vv_preview.pause();
                    play_Video.setVisibility(View.VISIBLE);
                    pause_Video.setVisibility(View.GONE);
                }
            });

            seek_stat_video.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onProgressChanged(SeekBar seekBar, int progress,
                                              boolean fromUser) {
                    if (fromUser) {
                        vv_preview.seekTo(progress);
                    }
                }
            });

        }

    }

    String getVideoTime(long ms) {
        ms /= 1000;
        return (ms / 3600) + ":" + ((ms % 3600) / 60) + ":" + ((ms % 3600) % 60);
    }

    private Runnable onEverySecond = new Runnable() {

        @Override
        public void run() {

            if (seek_stat_video != null) {
                seek_stat_video.setProgress(vv_preview.getCurrentPosition());
            }

            if (vv_preview.isPlaying()) {
                seek_stat_video.postDelayed(onEverySecond, 1000);
            }

        }
    };

    public void copyFile(Uri inputPath, String outputPath) {

        InputStream inputStream = null;
        try {
            inputStream = getContentResolver().openInputStream(inputPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            File f = new File(outputPath);
            f.setWritable(true, false);
            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            Toast.makeText(getApplicationContext(), "Video Download", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void copyFileee(File sourceFile, File destFile) throws IOException {
        if (!sourceFile.exists()) {
            return;
        }

        FileChannel source = null;
        FileChannel destination = null;
        source = new FileInputStream(sourceFile).getChannel();
        destination = new FileOutputStream(destFile).getChannel();
        if (destination != null && source != null) {
            destination.transferFrom(source, 0, source.size());
        }
        if (source != null) {
            source.close();
        }
        if (destination != null) {
            destination.close();
        }

    }

    private File createDirW(String dirName, String subDir) {
        File file = null;
        if (subDir != null) {
            file = new File(getFilesDir(), "GBWhatzUp/Videos");
        }
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    private File createDirWB(String dirName, String subDir) {
        File file = null;
        if (subDir != null) {
            file = new File(getFilesDir(), "GBWhatzUpWB/Videos");
        }
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    private boolean CheckDownload(String imageName) {
        boolean Check = false;
        File filePath = new File(getFilesDir(), "GBWhatzUp/Videos");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }

    private boolean CheckDownloadWB(String imageName) {
        boolean Check = false;
        File filePath = new File(getFilesDir(), "GBWhatzUpWB/Videos");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }

    @Override
    public void onBackPressed() {
        finish();
    }

}