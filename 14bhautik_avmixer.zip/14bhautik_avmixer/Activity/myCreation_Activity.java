package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.si_avmixer.bhautik_avmixer.R;

public class myCreation_Activity extends AppCompatActivity {

    ImageView iv_AudioCutterFile,iv_V2Afile,iv_VideoMotionFile,iv_VideoCutterFile,iv_AVMixerFile,btn_back_myCreations;
    public static boolean fromCreation = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation);

        iv_AudioCutterFile = findViewById(R.id.iv_AudioCutterFile);
        iv_V2Afile = findViewById(R.id.iv_V2Afile);
        iv_VideoMotionFile = findViewById(R.id.iv_VideoMotionFile);
        iv_VideoCutterFile = findViewById(R.id.iv_VideoCutterFile);
        iv_AVMixerFile = findViewById(R.id.iv_AVMixerFile);
        btn_back_myCreations = findViewById(R.id.btn_back_myCreations);

        btn_back_myCreations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        iv_AudioCutterFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fromCreation = true;
                Intent intent = new Intent(myCreation_Activity.this, myCreation_Audio_Activity.class);
                intent.putExtra("Value", 0);
                startActivity(intent);
//                finish();
            }
        });

        iv_V2Afile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fromCreation = true;

                Intent intent = new Intent(myCreation_Activity.this, myCreation_Audio_Activity.class);
                intent.putExtra("Value", 1);
                startActivity(intent);
//                finish();

            }
        });

        iv_VideoMotionFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fromCreation = true;

                Intent intent = new Intent(myCreation_Activity.this,myCreation_Videos_Activity.class);
                intent.putExtra("Value", 2);
                startActivity(intent);
//                finish();

            }
        });

        iv_VideoCutterFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fromCreation = true;

                Intent intent = new Intent(myCreation_Activity.this,myCreation_Videos_Activity.class);
                intent.putExtra("Value", 3);
                startActivity(intent);
//                finish();

            }
        });

        iv_AVMixerFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fromCreation = true;

                Intent intent = new Intent(myCreation_Activity.this,myCreation_Videos_Activity.class);
                intent.putExtra("Value", 4);
                startActivity(intent);
//                finish();
            }
        });

    }
}