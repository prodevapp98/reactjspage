package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telephony.SignalStrength;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.si_avmixer.bhautik_avmixer.Adapter.videoFiles_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.Model.allVideo_Model;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class VideoFiles_Activity extends AppCompatActivity {

    RecyclerView rv_videoFiles;
    ArrayList<allVideo_Model> videoFileList = new ArrayList<>();
    videoFiles_Adapter videoFiles_adapter;
    String folderName,folderPath;
    int val;
    TextView tv_folderName;
    ImageView iv_back_folderFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_files);

        rv_videoFiles = findViewById(R.id.rv_videoFiles);
        tv_folderName = findViewById(R.id.tv_folderName);
        iv_back_folderFile = findViewById(R.id.iv_back_folderFile);

        folderName = getIntent().getStringExtra("folderName");
        folderPath = getIntent().getStringExtra("folderPath");

        int valueav = getIntent().getIntExtra("AVMixer",0);
        int valuevc = getIntent().getIntExtra("VideoCutter",0);
        int v2avalue = getIntent().getIntExtra("V2A",0);
        int valuevm = getIntent().getIntExtra("VideoMotion",0);

        if (valueav == 1){
            val = valueav;
        } else if (valuevc == 4){
            val = valuevc;
        } else if (v2avalue == 3){
            val = v2avalue;
        } else if (valuevm == 5){
            val = valuevm;
        }

        tv_folderName.setText(folderName);

        showFiles();

        iv_back_folderFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void showFiles() {
        videoFileList = fetchFiles(folderName);
        sortAlpha2();
        videoFiles_adapter = new videoFiles_Adapter(videoFileList,this,val);
        rv_videoFiles.setAdapter(videoFiles_adapter);
        rv_videoFiles.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        videoFiles_adapter.notifyDataSetChanged();
    }

    public void sortAlpha2(){
        Collections.sort(videoFileList, new Comparator<allVideo_Model>() {
            @Override
            public int compare(allVideo_Model o1, allVideo_Model o2) {
                return o1.getVideoTitle().compareToIgnoreCase(o2.getVideoTitle());
            }

        });
    }

    private ArrayList<allVideo_Model> fetchFiles(String folderName) {

        ArrayList<allVideo_Model> videoFiles = new ArrayList<>();

        for (int i = 0; i < SelectVideoFile_Activity.allVideoArrayList.size(); i++) {
            if (SelectVideoFile_Activity.allVideoArrayList.get(i).getFolderNM().equals(folderName)) {
                videoFiles.add(SelectVideoFile_Activity.allVideoArrayList.get(i));
            }
        }
        return videoFiles;
    }
}