package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.si_avmixer.bhautik_avmixer.Adapter.audioFiles_Adapter;
import com.si_avmixer.bhautik_avmixer.Adapter.videoFiles_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.Utils;
import com.si_avmixer.bhautik_avmixer.Model.audioFolder_Model;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AudioFiles_Activity extends AppCompatActivity {

    RecyclerView rv_audioFiles;
    ArrayList<audioFolder_Model> audioFileList = new ArrayList<>();
    audioFiles_Adapter audioFiles_adapter;
    String folderName;
    int value,val;
    TextView tv_folderName;
    ImageView iv_back_folderFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_files);

        rv_audioFiles = findViewById(R.id.rv_audioFiles);
        tv_folderName = findViewById(R.id.tv_folderName);
        iv_back_folderFile = findViewById(R.id.iv_back_folderFile);

        folderName = getIntent().getStringExtra("AudioFolderName");
        value = getIntent().getIntExtra("AudioFolderVal",0);
        if (value == 2){
            val = value;
        }
        tv_folderName.setText(folderName);
        showFiles();

        iv_back_folderFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void showFiles() {
        audioFileList = fetchFiles(folderName);
        sortAlpha2();
        audioFiles_adapter = new audioFiles_Adapter(audioFileList,this,val);
        rv_audioFiles.setAdapter(audioFiles_adapter);
        rv_audioFiles.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        audioFiles_adapter.notifyDataSetChanged();
    }


    public void sortAlpha2(){
        Collections.sort(audioFileList, new Comparator<audioFolder_Model>() {
            @Override
            public int compare(audioFolder_Model o1, audioFolder_Model o2) {
                return o1.getDisplayName().compareToIgnoreCase(o2.getDisplayName());
            }
        });
    }

    private ArrayList<audioFolder_Model> fetchFiles(String folderName) {
        ArrayList<audioFolder_Model> videoFiles = new ArrayList<>();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection  = MediaStore.Audio.Media.DATA+" like?";
        String[] selectionArg = new String[]{"%"+folderName+"%"};
        Cursor cursor = getContentResolver().query(uri,null,selection,selectionArg,null);
        if (cursor != null && cursor.moveToNext()){
            do{
                String id = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
                String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                String displayName = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME));
                String size = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.SIZE));
                String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                String path = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                String dateAdded = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED));

                audioFolder_Model audioFolderModel = new audioFolder_Model(id,title,displayName,size, Utils.Companion.getDuration(path),path,dateAdded);
                if (path.endsWith(".mp3") && !Utils.Companion.getDuration(path).equals("0")) {
                    videoFiles.add(audioFolderModel);
                }

            } while (cursor.moveToNext());
        }
        return videoFiles;
    }

}