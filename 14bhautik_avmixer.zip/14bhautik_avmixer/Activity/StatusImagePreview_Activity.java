package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

import static android.os.Build.VERSION.SDK_INT;
import static com.si_avmixer.bhautik_avmixer.Activity.StatusSaver_Activity.oneTime;

public class StatusImagePreview_Activity extends AppCompatActivity {

    ImageView iv_preview,iv_back_preview,iv_download_Image,iv_share_Image;
    TextView tv_downloadNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_image_preview);


        iv_preview = findViewById(R.id.iv_preview);
        iv_back_preview = findViewById(R.id.iv_back_preview);
        iv_download_Image = findViewById(R.id.iv_download_Image);
        iv_share_Image = findViewById(R.id.iv_share_Image);
        tv_downloadNote = findViewById(R.id.tv_downloadNote);

        oneTime = true;

        iv_back_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Intent intent = getIntent();
        String imgpath = intent.getStringExtra("StatusImagePreview");
        String imgName = intent.getStringExtra("StatusImageName");
        int value = intent.getIntExtra("Value",-25);

        if (CheckDownload(imgName) || CheckDownloadWB(imgName)){
            iv_download_Image.setVisibility(View.GONE);
        } else {
            iv_download_Image.setVisibility(View.VISIBLE);
        }

        Glide.with(getApplicationContext()).load(imgpath).into(iv_preview);

        iv_download_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 11 ){
                    createDirWB("GBWhatzUpWB", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;

                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 12){
                    createDirW("GBWhatzUp", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 13 ){
                    createDirWB("GBWhatzUpWB", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;

                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 14){
                    createDirW("GBWhatzUp", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 2){
                    createDirW("GBWhatzUp", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 3){
                    createDirW("GBWhatzUp", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 1){
                    createDirWB("GBWhatzUpWB", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (value == 4){
                    createDirWB("GBWhatzUpWB", "Images");
                    Uri ImageUrl = Uri.parse(imgpath);
                    String ImageName = imgName;
                    File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                    if (SDK_INT >= Build.VERSION_CODES.R) {
                        copyFile(ImageUrl, String.valueOf(myFolderPath));
                    } else {
                        try {
                            File imagePath = new File(String.valueOf(ImageUrl));
                            copyFileee(imagePath,myFolderPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                iv_download_Image.setVisibility(View.GONE);
                iv_share_Image.setVisibility(View.VISIBLE);
                tv_downloadNote.setVisibility(View.VISIBLE);

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        tv_downloadNote.setVisibility(View.GONE);
                    }
                }, 3000);

            }
        });

        iv_share_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(imgpath);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                startActivity(Intent.createChooser(shareIntent, "Share it"));
            }
        });

    }

    public void copyFile(Uri inputPath, String outputPath) {
        InputStream inputStream = null;
        try {
            inputStream = getContentResolver().openInputStream(inputPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            File f = new File(outputPath);
            f.setWritable(true, false);
            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            Toast.makeText(getApplicationContext(), "Image download", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private void copyFileee(File sourceFile, File destFile) throws IOException {
        if (!sourceFile.exists()) {
            return;
        }

        FileChannel source = null;
        FileChannel destination = null;
        source = new FileInputStream(sourceFile).getChannel();
        destination = new FileOutputStream(destFile).getChannel();
        if (destination != null && source != null) {
            destination.transferFrom(source, 0, source.size());
        }
        if (source != null) {
            source.close();
        }
        if (destination != null) {
            destination.close();
        }

    }

    private File createDirW(String dirName,String subDir){
        File file = null;
        if (subDir != null){
            file = new File(getFilesDir(), "GBWhatzUp/Images");
        }
        if (!file.exists()){
            file.mkdirs();
        }
        return file;
    }
    private File createDirWB(String dirName,String subDir){
        File file = null;
        if (subDir != null){
            file = new File(getFilesDir(), "GBWhatzUpWB/Images");
        }
        if (!file.exists()){
            file.mkdirs();
        }
        return file;
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private boolean CheckDownload(String imageName) {
        boolean Check = false;
        File filePath = new File(getFilesDir(), "GBWhatzUp/Images");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }
    private boolean CheckDownloadWB(String imageName) {
        boolean Check = false;
        File filePath = new File(getFilesDir(), "GBWhatzUpWB/Images");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }

}