package com.si_avmixer.bhautik_avmixer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.si_avmixer.bhautik_avmixer.Adapter.MoreApps_Adapter;
import com.si_avmixer.bhautik_avmixer.Model.MoreApps_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.util.ArrayList;

public class MoreApps_Activity extends AppCompatActivity {

    ImageView iv_back_moreapp;
    RecyclerView rv_moreApps;
    ArrayList<MoreApps_Model> moreAppsModelArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_apps);

        iv_back_moreapp = findViewById(R.id.iv_back_moreapp);

        iv_back_moreapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        rv_moreApps = findViewById(R.id.rv_moreApps);
        moreAppsModelArrayList = new ArrayList<>();

        moreAppsModelArrayList.add(new MoreApps_Model("Master VPN", R.drawable.logo));
        moreAppsModelArrayList.add(new MoreApps_Model("FM Whatzzp", R.drawable.logo));
        moreAppsModelArrayList.add(new MoreApps_Model("APP LOCK", R.drawable.logo));

        MoreApps_Adapter adapter = new MoreApps_Adapter(moreAppsModelArrayList,getApplicationContext());
        rv_moreApps.setHasFixedSize(true);
        rv_moreApps.setLayoutManager(new GridLayoutManager(this,3));
        rv_moreApps.setAdapter(adapter);


    }
}