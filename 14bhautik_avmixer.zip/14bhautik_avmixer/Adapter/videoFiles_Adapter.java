package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Activity.AVMixer_Activity;
import com.si_avmixer.bhautik_avmixer.Activity.videoTrimmer_Activity;
import com.si_avmixer.bhautik_avmixer.Model.allVideo_Model;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

public class videoFiles_Adapter extends RecyclerView.Adapter<videoFiles_Adapter.ViewHolder>{

    ArrayList<allVideo_Model> videoList;
    Context context;
    int value;

    public videoFiles_Adapter(ArrayList<allVideo_Model> videoList, Context context, int value) {
        this.videoList = videoList;
        this.context = context;
        this.value = value;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_videofiles,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(videoFiles_Adapter.ViewHolder holder, int position) {

        File myvideoFile = new File(videoList.get(position).getVideoUri().getPath());


        holder.tv_videoFileName.setText(new File(String.valueOf(videoList.get(position).getVideoUri())).getName());
        if (!videoList.get(position).getVideoDuration().toString().isEmpty() && videoList.get(position).getVideoDuration()!= null && !TextUtils.isEmpty(videoList.get(position).getVideoDuration()))
        {
            holder.tv_videoFile_Duration.setText("Duration: "+videoList.get(position).getVideoDuration());

        }

        long size = Long.parseLong(videoList.get(position).getVideoSize());
        long sizeInMb =  size / (1024 * 1024);

        holder.tv_videoFileSize.setText("Size: " + sizeInMb+"MB");

        Glide.with(context).load(videoList.get(position).getVideoUri()).into(holder.iv_videoFile_image);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 1){
                    Intent intent = new Intent(context, AVMixer_Activity.class);
                    intent.putExtra("AVMixerVideoUrl", videoList.get(position).getVideoUri().toString());
                    intent.putExtra("AVMixerVideoName",videoList.get(position).getVideoTitle());
                    context.startActivity(intent);
                }

                if (value == 4 || value == 3 || value == 5){
                    if (myvideoFile.getName().contains("#")) {
                        Toast.makeText(context, "Video Not Supported", Toast.LENGTH_SHORT).show();
                    } else {
                        if (value == 3) {

                            Intent intent = new Intent(context, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoList.get(position).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 1);
                            context.startActivity(intent);
                        }
                        if (value == 4) {

                            Intent intent = new Intent(context, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoList.get(position).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 0);
                            context.startActivity(intent);
                        }

                        if (value == 5) {
                            Intent intent = new Intent(context, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoList.get(position).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 2);
                            context.startActivity(intent);
                        }
                    }

                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_videoFile_image;
        TextView tv_videoFileName,tv_videoFile_Duration,tv_videoFileSize;

        public ViewHolder(View itemView) {
            super(itemView);

            iv_videoFile_image = itemView.findViewById(R.id.iv_videoFile_image);
            tv_videoFileName = itemView.findViewById(R.id.tv_videoFileName);
            tv_videoFile_Duration = itemView.findViewById(R.id.tv_videoFile_Duration);
            tv_videoFileSize = itemView.findViewById(R.id.tv_videoFileSize);

        }
    }
}
