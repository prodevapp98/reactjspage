package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Activity.StatusDownloadPreview_Activity;
import com.si_avmixer.bhautik_avmixer.Model.Download_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

public class download_Adapter extends RecyclerView.Adapter<download_Adapter.ViewHolder> {

    ArrayList<Download_Model> arrayList = new ArrayList<>();
    Context context;
    onButtonClickListener onButtonClickListener;

    public void setOnButtonClickListener(onButtonClickListener onButtonClickListener){
        this.onButtonClickListener = onButtonClickListener;
    }

    public void setnewData(ArrayList<Download_Model> downloadImageList) {
        this.arrayList = downloadImageList;
        notifyDataSetChanged();
    }

    public interface onButtonClickListener{
        void onButtonDeleteClickListener(int position, String imageUrl);
        void onButtonShareClickListener(int position, String imageUrl);
    }

    public download_Adapter(ArrayList<Download_Model> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_download,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(download_Adapter.ViewHolder holder, int position) {

        int i2 = 1;
        for (int i3 = 1; i3 < position + 1; i3++) {
            i2++;
            if (i2 > 3) {
                i2 = 1;
            }
        }

        Glide.with(context).load(arrayList.get(position).getImgUrls()).into(holder.showDImages);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getApplicationContext(), StatusDownloadPreview_Activity.class);
                String SendPath = arrayList.get(position).getImgUrls();
                intent.putExtra("StatusDownloadImagePath", SendPath);
                intent.putExtra("fromDownload",true);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

        holder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onButtonClickListener.onButtonDeleteClickListener(position,arrayList.get(position).getImgUrls());

            }
        });

        holder.iv_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onButtonClickListener.onButtonShareClickListener(position,arrayList.get(position).getImgUrls());

            }
        });

        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) holder.rellay_downloadshow.getLayoutParams();
        switch (i2) {
            case 1:
                params.height = 370;
                holder.rellay_downloadshow.setLayoutParams(params);
                return;
            case 2:
                params.height = 430;
                holder.rellay_downloadshow.setLayoutParams(params);
                return;
            case 3:
                params.height = 470;
                holder.rellay_downloadshow.setLayoutParams(params);
                return;
        }


    }

    @Override
    public int getItemCount() {
       return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView showDImages,iv_delete,iv_share;
        RelativeLayout rellay_downloadshow;

        public ViewHolder(View itemView) {
            super(itemView);

            showDImages = itemView.findViewById(R.id.showDImages);
            iv_share = itemView.findViewById(R.id.iv_share);
            iv_delete = itemView.findViewById(R.id.iv_delete);
            rellay_downloadshow = itemView.findViewById(R.id.rellay_downloadshow);

        }
    }
}
