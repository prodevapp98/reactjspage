package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Activity.AVMixer_Activity;
import com.si_avmixer.bhautik_avmixer.Activity.videoTrimmer_Activity;
import com.si_avmixer.bhautik_avmixer.Model.allVideo_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

import life.knowledge4.videotrimmer.utils.FileUtils;

public class allVideo_Adapter extends RecyclerView.Adapter<allVideo_Adapter.viewHolder> {

    Context context1;
    ArrayList<allVideo_Model> videoArrayList;
    int value;

    public allVideo_Adapter(Context context1, ArrayList<allVideo_Model> videoArrayList, int value) {
        this.context1 = context1;
        this.videoArrayList = videoArrayList;
        this.value = value;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context1).inflate(R.layout.adapter_allvideo, viewGroup, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(final viewHolder holder, final int i) {

        File myvideoFile = new File(videoArrayList.get(i).getVideoUri().getPath());

        holder.tv_videoName.setText(myvideoFile.getName());

        holder.tv_video_Duration.setText("Duration: " + videoArrayList.get(i).getVideoDuration());

        long size = Long.parseLong(videoArrayList.get(i).getVideoSize());
        long sizeInMb = size / (1024 * 1024);
        if (Math.toIntExact(sizeInMb) == 0) {
            sizeInMb = 1;
        }

        holder.tv_videoSize.setText("Size: " + sizeInMb + "MB");

        Uri Path = videoArrayList.get(i).getVideoUri();
        File file = new File(Path.getPath());
        Glide.with(context1).load(file).override(200, 200).into(holder.iv_video_image1);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 1) {
                    Intent intent = new Intent(context1, AVMixer_Activity.class);
                    intent.putExtra("AVMixerVideoUrl", videoArrayList.get(i).getVideoUri().toString());
                    intent.putExtra("AVMixerVideoName", videoArrayList.get(i).getVideoTitle());
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context1.startActivity(intent);
                }

                if (value == 4 || value == 3 || value == 5) {

                    if (myvideoFile.getName().contains("#")) {
                        Toast.makeText(context1, "Video Not Supported", Toast.LENGTH_SHORT).show();
                    } else {
                        if (value == 3) {
                            Intent intent = new Intent(context1, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoArrayList.get(i).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 1);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context1.startActivity(intent);
                        }

                        if (value == 4) {
                            Intent intent = new Intent(context1, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoArrayList.get(i).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 0);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context1.startActivity(intent);
                        }

                        if (value == 5) {
                            Intent intent = new Intent(context1, videoTrimmer_Activity.class);
                            intent.putExtra("VideoTrimmer", videoArrayList.get(i).getVideoUri().toString());
                            intent.putExtra("ValueV2A", 2);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context1.startActivity(intent);
                        }

                    }

                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return videoArrayList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView tv_videoName, tv_video_Duration, tv_videoSize;
        ImageView iv_video_image1;

        public viewHolder(View itemView) {
            super(itemView);
            tv_videoName = (TextView) itemView.findViewById(R.id.tv_videoName);
            tv_video_Duration = (TextView) itemView.findViewById(R.id.tv_video_Duration);
            tv_videoSize = (TextView) itemView.findViewById(R.id.tv_videoSize);
            iv_video_image1 = (ImageView) itemView.findViewById(R.id.iv_video_image);
        }
    }

}
