package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.si_avmixer.bhautik_avmixer.Fragment.ImageFragment;
import com.si_avmixer.bhautik_avmixer.Fragment.VideoFragment;


public class ViewPager_Adapter_forSave extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;


    public ViewPager_Adapter_forSave(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                VideoFragment videosFragment = new VideoFragment();
                return videosFragment;
            case 1:
                ImageFragment imagesFragmen = new ImageFragment();
                return imagesFragmen;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return totalTabs;
    }
}

