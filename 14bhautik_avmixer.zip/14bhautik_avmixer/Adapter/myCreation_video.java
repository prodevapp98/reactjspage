package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Activity.StatusDownloadPreview_Activity;
import com.si_avmixer.bhautik_avmixer.Model.myCreationAudioCutter_Model;
import com.si_avmixer.bhautik_avmixer.Model.myCreationVideo_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.util.ArrayList;

public class myCreation_video extends RecyclerView.Adapter<myCreation_video.ViewHolder> {

    ArrayList<myCreationVideo_Model> arrayList = new ArrayList<>();
    Context context;
    Pos pos;

    public myCreation_video(ArrayList<myCreationVideo_Model> arrayList, Context context, Pos pos) {
        this.arrayList = arrayList;
        this.context = context;
        this.pos = pos;
    }

    public void setnewData(ArrayList<myCreationVideo_Model> videoList) {
        this.arrayList = videoList;
        notifyDataSetChanged();
    }

    public interface Pos{
        public void onClick(int positions,View v, String url);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_mycreation_video,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(myCreation_video.ViewHolder holder, int position) {

        holder.tv_videofileName.setText(arrayList.get(position).getVideoName());

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(arrayList.get(0).getVideoUrls());
        String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
        String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
        String bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE);

        holder.tv_videofileSize.setText("Size: "+ arrayList.get(position).getVideoSize() + " MB");

        holder.tv_videofile_Duration.setText("Duration: " + timeConversion(arrayList.get(position).getVideoDuration()));

        Glide.with(context).load(arrayList.get(position).getVideoUrls()).into(holder.iv_videofile_image);

        holder.iv_video_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.iv_video_menu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pos.onClick(position,v,arrayList.get(position).getVideoUrls());
                    }
                });
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, StatusDownloadPreview_Activity.class);
                intent.putExtra("StatusDownloadImagePath",arrayList.get(position).getVideoUrls());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });

    }

    public String timeConversion(long value) {
        String audioTime;
        int dur = (int) value;
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60000;
        int scs = dur % 60000 / 1000;

        if (hrs > 0) {
            audioTime = String.format("%02d:%02d:%02d", hrs, mns, scs);
        } else {
            audioTime = String.format("%02d:%02d", mns, scs);
        }
        return audioTime;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_videofileName,tv_videofile_Duration,tv_videofileSize;
        ImageView iv_videofile_image;
        LinearLayout iv_video_menu;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_videofile_Duration = (TextView) itemView.findViewById(R.id.tv_videofile_Duration);
            tv_videofileName = (TextView) itemView.findViewById(R.id.tv_videofileName);
            tv_videofileSize = (TextView) itemView.findViewById(R.id.tv_videofileSize);
            iv_videofile_image = itemView.findViewById(R.id.iv_videofile_image);
            iv_video_menu = itemView.findViewById(R.id.iv_video_menu);

        }
    }
}
