package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.si_avmixer.bhautik_avmixer.Model.myCreationAudioCutter_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.IOException;
import java.util.ArrayList;

public class myCreation_audio extends RecyclerView.Adapter<myCreation_audio.ViewHolder> {

    ArrayList<myCreationAudioCutter_Model> arrayList = new ArrayList<>();
    Context context;
    Pos pos;
    public static MediaPlayer mediaPlayerAudioCreation = null;
    int savedPos = 1001;

    public myCreation_audio(ArrayList<myCreationAudioCutter_Model> arrayList, Context context, Pos pos) {
        this.arrayList = arrayList;
        this.context = context;
        this.pos = pos;
    }

    public interface Pos {
        public void onClick(int positions, View v, String url);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_mycreation_audiocutter, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(myCreation_audio.ViewHolder holder, int position) {

        holder.tv_audiocutterFileName.setText(arrayList.get(position).getSongName());

        holder.tv_audiofile_Duration.setText("Duration: " + arrayList.get(position).getSongDuration());

        holder.tv_audiofileSize.setText("Size: " + arrayList.get(position).getSongSize() + " MB");

        holder.iv_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos.onClick(position, v, arrayList.get(position).getSongUrls());
            }
        });

        if (savedPos == position) {
            if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()) {
                holder.iv_audioThumbnail.setBackgroundResource(R.drawable.pause);
                mediaPlayerAudioCreation.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        holder.iv_audioThumbnail.setBackgroundResource(R.drawable.play);
                    }
                });
            } else {
                holder.iv_audioThumbnail.setBackgroundResource(R.drawable.play);

            }
        } else {
            holder.iv_audioThumbnail.setBackgroundResource(R.drawable.play);
        }

        holder.iv_audioThumbnail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (savedPos == position) {
                    if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()) {
                        mediaPlayerAudioCreation.stop();
                        notifyDataSetChanged();
                    } else {
                        playSong(position);
                        notifyDataSetChanged();
                    }
                } else {
                    if (mediaPlayerAudioCreation != null && mediaPlayerAudioCreation.isPlaying()) {
                        mediaPlayerAudioCreation.stop();
                    }
                    playSong(position);
                    notifyDataSetChanged();
                }
            }
        });
    }

    public void playSong(int position) {


        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int result = am.requestAudioFocus(focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);

        try {
            savedPos = position;
            mediaPlayerAudioCreation = new MediaPlayer();
            mediaPlayerAudioCreation.setDataSource(arrayList.get(position).getSongUrls());
            mediaPlayerAudioCreation.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            mediaPlayerAudioCreation.start();
        }

    }

    private AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {
                    AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                    switch (focusChange) {
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            mediaPlayerAudioCreation.pause();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            mediaPlayerAudioCreation.pause();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS):
                            mediaPlayerAudioCreation.pause();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_GAIN):
                            break;
                        default:
                            break;
                    }
                }
            };

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_audiocutterFileName, tv_audiofileSize, tv_audiofile_Duration;
        LinearLayout iv_menu;
        ImageView iv_audioThumbnail;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_audiocutterFileName = itemView.findViewById(R.id.tv_audiocutterFileName);
            iv_menu = itemView.findViewById(R.id.iv_audio_menu);
            tv_audiofileSize = itemView.findViewById(R.id.tv_audiofileSize);
            tv_audiofile_Duration = itemView.findViewById(R.id.tv_audiofile_Duration);
            iv_audioThumbnail = itemView.findViewById(R.id.iv_audioThumbnail);
        }
    }
}
