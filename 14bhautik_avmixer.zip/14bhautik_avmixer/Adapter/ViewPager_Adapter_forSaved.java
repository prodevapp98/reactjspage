package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.si_avmixer.bhautik_avmixer.Fragment.DImageFragment;
import com.si_avmixer.bhautik_avmixer.Fragment.DVideoFragment;
import com.si_avmixer.bhautik_avmixer.Fragment.ImageFragment;
import com.si_avmixer.bhautik_avmixer.Fragment.VideoFragment;


public class ViewPager_Adapter_forSaved extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;


    public ViewPager_Adapter_forSaved(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                DVideoFragment videosFragment = new DVideoFragment();
                return videosFragment;
            case 1:
                DImageFragment imagesFragmen = new DImageFragment();
                return imagesFragmen;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return totalTabs;
    }
}

