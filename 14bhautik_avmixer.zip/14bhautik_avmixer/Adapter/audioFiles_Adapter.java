package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Model.audioFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.util.ArrayList;

public class audioFiles_Adapter extends RecyclerView.Adapter<audioFiles_Adapter.ViewHolder> {

    ArrayList<audioFolder_Model> audioList;
    Context context;
    int Value;

    public audioFiles_Adapter(ArrayList<audioFolder_Model> videoList, Context context, int value) {
        this.audioList = videoList;
        this.context = context;
        Value = value;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_audiofile,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(audioFiles_Adapter.ViewHolder holder, int position) {
        holder.tv_audioFolderName.setText(audioList.get(position).getDisplayName());
        if (!audioList.get(position).getDuration().toString().isEmpty() && audioList.get(position).getDuration()!= null && !TextUtils.isEmpty(audioList.get(position).getDuration()))
        {
            holder.tv_audioFolder_Duration.setText("Duration: "+audioList.get(position).getDuration());

        }

        long size = Long.parseLong(audioList.get(position).getSize());
        long sizeInMb =  size / (1024 * 1024);

        holder.tv_audioFolderSize.setText("Size: " + sizeInMb+"MB");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Value == 2){
                    Intent intent1 = new Intent(Intent.ACTION_EDIT, Uri.parse(String.valueOf(audioList.get(position).getPath())));
                    intent1.putExtra("was_get_content_intent", false);
                    intent1.setClassName(context, "com.si_avmixer.bhautik_avmixer.Waveformview.RingdroidEditActivity");
                    intent1.setAction("android.intent.action.EDIT");
                    context.startActivity(intent1);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return audioList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_audioFolderName,tv_audioFolder_Duration,tv_audioFolderSize;
        public ViewHolder(View itemView) {
            super(itemView);
            tv_audioFolderName = itemView.findViewById(R.id.tv_audioFolderName);
            tv_audioFolder_Duration = itemView.findViewById(R.id.tv_audioFolder_Duration);
            tv_audioFolderSize = itemView.findViewById(R.id.tv_audioFolderSize);

        }
    }
}
