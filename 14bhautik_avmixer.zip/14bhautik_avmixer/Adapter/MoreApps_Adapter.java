package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.si_avmixer.bhautik_avmixer.Model.MoreApps_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.util.ArrayList;

public class MoreApps_Adapter extends RecyclerView.Adapter<MoreApps_Adapter.ViewHolder> {

    ArrayList<MoreApps_Model> arrayList = new ArrayList<>();
    Context context;

    public MoreApps_Adapter(ArrayList<MoreApps_Model> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.app_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.iv_MoreAppLogo.setImageResource(arrayList.get(position).getImgId());
        holder.tv_MoreAppName.setText(arrayList.get(position).getAppname());

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_MoreAppLogo;
        TextView tv_MoreAppName;

        public ViewHolder(View itemView) {
            super(itemView);

            iv_MoreAppLogo = itemView.findViewById(R.id.ivAppLogo);
            tv_MoreAppName = itemView.findViewById(R.id.tvAppName);

        }
    }
}
