package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.si_avmixer.bhautik_avmixer.Activity.VideoFiles_Activity;
import com.si_avmixer.bhautik_avmixer.Model.FolderModel;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

public class videoFolder_Adapter extends RecyclerView.Adapter<videoFolder_Adapter.ViewHolder> {

    ArrayList<FolderModel> mediaFiles;
    ArrayList<String> folderPath;
    Context context;
    int value;

    public videoFolder_Adapter(ArrayList<FolderModel> videoFolders, Context applicationContext, int adapterValue) {
        this.mediaFiles = videoFolders;
         this.context = applicationContext;
        this.value=adapterValue;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_videofolder,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(videoFolder_Adapter.ViewHolder holder, int position) {

        holder.folderName.setText(mediaFiles.get(position).getFolderName());

        int numberOfFiles = 0;
        File dir = new File(mediaFiles.get(position).getPath());
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file1 : files) {
                if (file1.getName().contains(".mp4")) {
                    numberOfFiles++;
                }
            }
            holder.numberofFile.setText(numberOfFiles + " Files");
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 1){

                    Intent intent = new Intent(context, VideoFiles_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("folderName",mediaFiles.get(position).getFolderName());
                    intent.putExtra("folderPath",mediaFiles.get(position).getPath());
                    intent.putExtra("AVMixer",value);
                    context.startActivity(intent);
                } else if (value == 4){
                    Intent intent = new Intent(context, VideoFiles_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("folderName",mediaFiles.get(position).getFolderName());
                    intent.putExtra("folderPath",mediaFiles.get(position).getPath());
                    intent.putExtra("VideoCutter",value);
                    context.startActivity(intent);
                } else if (value == 3){
                    Intent intent = new Intent(context, VideoFiles_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("folderName",mediaFiles.get(position).getFolderName());
                    intent.putExtra("folderPath",mediaFiles.get(position).getPath());
                    intent.putExtra("V2A",value);
                    context.startActivity(intent);
                } else if (value == 5){
                    Intent intent = new Intent(context, VideoFiles_Activity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("folderName",mediaFiles.get(position).getFolderName());
                    intent.putExtra("folderPath",mediaFiles.get(position).getPath());
                    intent.putExtra("VideoMotion",value);
                    context.startActivity(intent);
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return mediaFiles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView folderName, numberofFile;
        public ViewHolder(View itemView) {
            super(itemView);
            folderName = itemView.findViewById(R.id.folderName);
            numberofFile = itemView.findViewById(R.id.numberofFile);
        }
    }
}
