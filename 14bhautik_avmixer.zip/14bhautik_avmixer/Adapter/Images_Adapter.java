package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.si_avmixer.bhautik_avmixer.Activity.StatusImagePreview_Activity;
import com.si_avmixer.bhautik_avmixer.Model.Images_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import static android.os.Build.VERSION.SDK_INT;

public class Images_Adapter extends RecyclerView.Adapter<Images_Adapter.ViewHolder> {

    ArrayList<Images_Model> arrayList = new ArrayList<>();
    Context context;
    int value;

    public Images_Adapter(ArrayList<Images_Model> arrayList, Context context, int value) {
        this.arrayList = arrayList;
        this.context = context;
        this.value = value;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_images, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(Images_Adapter.ViewHolder holder, int position) {

        int i2 = 1;
        for (int i3 = 1; i3 < position + 1; i3++) {
            i2++;
            if (i2 > 3) {
                i2 = 1;
            }
        }

        Glide.with(context).load(arrayList.get(position).getImageUrl()).into(holder.showImages);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context.getApplicationContext(), StatusImagePreview_Activity.class);
                intent.putExtra("StatusImagePreview", arrayList.get(position).getImageUrl());
                intent.putExtra("StatusImageName",arrayList.get(position).getImageName());
                intent.putExtra("Value", value);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });

        holder.downloadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.downloadImage.isPressed()) {

                    if (value == 11 ){
                        createDirWB("GBWhatzUpWB", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();

                        File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 12){
                        createDirW("GBWhatzUp", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 13 ){
                        createDirWB("GBWhatzUpWB", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();

                        File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 14){
                        createDirW("GBWhatzUp", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 2){
                        createDirW("GBWhatzUp", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 3){
                        createDirW("GBWhatzUp", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirW("GBWhatzUp", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 1){
                        createDirWB("GBWhatzUpWB", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    if (value == 4){
                        createDirWB("GBWhatzUpWB", "Images");
                        Uri ImageUrl = Uri.parse(arrayList.get(position).getImageUrl());
                        String ImageName = arrayList.get(position).getImageName();
                        File myFolderPath = new File(createDirWB("GBWhatzUpWB", "Images").getPath(), ImageName);
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            copyFile(ImageUrl, String.valueOf(myFolderPath));
                        } else {
                            try {
                                File imagePath = new File(String.valueOf(ImageUrl));
                                copyFileee(imagePath,myFolderPath);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    notifyDataSetChanged();

                }
            }
        });

        if (value == 2 || value == 3 || value == 12 || value == 14){
            if (CheckDownload(arrayList.get(position).getImageName())){
                holder.downloadImage.setVisibility(View.GONE);
            }else {
                holder.downloadImage.setVisibility(View.VISIBLE);
            }
        }
        if (value == 1 || value == 4 || value == 11 || value == 13){
            if (CheckDownloadWB(arrayList.get(position).getImageName())){
                holder.downloadImage.setVisibility(View.GONE);
            }else {
                holder.downloadImage.setVisibility(View.VISIBLE);
            }
        }

        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) holder.rel_lay_imageshow.getLayoutParams();
        switch (i2) {
            case 1:
                params.height = 370;
                holder.rel_lay_imageshow.setLayoutParams(params);
                return;
            case 2:
                params.height = 430;
                holder.rel_lay_imageshow.setLayoutParams(params);
                return;
            case 3:
                params.height = 470;
                holder.rel_lay_imageshow.setLayoutParams(params);
                return;
        }

    }

    private boolean CheckDownload(String imageName) {
        boolean Check = false;
        File filePath = new File(context.getFilesDir(), "GBWhatzUp/Images");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }
    private boolean CheckDownloadWB(String imageName) {
        boolean Check = false;
        File filePath = new File(context.getFilesDir(), "GBWhatzUpWB/Images");
        File file = new File(filePath.getAbsolutePath());
        File[] allFiles = file.listFiles();
        if (allFiles != null) {
            for (File file1 : allFiles) {
                if (file1.getName().matches(imageName)) {
                    Check = true;
                    break;
                }
            }
        }
        return Check;
    }

    public void copyFile(Uri inputPath, String outputPath) {
        InputStream inputStream = null;
        try {
            inputStream = context.getContentResolver().openInputStream(inputPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            File f = new File(outputPath);
            f.setWritable(true, false);
            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            Toast.makeText(context, "Image download", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private void copyFileee(File sourceFile, File destFile) throws IOException {
        if (!sourceFile.exists()) {
            return;
        }

        FileChannel source = null;
        FileChannel destination = null;
        source = new FileInputStream(sourceFile).getChannel();
        destination = new FileOutputStream(destFile).getChannel();
        if (destination != null && source != null) {
            destination.transferFrom(source, 0, source.size());
        }
        if (source != null) {
            source.close();
        }
        if (destination != null) {
            destination.close();
        }

    }

    private File createDirW(String dirName,String subDir){
        File file = null;
        if (subDir != null){
            file = new File(context.getFilesDir(), "GBWhatzUp/Images");
        }
        if (!file.exists()){
            file.mkdirs();
        }
        return file;
    }
    private File createDirWB(String dirName,String subDir){
        File file = null;
        if (subDir != null){
            file = new File(context.getFilesDir(), "GBWhatzUpWB/Images");
        }
        if (!file.exists()){
            file.mkdirs();
        }
        return file;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView showImages,downloadImage;
        RelativeLayout rel_lay_imageshow;
        public ViewHolder(View itemView) {
            super(itemView);
            showImages = itemView.findViewById(R.id.showImages);
            downloadImage = itemView.findViewById(R.id.downloadImage);
            rel_lay_imageshow = itemView.findViewById(R.id.rel_lay_imageshow);
        }
    }

}
