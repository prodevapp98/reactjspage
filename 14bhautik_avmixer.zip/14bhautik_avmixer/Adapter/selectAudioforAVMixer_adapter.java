package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.IOException;
import java.util.ArrayList;

import static com.si_avmixer.bhautik_avmixer.Activity.SelectAudioForAVMixer.selectedUrl;


public class selectAudioforAVMixer_adapter extends RecyclerView.Adapter<selectAudioforAVMixer_adapter.ViewHolder> {

    Context context1;
    ArrayList<allAudio_Model> audioArrayList;
    private onItemClickListener mItemClickListener;
    int savedPos = 2001;
    public static MediaPlayer mPlayer = null;

    public void setOnItemClickListener(onItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public interface onItemClickListener {
        void onItemClickListener(int position, String url,String name);
    }

    public selectAudioforAVMixer_adapter(Context context1, ArrayList<allAudio_Model> audioArrayList) {
        this.context1 = context1;
        this.audioArrayList = audioArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context1).inflate(R.layout.adapter_selectaudioavmixer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(selectAudioforAVMixer_adapter.ViewHolder holder, int position) {
        holder.tv_selectedaudioName.setText(audioArrayList.get(position).getAudioTitle());

        if (savedPos == position) {
            if (mPlayer != null && mPlayer.isPlaying()) {
                holder.linlay.setBackgroundResource(R.drawable.preview_selected);
                holder.iv_stop.setVisibility(View.VISIBLE);
                holder.iv_play.setVisibility(View.GONE);

            } else {
                holder.linlay.setBackgroundResource(0);
                holder.iv_stop.setVisibility(View.GONE);
                holder.iv_play.setVisibility(View.VISIBLE);
            }
        }  else {
            holder.linlay.setBackgroundResource(0);
            holder.iv_stop.setVisibility(View.GONE);
            holder.iv_play.setVisibility(View.VISIBLE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mItemClickListener.onItemClickListener(position,audioArrayList.get(position).getAudioUri().toString(),audioArrayList.get(position).getAudioTitle());

                holder.linlay.setBackgroundResource(R.drawable.preview_selected);
                if (savedPos == position) {
                    if (mPlayer != null && mPlayer.isPlaying()) {
                        mPlayer.stop();
                        selectedUrl = null;
                        notifyDataSetChanged();
                    } else {
                        playSong(position);
                        notifyDataSetChanged();
                    }
                } else{
                    if (mPlayer != null && mPlayer.isPlaying()) {
                        mPlayer.stop();
                    }
                    playSong(position);
                    notifyDataSetChanged();
                }

            }
        });
    }

    public void playSong(int position){

        AudioManager am = (AudioManager) context1.getSystemService(Context.AUDIO_SERVICE);
        int result = am.requestAudioFocus(focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        try {
            savedPos = position;
            mPlayer = new MediaPlayer();
            mPlayer.setDataSource(String.valueOf(audioArrayList.get(position).getAudioUri()));
            mPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            mPlayer.start();
        }

    }

    private AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {
                    AudioManager am =(AudioManager)context1.getSystemService(Context.AUDIO_SERVICE);
                    switch (focusChange) {
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) :
                            mPlayer.stop();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) :
                            mPlayer.stop();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS) :
                            mPlayer.stop();
                            notifyDataSetChanged();
                            break;
                        case (AudioManager.AUDIOFOCUS_GAIN) :
                            break;
                        default: break;
                    }
                }
            };

    @Override
    public int getItemCount() {
        return audioArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_selectedaudioName;
        LinearLayout linlay;
        ImageView iv_stop,iv_play;

        public ViewHolder(View itemView) {
            super(itemView);
            tv_selectedaudioName = itemView.findViewById(R.id.tv_selectedaudioName);
            linlay = itemView.findViewById(R.id.linlay);
            iv_stop = itemView.findViewById(R.id.iv_stop);
            iv_play = itemView.findViewById(R.id.iv_play);
        }
    }
}
