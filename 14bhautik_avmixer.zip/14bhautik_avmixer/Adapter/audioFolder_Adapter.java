package com.si_avmixer.bhautik_avmixer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.si_avmixer.bhautik_avmixer.Activity.AudioFiles_Activity;
import com.si_avmixer.bhautik_avmixer.Activity.VideoFiles_Activity;
import com.si_avmixer.bhautik_avmixer.Model.FolderModel;
import com.si_avmixer.bhautik_avmixer.Model.audioFolder_Model;
import com.si_avmixer.bhautik_avmixer.Model.videoFolder_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

public class audioFolder_Adapter extends RecyclerView.Adapter<audioFolder_Adapter.ViewHolder> {

    ArrayList<FolderModel> mediaFiles;
    Context context;
    int value;

    public audioFolder_Adapter(ArrayList<FolderModel> mediaFiles, Context context, int value) {
        this.mediaFiles = mediaFiles;
        this.context = context;
        this.value = value;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_audiofolder,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(audioFolder_Adapter.ViewHolder holder, int position) {
        holder.audio_folderName.setText(mediaFiles.get(position).getFolderName());

        int numberOfFiles = 0;
        File dir = new File(mediaFiles.get(position).getPath());
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file1 : files) {
                if (file1.getName().contains(".mp3")) {
                    numberOfFiles++;
                }
            }
            holder.audio_NumberofFile.setText(numberOfFiles + " Files");
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 2){
                    Intent intent = new Intent(context, AudioFiles_Activity.class);
                    intent.putExtra("AudioFolderName",mediaFiles.get(position).getFolderName());
                    intent.putExtra("AudioFolderVal",value);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mediaFiles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView audio_folderName, audio_NumberofFile;
        public ViewHolder(View itemView) {
            super(itemView);

            audio_NumberofFile = itemView.findViewById(R.id.audio_NumberofFile);
            audio_folderName = itemView.findViewById(R.id.audio_folderName);
        }
    }
}
