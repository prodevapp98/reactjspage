package com.si_avmixer.bhautik_avmixer.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.si_avmixer.bhautik_avmixer.Model.allAudio_Model;
import com.si_avmixer.bhautik_avmixer.R;

import java.io.File;
import java.util.ArrayList;

public class allAudio_Adapter extends RecyclerView.Adapter<allAudio_Adapter.viewHolder> {

    Context context1;
    ArrayList<allAudio_Model> audioArrayList;
    int Value;

    public allAudio_Adapter(Context context1, ArrayList<allAudio_Model> audioArrayList, int value) {
        this.context1 = context1;
        this.audioArrayList = audioArrayList;
        Value = value;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context1).inflate(R.layout.adapter_allaudio, viewGroup, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(final viewHolder holder, final int i) {
        holder.tv_audioName.setText(audioArrayList.get(i).getAudioTitle());
        holder.tv_audio_Duration.setText("Duration: "+audioArrayList.get(i).getAudioDuration());

        long size = Long.parseLong(audioArrayList.get(i).getAudioSize());
        long sizeInMb =  size / (1024 * 1024);

        if (Math.toIntExact(sizeInMb) == 0) {
            sizeInMb = 1;
        }

        holder.tv_audioSize.setText("Size: " + sizeInMb+"MB");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Value == 2){
                    Intent intent1 = new Intent(Intent.ACTION_EDIT, Uri.parse(String.valueOf(audioArrayList.get(i).getAudioUri())));
                    intent1.putExtra("was_get_content_intent", false);
                    intent1.setClassName(context1, "com.si_avmixer.bhautik_avmixer.Waveformview.RingdroidEditActivity");
                    intent1.setAction("android.intent.action.EDIT");
                    intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context1.startActivity(intent1);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return audioArrayList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView tv_audioName, tv_audio_Duration, tv_audioSize;
        public viewHolder(View itemView) {
            super(itemView);
            tv_audioName = (TextView) itemView.findViewById(R.id.tv_audioName);
            tv_audio_Duration = (TextView) itemView.findViewById(R.id.tv_audio_Duration);
            tv_audioSize = (TextView) itemView.findViewById(R.id.tv_audioSize);
        }
    }

}
