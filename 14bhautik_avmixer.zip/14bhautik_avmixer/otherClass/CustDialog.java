package com.si_avmixer.bhautik_avmixer.otherClass;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.widget.TextView;

import com.si_avmixer.bhautik_avmixer.R;

public class CustDialog {
    Context context;
    Dialog dialog;

    public CustDialog(Context context) {
        this.context = context;
    }

    public void showDialog(String title){
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.custdialog);

        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView textView = dialog.findViewById(R.id.dialogText);
        textView.setText(title);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dialog.create();
        }
        dialog.show();
    }

    public void hideDialog(){
        dialog.dismiss();
    }
}
