package com.si_avmixer.bhautik_avmixer.Model

import android.media.MediaMetadataRetriever
import java.io.File
import java.lang.Math.log10
import java.text.DecimalFormat
import java.util.concurrent.TimeUnit
import kotlin.math.pow

class Utils {
    companion object{

        fun getDuration(path: String): String {
            var s: String? = null
            try {
                val mediaMetadataRetriever = MediaMetadataRetriever()
                mediaMetadataRetriever.setDataSource(path)
                s = duration(mediaMetadataRetriever.extractMetadata(9)!!)
            } catch (e: java.lang.Exception) {
                s = "0"
                e.printStackTrace()
            }
            return s!!
        }

        private fun duration(str: String): String? {
            val parseInt = str.toInt().toLong()
            val hours: Long = TimeUnit.MILLISECONDS.toHours(parseInt)
            val minutes: Long =
                TimeUnit.MILLISECONDS.toMinutes(parseInt) - TimeUnit.HOURS.toMinutes(
                    TimeUnit.MILLISECONDS.toHours(parseInt)
                )
            val seconds: Long =
                TimeUnit.MILLISECONDS.toSeconds(parseInt) - TimeUnit.MINUTES.toSeconds(
                    TimeUnit.MILLISECONDS.toMinutes(parseInt)
                )
            return if (hours >= 1) {
                String.format(
                    "%02d:%02d:%02d",
                    java.lang.Long.valueOf(hours),
                    java.lang.Long.valueOf(minutes),
                    java.lang.Long.valueOf(seconds)
                )
            } else String.format(
                "%02d:%02d",
                java.lang.Long.valueOf(minutes),
                java.lang.Long.valueOf(seconds)
            )
        }

        fun getFolderSizeLabel(file: File): String {
            val size =
                getFolderSize(file).toDouble()

            var names: String? = null
            var digitGroups: Int? = null
            if (size <= 0) {
                return "0"
            }
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            digitGroups = (log10(size.toDouble()) / log10(1024.0)).toInt()
            names = DecimalFormat("#,##0.#").format(size / 1024.0.pow(digitGroups.toDouble()))
                .toString() + " " + units[digitGroups]

            return names
        }

        fun getFolderSize(file: File): Long {
            var size: Long = 0
            if (file.isDirectory) {
                for (child in file.listFiles()!!) {
                    size += getFolderSize(child)
                }
            } else {
                size = file.length()
            }
            return size
        }

    }
}