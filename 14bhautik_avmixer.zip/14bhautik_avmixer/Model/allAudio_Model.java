package com.si_avmixer.bhautik_avmixer.Model;

import android.net.Uri;

public class allAudio_Model {

    String audioTitle;
    String audioDuration;
    Uri audioUri;
    String audioSize;
    String durationNoFormat;
    String path;
    String folderNM;

    public allAudio_Model(String audioTitle, String audioDuration, Uri audioUri, String audioSize, String durationNoFormat) {
        this.audioTitle = audioTitle;
        this.audioDuration = audioDuration;
        this.audioUri = audioUri;
        this.audioSize = audioSize;
        this.durationNoFormat = durationNoFormat;
    }

    public String getFolderNM() {
        return folderNM;
    }

    public void setFolderNM(String folderNM) {
        this.folderNM = folderNM;
    }

    public allAudio_Model() {
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getAudioTitle() {
        return audioTitle;
    }

    public void setAudioTitle(String audioTitle) {
        this.audioTitle = audioTitle;
    }

    public String getAudioDuration() {
        return audioDuration;
    }

    public void setAudioDuration(String audioDuration) {
        this.audioDuration = audioDuration;
    }

    public Uri getAudioUri() {
        return audioUri;
    }

    public void setAudioUri(Uri audioUri) {
        this.audioUri = audioUri;
    }

    public String getAudioSize() {
        return audioSize;
    }

    public void setAudioSize(String audioSize) {
        this.audioSize = audioSize;
    }

    public String getDurationNoFormat() {
        return durationNoFormat;
    }

    public void setDurationNoFormat(String durationNoFormat) {
        this.durationNoFormat = durationNoFormat;
    }
}
