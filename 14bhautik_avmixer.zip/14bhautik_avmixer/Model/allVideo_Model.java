package com.si_avmixer.bhautik_avmixer.Model;

import android.net.Uri;

public class allVideo_Model {
    String videoTitle;
    String videoDuration;
    Uri videoUri;
    String videoSize;
    String folderNM;

    public String getFolderNM() {
        return folderNM;
    }

    public void setFolderNM(String folderNM) {
        this.folderNM = folderNM;
    }

    public String getVideoSize() {
        return videoSize;
    }

    public void setVideoSize(String videoSize) {
        this.videoSize = videoSize;
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public void setVideoTitle(String videoTitle) {
        this.videoTitle = videoTitle;
    }

    public String getVideoDuration() {
        return videoDuration;
    }

    public void setVideoDuration(String videoDuration) {
        this.videoDuration = videoDuration;
    }

    public Uri getVideoUri() {
        return videoUri;
    }

    public void setVideoUri(Uri videoUri) {
        this.videoUri = videoUri;
    }
}

