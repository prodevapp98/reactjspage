package com.si_avmixer.bhautik_avmixer.Model;

public class myCreationAudioCutter_Model {

    String songUrls,songName,songDuration;
    int songSize;

    public myCreationAudioCutter_Model(String songUrls, String songName, int songSize, String songDuration) {
        this.songUrls = songUrls;
        this.songName = songName;
        this.songSize = songSize;
        this.songDuration = songDuration;
    }

    public myCreationAudioCutter_Model() {
    }

    public String getSongUrls() {
        return songUrls;
    }

    public void setSongUrls(String songUrls) {
        this.songUrls = songUrls;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public int getSongSize() {
        return songSize;
    }

    public void setSongSize(int songSize) {
        this.songSize = songSize;
    }

    public String getSongDuration() {
        return songDuration;
    }

    public void setSongDuration(String songDuration) {
        this.songDuration = songDuration;
    }
}
