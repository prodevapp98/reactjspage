package com.si_avmixer.bhautik_avmixer.Model;

import java.util.Comparator;

public class FolderModel {
    private String path;
    private String folderName;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public static Comparator<FolderModel> ListSortZtoA = new Comparator<FolderModel>() {


        @Override
        public int compare(FolderModel songModel, FolderModel t1) {
            String StudentName1 = songModel.getFolderName().toUpperCase();
            String StudentName2 = t1.getFolderName().toUpperCase();
            return StudentName2.compareTo(StudentName1);
        }
    };
    public static Comparator<FolderModel> ListSortAtoZ = new Comparator<FolderModel>() {


        @Override
        public int compare(FolderModel songModel, FolderModel t1) {
            String StudentName1 = songModel.getFolderName().toUpperCase();
            String StudentName2 = t1.getFolderName().toUpperCase();
            return StudentName1.compareTo(StudentName2);
        }
    };
    public static Comparator<String> albumListSortAtoZ = new Comparator<String>() {


        @Override
        public int compare(String songModel, String t1) {
            String StudentName1 = songModel.toUpperCase();
            String StudentName2 = t1.toUpperCase();
            return StudentName1.compareTo(StudentName2);
        }
    };
    public static Comparator<String> albumListSortZtoA = new Comparator<String>() {


        @Override
        public int compare(String songModel, String t1) {
            String StudentName1 = songModel.toUpperCase();
            String StudentName2 = t1.toUpperCase();
            return StudentName2.compareTo(StudentName1);
        }
    };

}
