package com.si_avmixer.bhautik_avmixer.Model;

public class MoreApps_Model {

    private String appname;
    private int imgId;

    public MoreApps_Model(String appname, int imgId) {
        this.appname = appname;
        this.imgId = imgId;
    }

    public MoreApps_Model() {
    }

    public String getAppname() {
        return appname;
    }

    public void setAppname(String appname) {
        this.appname = appname;
    }

    public int getImgId() {
        return imgId;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

}
