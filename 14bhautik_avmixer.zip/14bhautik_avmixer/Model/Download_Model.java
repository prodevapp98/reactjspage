package com.si_avmixer.bhautik_avmixer.Model;

public class Download_Model {
    String imgUrls;

    public Download_Model(String imgUrls) {
        this.imgUrls = imgUrls;

    }

    public Download_Model() {
    }

    public String getImgUrls() {
        return imgUrls;
    }

    public void setImgUrls(String imgUrls) {
        this.imgUrls = imgUrls;
    }
}
