package com.si_avmixer.bhautik_avmixer.Model;

import android.bluetooth.le.AdvertiseData;

import java.io.File;

public class myCreationVideo_Model {

    String videoUrls,videoName;
    int videoSize,videoDuration;

    public myCreationVideo_Model(String videoUrls, String videoName, int videoSize, int videoDuration) {
        this.videoUrls = videoUrls;
        this.videoName = videoName;
        this.videoSize = videoSize;
        this.videoDuration = videoDuration;

    }


    public String getVideoUrls() {
        return videoUrls;
    }

    public void setVideoUrls(String videoUrls) {
        this.videoUrls = videoUrls;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }


    public int getVideoSize() {
        return videoSize;
    }

    public void setVideoSize(int videoSize) {
        this.videoSize = videoSize;
    }

    public int getVideoDuration() {
        return videoDuration;
    }

    public void setVideoDuration(int videoDuration) {
        this.videoDuration = videoDuration;
    }
}
