package com.si_avmixer.bhautik_avmixer.AudioExtractor;

import android.annotation.SuppressLint;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;

public class AudioExtractor {

    private static final int DEFAULT_BUFFER_SIZE = 1024 * 1024;
    private static final String TAG = "AudioExtractorDecoder";

    public AudioExtractor() {
    }

    @SuppressLint({"NewApi", "WrongConstant"})
    public void VideotoAudio(String srcPath, String dstPath, boolean useAudio, boolean useVideo) throws IOException {

            MediaExtractor extractor = new MediaExtractor();
            extractor.setDataSource(srcPath);
            int trackCount = extractor.getTrackCount();

            MediaMuxer muxer = new MediaMuxer(dstPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            HashMap<Integer, Integer> indexMap = new HashMap<>(trackCount);
            int bufferSize = -1;
            for (int i = 0; i < trackCount; i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                boolean selectCurrentTrack = false;
                if (mime.startsWith("audio/") && useAudio) {
                    selectCurrentTrack = true;
                } else if (mime.startsWith("video/") && useVideo) {
                    selectCurrentTrack = true;
                }
                if (selectCurrentTrack) {
                    extractor.selectTrack(i);
                    int dstIndex = muxer.addTrack(format);
                    indexMap.put(i, dstIndex);
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        int newSize = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE);
                        bufferSize = Math.max(newSize, bufferSize);
                    }
                }

            }

            if (bufferSize < 0) {
                bufferSize = DEFAULT_BUFFER_SIZE;
            }
            MediaMetadataRetriever retrieverSrc = new MediaMetadataRetriever();
            retrieverSrc.setDataSource(srcPath);
            String degreesString = retrieverSrc.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if (degreesString != null) {
                int degrees = Integer.parseInt(degreesString);
                if (degrees >= 0) {
                    muxer.setOrientationHint(degrees);
                }
            }

            int offset = 0;
            int trackIndex;
            ByteBuffer dstBuf = ByteBuffer.allocate(bufferSize);
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            muxer.start();
            while (true) {
                bufferInfo.offset = offset;
                bufferInfo.size = extractor.readSampleData(dstBuf, offset);
                if (bufferInfo.size < 0) {

                    bufferInfo.size = 0;
                    break;
                } else {
                    bufferInfo.presentationTimeUs = extractor.getSampleTime();
                    bufferInfo.flags = extractor.getSampleFlags();
                    trackIndex = extractor.getSampleTrackIndex();
                    muxer.writeSampleData(indexMap.get(trackIndex), dstBuf, bufferInfo);
                    extractor.advance();
                }
            }

            muxer.stop();
            muxer.release();

    }

}